-- =========================================================
-- AGENDE 3.2 SAMPLE (TEST) DATA - file 2 of 2, run AFTER schema.sql
-- All people below are fictitious test accounts.
-- For several weeks of realistic demo history (analytics/forecast),
-- also run:  python tools/seed_demo_data.py
-- =========================================================
USE agende_db;

-- ---------------------------------------------------------
-- USERS
-- admin123    -> admin@agende.com
-- provider123 -> provider@agende.com
-- user123     -> user@agende.com
-- password123 -> every other sample account
-- ---------------------------------------------------------
INSERT INTO users (id, role_id, name, email, password, phone, is_active) VALUES
(1, 3, 'Angela Marasigan', 'admin@agende.com', 'scrypt:32768:8:1$8NXNaoqGgXyIN5gh$7fe7e5893670e0f1488dc2dac7960fcc674b651c8668a45c08556eaedef7426a518f31948d6d93ee1dbd822b71c7008bee27d16af6ee7449a0a82c5014586c28', '0917-100-0001', 1),
(2, 2, 'Dr. Miguel Santos', 'provider@agende.com', 'scrypt:32768:8:1$pP5MW5mdC3v5FlbO$83f964b5a105f7fbb1cf768a8269e263ad70f17d5533c9f47087c07e1cc9ffefdc273d2296ba8e1abbb44c636f433e2a8911bb4bf7b0b7688bd2503bf5589d3a', '0917-200-0001', 1),
(3, 2, 'Dr. Karen Villareal', 'karen.villareal@agende.com', 'scrypt:32768:8:1$usDorqSnQrOYOjMa$70f11cc50e07f16ce0af5a138b1caf112882fff173ffbbe050511000d41ffbaf88393d37e31b9c078609634e3faa3554985bf55969ce9ba99f6e2bd554aaed57', '0917-200-0002', 1),
(4, 2, 'Engr. Paolo Reyes', 'paolo.reyes@agende.com', 'scrypt:32768:8:1$usDorqSnQrOYOjMa$70f11cc50e07f16ce0af5a138b1caf112882fff173ffbbe050511000d41ffbaf88393d37e31b9c078609634e3faa3554985bf55969ce9ba99f6e2bd554aaed57', '0917-200-0003', 1),
(5, 1, 'Juan Dela Cruz', 'user@agende.com', 'scrypt:32768:8:1$9pkw84xm3i8nBBlR$0d3462b7ea95c4e6a409ec00c6398a340d45b247065f01f431d8ca70e2b6e670ac8977db5da8dbd41d110800877e2a7afae981ef29722c389b4d6a4f94e12fa8', '0917-300-0001', 1),
(6, 1, 'Maria Clara Santos', 'maria.santos@example.com', 'scrypt:32768:8:1$usDorqSnQrOYOjMa$70f11cc50e07f16ce0af5a138b1caf112882fff173ffbbe050511000d41ffbaf88393d37e31b9c078609634e3faa3554985bf55969ce9ba99f6e2bd554aaed57', '0917-300-0002', 1),
(7, 1, 'Jose Rizal Ramos', 'jose.ramos@example.com', 'scrypt:32768:8:1$usDorqSnQrOYOjMa$70f11cc50e07f16ce0af5a138b1caf112882fff173ffbbe050511000d41ffbaf88393d37e31b9c078609634e3faa3554985bf55969ce9ba99f6e2bd554aaed57', '0917-300-0003', 1),
(8, 1, 'Andres Bonifacio Cruz', 'andres.cruz@example.com', 'scrypt:32768:8:1$usDorqSnQrOYOjMa$70f11cc50e07f16ce0af5a138b1caf112882fff173ffbbe050511000d41ffbaf88393d37e31b9c078609634e3faa3554985bf55969ce9ba99f6e2bd554aaed57', '0917-300-0004', 1),
(9, 1, 'Gabriela Silang Torres', 'gabriela.torres@example.com', 'scrypt:32768:8:1$usDorqSnQrOYOjMa$70f11cc50e07f16ce0af5a138b1caf112882fff173ffbbe050511000d41ffbaf88393d37e31b9c078609634e3faa3554985bf55969ce9ba99f6e2bd554aaed57', '0917-300-0005', 1),
(10, 1, 'Emilio Aguinaldo Reyes', 'emilio.reyes@example.com', 'scrypt:32768:8:1$usDorqSnQrOYOjMa$70f11cc50e07f16ce0af5a138b1caf112882fff173ffbbe050511000d41ffbaf88393d37e31b9c078609634e3faa3554985bf55969ce9ba99f6e2bd554aaed57', '0917-300-0006', 1),
(11, 1, 'Melchora Aquino Flores', 'melchora.flores@example.com', 'scrypt:32768:8:1$usDorqSnQrOYOjMa$70f11cc50e07f16ce0af5a138b1caf112882fff173ffbbe050511000d41ffbaf88393d37e31b9c078609634e3faa3554985bf55969ce9ba99f6e2bd554aaed57', '0917-300-0007', 1),
(12, 1, 'Antonio Luna Bautista', 'antonio.bautista@example.com', 'scrypt:32768:8:1$usDorqSnQrOYOjMa$70f11cc50e07f16ce0af5a138b1caf112882fff173ffbbe050511000d41ffbaf88393d37e31b9c078609634e3faa3554985bf55969ce9ba99f6e2bd554aaed57', '0917-300-0008', 1),
(13, 2, 'Atty. Liza Mendoza', 'liza.mendoza@agende.com', 'scrypt:32768:8:1$usDorqSnQrOYOjMa$70f11cc50e07f16ce0af5a138b1caf112882fff173ffbbe050511000d41ffbaf88393d37e31b9c078609634e3faa3554985bf55969ce9ba99f6e2bd554aaed57', '0917-200-0004', 1);

-- ---------------------------------------------------------
-- SERVICES
-- ---------------------------------------------------------
INSERT INTO services (id, name, description, duration, risk_category, is_active) VALUES
(1, 'General Consultation', 'Basic check-up and consultation', 30, 'Healthcare', 1),
(2, 'Dental Cleaning', 'Routine dental cleaning and check-up', 45, 'Dental', 1),
(3, 'IT Support Session', 'Technical support and troubleshooting', 60, NULL, 1),
(4, 'Legal Consultation', 'Consultation with a legal advisor', 30, 'Legal & Financial', 1),
(5, 'Career Counseling', 'One-on-one career guidance session', 45, 'Education', 1);

-- ---------------------------------------------------------
-- STAFF (providers) and the services each one offers
-- ---------------------------------------------------------
INSERT INTO providers (id, user_id, position, is_active) VALUES
(1, 2, 'Physician', 1),
(2, 3, 'Dentist', 1),
(3, 4, 'IT Specialist', 1),
(4, 13, 'Legal Advisor', 1);

INSERT INTO provider_services (provider_id, service_id) VALUES
(1, 1),
(2, 2),
(3, 3), (3, 5),
(4, 4), (4, 5);

-- ---------------------------------------------------------
-- WEEKLY AVAILABILITY  (0=Monday ... 6=Sunday)
-- Dr. Santos has two windows per day = a 12:00-13:00 lunch break.
-- ---------------------------------------------------------
INSERT INTO provider_schedules (provider_id, day_of_week, start_time, end_time, is_available) VALUES
(1, 0, '08:00:00', '12:00:00', 1), (1, 0, '13:00:00', '17:00:00', 1),
(1, 1, '08:00:00', '12:00:00', 1), (1, 1, '13:00:00', '17:00:00', 1),
(1, 2, '08:00:00', '12:00:00', 1), (1, 2, '13:00:00', '17:00:00', 1),
(1, 3, '08:00:00', '12:00:00', 1), (1, 3, '13:00:00', '17:00:00', 1),
(1, 4, '08:00:00', '12:00:00', 1), (1, 4, '13:00:00', '17:00:00', 1),
(2, 0, '09:00:00', '18:00:00', 1),
(2, 2, '09:00:00', '18:00:00', 1),
(2, 4, '09:00:00', '18:00:00', 1),
(3, 1, '08:00:00', '16:00:00', 1),
(3, 3, '08:00:00', '16:00:00', 1),
(3, 5, '08:00:00', '12:00:00', 1),
(4, 0, '10:00:00', '15:00:00', 1),
(4, 1, '10:00:00', '15:00:00', 1),
(4, 2, '10:00:00', '15:00:00', 1),
(4, 3, '10:00:00', '15:00:00', 1);

-- ---------------------------------------------------------
-- A FEW APPOINTMENTS around today (sample statuses)
-- ---------------------------------------------------------
INSERT INTO appointments (id, user_id, provider_id, service_id, appointment_date, start_time, end_time, status, notes, cancellation_reason) VALUES
(1, 5, 1, 1, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '09:00:00', '09:30:00', 'confirmed', 'Follow-up check-up', NULL),
(2, 5, 2, 2, DATE_ADD(CURDATE(), INTERVAL 2 DAY), '10:00:00', '10:45:00', 'pending', 'First time cleaning', NULL),
(3, 6, 1, 1, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '11:00:00', '11:30:00', 'confirmed', NULL, NULL),
(4, 7, 3, 3, DATE_ADD(CURDATE(), INTERVAL 3 DAY), '09:00:00', '10:00:00', 'pending', 'Laptop issues', NULL),
(5, 8, 2, 2, DATE_ADD(CURDATE(), INTERVAL 4 DAY), '09:00:00', '09:45:00', 'confirmed', NULL, NULL),
(6, 9, 1, 1, DATE_ADD(CURDATE(), INTERVAL 5 DAY), '08:30:00', '09:00:00', 'pending', NULL, NULL),
(7, 5, 3, 3, DATE_SUB(CURDATE(), INTERVAL 5 DAY), '08:00:00', '09:00:00', 'completed', 'Resolved network issue', NULL),
(8, 6, 2, 2, DATE_SUB(CURDATE(), INTERVAL 3 DAY), '10:00:00', '10:45:00', 'completed', NULL, NULL),
(9, 10, 1, 1, DATE_SUB(CURDATE(), INTERVAL 2 DAY), '13:00:00', '13:30:00', 'cancelled', NULL, 'Client requested cancellation'),
(10, 11, 3, 3, DATE_SUB(CURDATE(), INTERVAL 1 DAY), '08:00:00', '09:00:00', 'no_show', NULL, NULL),
(11, 12, 4, 4, DATE_ADD(CURDATE(), INTERVAL 6 DAY), '11:00:00', '11:30:00', 'pending', NULL, NULL),
(12, 5, 1, 1, DATE_ADD(CURDATE(), INTERVAL 7 DAY), '08:00:00', '08:30:00', 'confirmed', NULL, NULL);

-- ---------------------------------------------------------
-- STATUS HISTORY
-- ---------------------------------------------------------
INSERT INTO appointment_history (appointment_id, action, old_status, new_status, performed_by, reason) VALUES
(1, 'created', NULL, 'pending', 5, NULL), (1, 'confirmed', 'pending', 'confirmed', 2, NULL),
(2, 'created', NULL, 'pending', 5, NULL),
(3, 'created', NULL, 'pending', 6, NULL), (3, 'confirmed', 'pending', 'confirmed', 2, NULL),
(4, 'created', NULL, 'pending', 7, NULL),
(5, 'created', NULL, 'pending', 8, NULL), (5, 'confirmed', 'pending', 'confirmed', 3, NULL),
(6, 'created', NULL, 'pending', 9, NULL),
(7, 'created', NULL, 'pending', 5, NULL), (7, 'confirmed', 'pending', 'confirmed', 4, NULL), (7, 'completed', 'confirmed', 'completed', 4, NULL),
(8, 'created', NULL, 'pending', 6, NULL), (8, 'confirmed', 'pending', 'confirmed', 3, NULL), (8, 'completed', 'confirmed', 'completed', 3, NULL),
(9, 'created', NULL, 'pending', 10, NULL), (9, 'cancelled', 'pending', 'cancelled', 10, 'Client requested cancellation'),
(10, 'created', NULL, 'pending', 11, NULL), (10, 'confirmed', 'pending', 'confirmed', 4, NULL), (10, 'no_show', 'confirmed', 'no_show', 4, NULL),
(11, 'created', NULL, 'pending', 12, NULL),
(12, 'created', NULL, 'pending', 5, NULL), (12, 'confirmed', 'pending', 'confirmed', 2, NULL);

-- ---------------------------------------------------------
-- NOTIFICATIONS
-- ---------------------------------------------------------
INSERT INTO notifications (user_id, appointment_id, event_code, title, message, type, is_read) VALUES
(5, 1, 'N003', 'Appointment confirmed', 'Your General Consultation with Dr. Miguel Santos has been confirmed.', 'success', 0),
(5, 2, 'N001', 'Request submitted', 'Your Dental Cleaning request is waiting for confirmation.', 'info', 0),
(6, 3, 'N003', 'Appointment confirmed', 'Your General Consultation with Dr. Miguel Santos has been confirmed.', 'success', 1),
(2, 6, 'N002', 'New appointment request', 'Gabriela Silang Torres requested General Consultation.', 'info', 0),
(4, 4, 'N002', 'New appointment request', 'Jose Rizal Ramos requested IT Support Session.', 'info', 0),
(1, NULL, 'N012', 'Welcome to AGENDE 3.0', 'System settings, forecasting and reports are available in the sidebar.', 'info', 0);
