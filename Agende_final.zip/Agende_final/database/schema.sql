-- =========================================================
-- AGENDE 3.2 DATABASE SCHEMA
-- Web-Based Multi-Appointment System
--
-- File 1 of 2. Creates agende_db with every table plus the reference
-- data the system needs (roles, default system settings).
-- File 2 (seed.sql) adds the sample accounts, services, schedules and
-- appointments used for testing and demonstrations.
--
-- Easiest: install.bat runs both for you.
-- By hand (phpMyAdmin -> Import, or the MySQL command line):
--     mysql -u root -p < database/schema.sql
--     mysql -u root -p agende_db < database/seed.sql
-- Running schema.sql on an existing agende_db stops at "table exists":
-- drop the database first (back it up) if you want to start over.
--
-- Tables (blueprint section 17, adapted to this codebase):
--   roles, users, services, providers (staff), provider_services,
--   provider_schedules, blocked_periods, appointments,
--   appointment_history (status history), notifications, audit_logs,
--   system_settings, password_resets, forecast_models,
--   forecast_results, historical_appointments
-- =========================================================

CREATE DATABASE IF NOT EXISTS agende_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE agende_db;

-- ---------------------------------------------------------
-- ROLES  (names kept from 2.1: user = Client, provider = Staff)
-- ---------------------------------------------------------
CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255) NULL
);

-- ---------------------------------------------------------
-- USERS (all accounts)
-- ---------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_id INT NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(30) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    last_login DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

-- ---------------------------------------------------------
-- SERVICES
-- ---------------------------------------------------------
CREATE TABLE services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description VARCHAR(255) NULL,
    duration INT NOT NULL DEFAULT 30,          -- minutes
    risk_category VARCHAR(60) NULL,            -- no-show model category (Dental, Healthcare ...), set on the Services page
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_service_duration CHECK (duration > 0)
);

-- ---------------------------------------------------------
-- PROVIDERS / STAFF  (one row per staff user account)
-- ---------------------------------------------------------
CREATE TABLE providers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL UNIQUE,
    position VARCHAR(100) NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ---------------------------------------------------------
-- PROVIDER_SERVICES  (Staff <-> Services, many-to-many)
-- ---------------------------------------------------------
CREATE TABLE provider_services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    provider_id INT NOT NULL,
    service_id INT NOT NULL,
    UNIQUE KEY uq_provider_service (provider_id, service_id),
    FOREIGN KEY (provider_id) REFERENCES providers(id),
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- ---------------------------------------------------------
-- PROVIDER SCHEDULES (weekly working windows)
-- Several windows on the same day model breaks, e.g.
-- Monday 08:00-12:00 and Monday 13:00-17:00 = lunch break.
-- ---------------------------------------------------------
CREATE TABLE provider_schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    provider_id INT NOT NULL,
    day_of_week TINYINT NOT NULL,              -- 0=Monday ... 6=Sunday
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    is_available TINYINT(1) NOT NULL DEFAULT 1,
    FOREIGN KEY (provider_id) REFERENCES providers(id),
    CONSTRAINT chk_schedule_range CHECK (end_time > start_time),
    CONSTRAINT chk_schedule_day CHECK (day_of_week BETWEEN 0 AND 6)
);

-- ---------------------------------------------------------
-- BLOCKED PERIODS (leave, meetings, one-off breaks)
-- ---------------------------------------------------------
CREATE TABLE blocked_periods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    provider_id INT NOT NULL,
    start_datetime DATETIME NOT NULL,
    end_datetime DATETIME NOT NULL,
    reason VARCHAR(255) NULL,
    created_by INT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (provider_id) REFERENCES providers(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    CONSTRAINT chk_blocked_period CHECK (end_datetime > start_datetime),
    INDEX idx_blocked_provider (provider_id, start_datetime)
);

-- ---------------------------------------------------------
-- APPOINTMENTS (core transaction table)
-- status: pending, confirmed, completed, cancelled, rejected,
--         no_show (shown as "Did not attend"), expired
-- ---------------------------------------------------------
CREATE TABLE appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    provider_id INT NOT NULL,
    service_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    notes VARCHAR(255) NULL,
    cancellation_reason VARCHAR(255) NULL,
    rejection_reason VARCHAR(255) NULL,
    cancelled_by INT NULL,
    reschedule_count INT NOT NULL DEFAULT 0,
    reminder_sent_at DATETIME NULL,
    sameday_reminder_sent_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (provider_id) REFERENCES providers(id),
    FOREIGN KEY (service_id) REFERENCES services(id),
    FOREIGN KEY (cancelled_by) REFERENCES users(id),
    CONSTRAINT chk_appointment_range CHECK (end_time > start_time),
    INDEX idx_appt_provider_date (provider_id, appointment_date),
    INDEX idx_appt_user_date (user_id, appointment_date),
    INDEX idx_appt_status (status),
    INDEX idx_appt_date (appointment_date)
);

-- ---------------------------------------------------------
-- APPOINTMENT HISTORY (status history; performed_by NULL = system)
-- ---------------------------------------------------------
CREATE TABLE appointment_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    appointment_id INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    old_status VARCHAR(20) NULL,
    new_status VARCHAR(20) NULL,
    performed_by INT NULL,
    reason VARCHAR(255) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id),
    FOREIGN KEY (performed_by) REFERENCES users(id),
    INDEX idx_history_appt (appointment_id)
);

-- ---------------------------------------------------------
-- NOTIFICATIONS
-- ---------------------------------------------------------
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    appointment_id INT NULL,
    event_code VARCHAR(10) NULL,                -- N001 ... N012 (blueprint section 12)
    title VARCHAR(120) NULL,
    message VARCHAR(255) NOT NULL,
    type VARCHAR(30) NOT NULL DEFAULT 'info',   -- info, success, warning, danger
    channel VARCHAR(20) NOT NULL DEFAULT 'in_app',
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    email_sent_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (appointment_id) REFERENCES appointments(id),
    INDEX idx_notif_user (user_id, is_read)
);

-- ---------------------------------------------------------
-- AUDIT LOGS (append-only from the application's point of view)
-- ---------------------------------------------------------
CREATE TABLE audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action VARCHAR(100) NOT NULL,
    entity_name VARCHAR(80) NOT NULL,
    entity_id INT NULL,
    old_value TEXT NULL,
    new_value TEXT NULL,
    details TEXT NULL,
    ip_address VARCHAR(45) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_audit_created (created_at)
);

-- ---------------------------------------------------------
-- SYSTEM SETTINGS (edited on /admin/settings)
-- ---------------------------------------------------------
CREATE TABLE system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value VARCHAR(255) NOT NULL,
    description VARCHAR(255) NULL,
    updated_by INT NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (updated_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ---------------------------------------------------------
-- PASSWORD RESETS (token is stored hashed, never in plain text)
-- ---------------------------------------------------------
CREATE TABLE password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    token_hash CHAR(64) NOT NULL UNIQUE,
    expires_at DATETIME NOT NULL,
    used_at DATETIME NULL,
    created_by INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- ---------------------------------------------------------
-- FORECAST MODELS and RESULTS (saved runs, blueprint 18.13/18.14)
-- ---------------------------------------------------------
CREATE TABLE forecast_models (
    id INT AUTO_INCREMENT PRIMARY KEY,
    model_type VARCHAR(30) NOT NULL,            -- appointments / no_shows
    algorithm VARCHAR(60) NOT NULL DEFAULT 'Ordinary least squares (simple linear regression)',
    data_source VARCHAR(20) NOT NULL,           -- live / imported / combined
    training_start DATE NOT NULL,
    training_end DATE NOT NULL,
    training_weeks INT NOT NULL,
    test_weeks INT NOT NULL,
    intercept DECIMAL(14,6) NOT NULL,
    slope DECIMAL(14,6) NOT NULL,
    mae DECIMAL(14,4) NULL,
    rmse DECIMAL(14,4) NULL,
    r2 DECIMAL(14,4) NULL,
    version_label VARCHAR(20) NULL,             -- FM-0001: the appointment + did-not-attend pair trained together
    training_record_count INT NULL,             -- appointment records inside the training weeks (blueprint 18.13)
    baseline_mae DECIMAL(14,4) NULL,            -- MAE of the naive "average training week" baseline on the test weeks
    min_weeks INT NULL,                         -- minimum-weeks rule in force when trained
    train_trigger VARCHAR(20) NOT NULL DEFAULT 'manual',  -- manual / auto / cli
    is_active TINYINT(1) NOT NULL DEFAULT 0,    -- 1 = the deployed model used by the dashboard
    created_by INT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_fm_active (is_active),
    INDEX idx_fm_version (version_label),
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE forecast_results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    model_id INT NOT NULL,
    forecast_period DATE NOT NULL,              -- Monday of the forecast week
    target_type VARCHAR(30) NOT NULL,
    predicted_value DECIMAL(14,4) NOT NULL,     -- raw model output (may be negative)
    display_value INT NOT NULL,                 -- max(0, round(predicted_value))
    generated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (model_id) REFERENCES forecast_models(id)
);

-- ---------------------------------------------------------
-- HISTORICAL APPOINTMENTS (imported history for forecasting only;
-- filled by tools/import_dataset_history.py, kept separate from
-- the operational appointments table - blueprint section 40)
-- ---------------------------------------------------------
CREATE TABLE historical_appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source_ref VARCHAR(40) NULL,
    appointment_date DATE NOT NULL,
    start_time TIME NULL,
    duration_minutes INT NULL,
    service_category VARCHAR(100) NULL,
    provider_code VARCHAR(40) NULL,
    status VARCHAR(20) NOT NULL,
    imported_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_hist_date (appointment_date)
);

-- ---------------------------------------------------------
-- REQUIRED REFERENCE DATA (not sample data)
-- ---------------------------------------------------------
INSERT INTO roles (id, name, description) VALUES
(1, 'user', 'Client - books and manages own appointments'),
(2, 'provider', 'Staff / service provider - manages assigned appointments and availability'),
(3, 'admin', 'Administrator - manages the whole system');

INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('booking_min_lead_minutes', '60', 'Minimum minutes between now and the start of a new booking'),
('booking_max_days_ahead', '60', 'How many days ahead clients may book'),
('slot_interval_minutes', '30', 'Spacing between offered start times'),
('buffer_minutes', '0', 'Gap required after each appointment before the next can start'),
('cancellation_cutoff_hours', '2', 'Clients cannot cancel or reschedule within this many hours of the start'),
('require_cancellation_reason', '1', '1 = a reason is required to cancel'),
('reminder_hours_before', '24', 'When the advance reminder is sent'),
('auto_expire_pending', '1', '1 = pending requests whose start time passes become Expired'),
('forecast_min_weeks', '26', 'Minimum complete weeks before a model is trained (set by the minimum-weeks experiment)'),
('forecast_auto_retrain', '1', '1 = retrain the forecast model automatically when a new complete week of records exists'),
('noshow_risk_enabled', '1', '1 = show the advisory no-show risk to staff and admins (never to clients)'),
('forecast_horizon_weeks', '4', 'Number of future weeks to forecast');
