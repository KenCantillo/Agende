# AGENDE: Baseline, Tuning and Model Selection Report

_Generated October 23, 2026 by `research/model_selection.py` from `AGENDE_dataset_package.zip` (scikit-learn 1.9.1, fixed seed 42, 9 min). Re-running the script reproduces every number._

## Summary: the two selected models

| Task | Selected model | Key test result | Beats baseline by |
|---|---|---|---|
| **No-show prediction** (per appointment) | **Logistic regression**, all dataset features (l1_ratio=1, class_weight=balanced, C=0.03) | PR-AUC 0.293, ROC-AUC 0.746; at the chosen threshold catches 49% of no-shows with 28% precision | PR-AUC 2.1× the history rule, 3.0× chance |
| **Time forecasting** (weekly totals, 1–4 weeks ahead) | **Moving average** (appointments: {'window': 52}, no-shows: {'window': 12}) | test MAE 16.3 appointments/week (2.8% of a week), 6.3 no-shows/week | 27% and 25% lower MAE than the naive forecast |

For use **inside AGENDE**, which does not record age, sex, weather, booking channel, deposits or reminder status, the same procedure on AGENDE-available features selects **Logistic regression** (test PR-AUC 0.275, ROC-AUC 0.722).

> **Blueprint note.** The blueprint (A-011, A-012, 15.1) limits AGENDE to aggregate forecasting and rules out individual no-show prediction. Using the no-show model in the system therefore needs a documented scope change: present it as an advisory risk indicator for staff (who to remind or call), never as automatic cancellation, rejection or overbooking, and say so in the manuscript.

## Part 1: No-show prediction

### 1.1 Data understanding

| Item | Value |
|---|---|
| Rows · columns | 60,000 · 23 |
| Appointment dates | 01/01/2023 to 12/31/2024 |
| Missing values · duplicate IDs | 0 · 0 |
| Outcomes | attended 45,980, cancelled 9,683, did_not_attend 4,337 |
| Booking date before appointment date | yes, all rows |
| `scheduling_interval` equals the date difference | yes, all rows |
| Rows marked first visit but with earlier appointments | 26,688 (inconsistent; kept, but `prior_appointments` carries the history) |

No-show rate by quarter (drift):

| 2023Q1 | 2023Q2 | 2023Q3 | 2023Q4 | 2024Q1 | 2024Q2 | 2024Q3 | 2024Q4 |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 6.1% | 6.5% | 6.8% | 7.0% | 7.2% | 8.0% | 8.1% | 8.1% |

No-show rate by number of earlier no-shows: 0: 5.6%, 1: 9.9%, 2: 16.8%, 3: 24.8%, 4+: 35.1%. Past behaviour is the strongest single signal.

### 1.2 Preparation and design decisions

* **Target:** `did_not_attend` (1 = missed). **Population:** non-cancelled appointments. A cancelled booking can neither be attended nor missed, and cancellations are known before the visit, when staff would act on a risk score. (The README's all-rows definition is reported in 1.6.)
* **Split by time, never at random** (the rate drifts upward):

| Set | Dates | Rows | No-show rate | Used for |
|---|---|---:|---:|---|
| Train | 01/01/2023 – 03/31/2024 | 31,668 | 7.9% | fitting |
| Validation | 04/01/2024 – 08/31/2024 | 10,422 | 9.7% | tuning, model choice, threshold |
| Test | 09/01/2024 – 12/31/2024 | 8,227 | 9.8% | final report only |

* **Derived features:** appointment hour, `has_history`, earlier no-show rate and earlier cancellation rate (from the client's earlier appointments). History counts enter as log(1 + count): the median client has 3 earlier visits, and a raw count would make a regular client with hundreds of visits look extreme. This scored better on validation than raw counts (AGENDE set: PR-AUC 0.247 vs 0.242 for raw counts). Deployed models also clip every number to the 0.5–99.5 percentile range seen in training.
* **Excluded:** `appointment_id` (identifier (README: never a feature)); `historical_outcome` (is the outcome (leakage)); `scheduling_date / appointment_date` (used only to split by time); `age_group` (duplicate of age).
* **Feature sets:** *full* = 20 features from the dataset; *agende* = 12 features AGENDE records or can compute (scheduling_interval, is_first_visit, log_prior_appointments, log_prior_no_shows, log_prior_cancellations, prior_no_show_rate, prior_cancel_rate, has_history, daily_bookings_in_category, hour, appointment_category, day_of_week).
* **Metrics:** PR-AUC (average precision) is the primary metric, because only about 9% of appointments are missed and accuracy would reward predicting "attends" for everyone. ROC-AUC, Brier score (probability accuracy), and precision / recall / F1 at a threshold are also reported.

### 1.3 Baselines

| Baseline | Val PR-AUC | Test PR-AUC | Test ROC-AUC | Test precision | Test recall | Test F1 | Test accuracy |
|---|---:|---:|---:|---:|---:|---:|---:|
| Baseline: always 'attends' (majority class) | 0.097 | 0.098 | 0.500 | 0.000 | 0.000 | 0.000 | 0.902 |
| Baseline: rule 'missed before -> will miss' | 0.143 | 0.142 | 0.640 | 0.172 | 0.587 | 0.266 | 0.682 |
| Baseline: logistic regression, default settings | 0.266 | 0.289 | 0.744 | 0.262 | 0.493 | 0.342 | 0.814 |

The majority baseline shows why accuracy is misleading: about 90% accuracy while catching no no-shows at all.

### 1.4 Hyper-parameter tuning

Random search: every configuration is trained on the training months and scored on the validation months (PR-AUC). Class weighting (`balanced`) is part of the search, as a way to handle the class imbalance.

| Model | Search space | Configurations tried |
|---|---|---:|
| Logistic regression | C ∈ [0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1, 3, 10]; l1_ratio ∈ [0, 1]; class_weight ∈ [None, 'balanced'] | 36 per feature set |
| Logistic regression with binned numbers (scorecard) | n_bins ∈ [4, 6, 8, 10, 12]; C ∈ [0.01, 0.03, 0.1, 0.3, 1, 3]; l1_ratio ∈ [0, 1]; class_weight ∈ [None, 'balanced'] | 30 per feature set |
| Decision tree | max_depth ∈ [3, 4, 5, 6, 8, 10, 12]; min_samples_leaf ∈ [20, 50, 100, 200, 400]; class_weight ∈ [None, 'balanced']; criterion ∈ ['gini', 'entropy'] | 30 per feature set |
| Random forest | n_estimators ∈ [200, 400]; max_depth ∈ [6, 8, 10, 14, None]; min_samples_leaf ∈ [5, 10, 20, 50, 100]; max_features ∈ ['sqrt', 0.3, 0.5]; class_weight ∈ [None, 'balanced_subsample'] | 18 per feature set |
| Gradient boosting (HistGradientBoosting) | learning_rate ∈ [0.02, 0.03, 0.05, 0.08, 0.1]; max_iter ∈ [150, 300, 500]; max_leaf_nodes ∈ [7, 15, 31]; max_depth ∈ [3, 4, 6, None]; min_samples_leaf ∈ [50, 100, 200, 400]; l2_regularization ∈ [0, 0.1, 1, 5]; class_weight ∈ [None, 'balanced'] | 40 per feature set |

### 1.5 Leaderboard (tuned models)

**All dataset features**

| Model | Best settings | Val PR-AUC | Val ROC-AUC | Test PR-AUC | Test ROC-AUC | Test Brier | Test precision | Test recall | Test F1 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| **Logistic regression** ← chosen | l1_ratio=1, class_weight=balanced, C=0.03 | 0.270 | 0.733 | 0.293 | 0.746 | 0.0795 | 0.276 | 0.489 | 0.353 |
| Random forest | n_estimators=400, min_samples_leaf=20, max_features=0.3, max_depth=8, class_weight=None | 0.258 | 0.720 | 0.283 | 0.734 | 0.0805 | 0.275 | 0.457 | 0.343 |
| Gradient boosting (HistGradientBoosting) | min_samples_leaf=50, max_leaf_nodes=7, max_iter=500, max_depth=None, learning_rate=0.08, l2_regularization=0, class_weight=balanced | 0.249 | 0.714 | 0.269 | 0.724 | 0.2314 | 0.226 | 0.487 | 0.309 |
| Logistic regression with binned numbers (scorecard) | n_bins=12, l1_ratio=0, class_weight=None, C=0.01 | 0.245 | 0.721 | 0.239 | 0.730 | 0.0827 | 0.233 | 0.523 | 0.322 |
| Decision tree | min_samples_leaf=50, max_depth=8, criterion=entropy, class_weight=None | 0.227 | 0.676 | 0.241 | 0.699 | 0.0823 | 0.264 | 0.436 | 0.329 |

Selection test (paired bootstrap, 2,000 resamples of the validation set; difference in PR-AUC vs the top model):

| Model | Δ PR-AUC vs top | 95% interval | Statistically tied with the top model? |
|---|---:|---|---|
| Logistic regression | +0.0000 | (+0.0000, +0.0000) | yes |
| Random forest | -0.0119 | (-0.0249, +0.0004) | yes |
| Gradient boosting (HistGradientBoosting) | -0.0211 | (-0.0355, -0.0080) | no |
| Logistic regression with binned numbers (scorecard) | -0.0248 | (-0.0408, -0.0103) | no |
| Decision tree | -0.0437 | (-0.0629, -0.0261) | no |

**Features AGENDE records**

| Model | Best settings | Val PR-AUC | Val ROC-AUC | Test PR-AUC | Test ROC-AUC | Test Brier | Test precision | Test recall | Test F1 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| **Logistic regression** ← chosen | l1_ratio=1, class_weight=balanced, C=0.03 | 0.247 | 0.703 | 0.275 | 0.722 | 0.0809 | 0.280 | 0.423 | 0.337 |
| Gradient boosting (HistGradientBoosting) | min_samples_leaf=50, max_leaf_nodes=7, max_iter=500, max_depth=None, learning_rate=0.08, l2_regularization=0, class_weight=balanced | 0.247 | 0.696 | 0.266 | 0.704 | 0.2258 | 0.269 | 0.396 | 0.320 |
| Random forest | n_estimators=400, min_samples_leaf=20, max_features=sqrt, max_depth=6, class_weight=None | 0.237 | 0.694 | 0.265 | 0.709 | 0.0820 | 0.282 | 0.404 | 0.332 |
| Logistic regression with binned numbers (scorecard) | n_bins=12, l1_ratio=0, class_weight=None, C=0.01 | 0.216 | 0.696 | 0.225 | 0.710 | 0.0840 | 0.241 | 0.400 | 0.301 |
| Decision tree | min_samples_leaf=50, max_depth=10, criterion=entropy, class_weight=balanced | 0.213 | 0.660 | 0.229 | 0.670 | 0.2432 | 0.257 | 0.360 | 0.300 |

Selection test (paired bootstrap, 2,000 resamples of the validation set; difference in PR-AUC vs the top model):

| Model | Δ PR-AUC vs top | 95% interval | Statistically tied with the top model? |
|---|---:|---|---|
| Logistic regression | +0.0000 | (+0.0000, +0.0000) | yes |
| Gradient boosting (HistGradientBoosting) | -0.0006 | (-0.0131, +0.0122) | yes |
| Random forest | -0.0107 | (-0.0238, +0.0029) | yes |
| Logistic regression with binned numbers (scorecard) | -0.0313 | (-0.0468, -0.0171) | no |
| Decision tree | -0.0337 | (-0.0495, -0.0193) | no |

**Selection rule:** highest validation PR-AUC. If a simpler model is statistically tied with it, the simpler model wins (simplicity order: logistic regression < binned logistic < decision tree < random forest < gradient boosting), because it is easier to explain, to audit and to deploy. The test set was used only after the choice was made.

### 1.6 The chosen models in detail

**All dataset features: Logistic regression.** Threshold 0.158 (maximizes F1 on validation). On the test months it flags 17.4% of appointments:

| | Predicted attends | Predicted no-show |
|---|---:|---:|
| **Attended** | 6,380 | 1,038 |
| **Did not attend** | 413 | 396 |

Ranking value: reminding only the riskiest 5% catches 22%, 10% catches 35%, 20% catches 53%, 30% catches 63% of all no-shows (random selection would catch the same percentage as it contacts).

**AGENDE features: Logistic regression.** Threshold 0.153 (maximizes F1 on validation). On the test months it flags 14.9% of appointments:

| | Predicted attends | Predicted no-show |
|---|---:|---:|
| **Attended** | 6,538 | 880 |
| **Did not attend** | 467 | 342 |

Ranking value: reminding only the riskiest 5% catches 20%, 10% catches 33%, 20% catches 50%, 30% catches 61% of all no-shows (random selection would catch the same percentage as it contacts).

**Sensitivity check:** using the README's definition (all 60,000 rows, cancelled = 0), the chosen AGENDE configuration reaches test PR-AUC 0.225 / ROC-AUC 0.712. PR-AUC is lower mainly because the base rate is lower; the ranking quality (ROC-AUC) is similar.

**What drives the prediction** (permutation importance on test; drop in PR-AUC when a feature is shuffled):

| Feature | Importance | ± |
|---|---:|---:|
| `log_prior_no_shows` | 0.1645 | 0.0022 |
| `appointment_category` | 0.0294 | 0.0046 |
| `deposit_paid` | 0.0258 | 0.0032 |
| `reminder_sent` | 0.0226 | 0.0027 |
| `scheduling_interval` | 0.0186 | 0.0031 |
| `age` | 0.0105 | 0.0049 |
| `weather` | 0.0054 | 0.0020 |
| `log_prior_cancellations` | 0.0028 | 0.0008 |
| `log_prior_appointments` | 0.0022 | 0.0021 |
| `is_first_visit` | 0.0016 | 0.0020 |

Largest logistic-regression effects (per one standard deviation for numbers; odds ratio = e^coefficient):

| Feature | Coefficient | Odds ratio |
|---|---:|---:|
| `log_prior_no_shows` (+1 SD = 0.38) | +0.506 | 1.66 |
| `deposit_paid` (+1 SD = 0.37) | -0.333 | 0.72 |
| `reminder_sent` (+1 SD = 0.46) | -0.284 | 0.75 |
| `scheduling_interval` (+1 SD = 6.54) | +0.221 | 1.25 |
| `log_prior_appointments` (+1 SD = 0.88) | -0.170 | 0.84 |
| `age` (+1 SD = 17.11) | -0.152 | 0.86 |
| `is_first_visit` (+1 SD = 0.49) | +0.104 | 1.11 |
| `log_prior_cancellations` (+1 SD = 0.52) | +0.086 | 1.09 |

### 1.7 Exported models

* `research/ml/models/noshow_full.json`: coefficients as plain JSON, scored by `agende/noshow_scorer.py` with **no scikit-learn needed**. It matches scikit-learn's own probabilities to 2.8e-16. Also `noshow_full.joblib` (needs scikit-learn 1.9.1).
* `research/ml/models/noshow_agende.json` (also deployed to `agende/models/`, which the web app reads): coefficients as plain JSON, scored by `agende/noshow_scorer.py` with **no scikit-learn needed**. It matches scikit-learn's own probabilities to 2.2e-16. Also `noshow_agende.joblib` (needs scikit-learn 1.9.1).
* Final models were refit on all non-cancelled appointments with the chosen settings. A model trained with `class_weight=balanced` has its intercept lowered by log(n0/n1) (prior correction, King & Zeng 2001), so its output is a real no-show probability (see the Brier scores and the calibration chart). Risk tiers: **high** ≥ the validation F1 threshold, **medium** ≥ the training no-show rate, otherwise **low**.

## Part 2: Time forecasting (weekly totals)

**Data:** `AGENDE_appointment_history.csv` → 104 complete Monday–Sunday weeks (01/02/2023 – 12/29/2024), built with the same code the system uses. Targets: appointments per week (mean 575) and did-not-attend per week (mean 41.5).

**Evaluation: walk-forward (rolling origin).** At every origin a model sees only earlier weeks and forecasts the next 4 weeks (AGENDE's horizon); errors over all origins and horizons are averaged. Weeks 1–62 are history only; origins in weeks 63–83 are the **validation** set (tuning and choice); weeks 84–104 are the **test** set.

### 2.1 Baselines and tuned candidates

| Model | Type | Grid size | Appointments: best settings | No-shows: best settings |
|---|---|---:|---|---|
| Baseline: naive (last week repeated) | baseline | 1 | - | - |
| Baseline: historical mean | baseline | 1 | - | - |
| Baseline: seasonal naive (same week last year) | baseline | 1 | - | - |
| Linear regression trend, all weeks (blueprint 3.1 model) | baseline | 1 | {'window': None} | {'window': None} |
| Moving average | tuned | 9 | {'window': 52} | {'window': 12} |
| Linear regression trend, tuned training window | tuned | 6 | {'window': 26} | {'window': 78} |
| Simple exponential smoothing | tuned | 8 | {'alpha': 0.02} | {'alpha': 0.1} |
| Holt's linear trend (damped) | tuned | 64 | {'alpha': 0.05, 'beta': 0.01, 'phi': 0.8} | {'alpha': 0.05, 'beta': 0.1, 'phi': 0.98} |
| Ridge autoregression (lags + trend) | tuned | 50 | {'p': 1, 'alpha': 1000, 'trend': False} | {'p': 8, 'alpha': 1000, 'trend': True} |
| Gradient boosting on lags | tuned | 48 | {'p': 13, 'learning_rate': 0.03, 'max_iter': 50, 'max_leaf_nodes': 4, 'trend': False} | {'p': 13, 'learning_rate': 0.03, 'max_iter': 50, 'max_leaf_nodes': 4, 'trend': True} |

### 2.2 Leaderboard

**Appointments per week** (errors in appointments per week)

| Model | Val MAE | Val RMSE | Test MAE | Test RMSE | Test MAPE | Test MAE 1 week ahead | 4 weeks ahead |
|---|---:|---:|---:|---:|---:|---:|---:|
| Simple exponential smoothing | 17.82 | 21.68 | 17.08 | 20.04 | 3.0% | 17.55 | 16.19 |
| **Moving average** | 17.83 | 21.18 | 16.33 | 19.79 | 2.8% | 16.70 | 15.83 |
| Baseline: historical mean | 18.07 | 21.51 | 16.54 | 19.64 | 2.9% | 16.87 | 15.84 |
| Ridge autoregression (lags + trend) | 18.11 | 21.56 | 16.52 | 19.64 | 2.9% | 16.87 | 15.82 |
| Holt's linear trend (damped) | 18.35 | 22.06 | 16.58 | 20.12 | 2.9% | 16.66 | 16.08 |
| Linear regression trend, tuned training window | 18.46 | 23.28 | 19.01 | 23.84 | 3.3% | 18.34 | 19.01 |
| Linear regression trend, all weeks (blueprint 3.1 model) | 18.52 | 22.27 | 16.49 | 20.11 | 2.9% | 16.56 | 16.04 |
| Gradient boosting on lags | 19.34 | 23.48 | 15.72 | 18.48 | 2.7% | 16.08 | 15.25 |
| Baseline: seasonal naive (same week last year) | 22.10 | 29.20 | 24.38 | 30.07 | 4.2% | 24.67 | 23.33 |
| Baseline: naive (last week repeated) | 24.32 | 30.51 | 22.44 | 27.14 | 3.9% | 22.05 | 21.50 |

**Did not attend per week** (errors in no-shows per week)

| Model | Val MAE | Val RMSE | Test MAE | Test RMSE | Test MAPE | Test MAE 1 week ahead | 4 weeks ahead |
|---|---:|---:|---:|---:|---:|---:|---:|
| Ridge autoregression (lags + trend) | 5.32 | 7.40 | 6.55 | 7.93 | 13.9% | 7.41 | 5.92 |
| Holt's linear trend (damped) | 5.90 | 7.88 | 5.95 | 7.37 | 12.6% | 6.21 | 5.92 |
| Linear regression trend, all weeks (blueprint 3.1 model) | 5.91 | 7.96 | 5.71 | 7.24 | 12.1% | 6.04 | 5.61 |
| Linear regression trend, tuned training window | 5.92 | 7.97 | 5.97 | 7.36 | 12.7% | 6.22 | 5.92 |
| **Moving average** | 5.98 | 8.26 | 6.26 | 7.61 | 13.3% | 6.58 | 6.28 |
| Gradient boosting on lags | 6.19 | 8.67 | 6.40 | 8.12 | 13.6% | 6.71 | 6.25 |
| Simple exponential smoothing | 6.35 | 8.60 | 6.04 | 7.52 | 12.8% | 6.20 | 6.15 |
| Baseline: historical mean | 7.42 | 9.79 | 7.44 | 9.52 | 15.8% | 7.60 | 7.21 |
| Baseline: naive (last week repeated) | 8.97 | 11.50 | 8.33 | 10.39 | 17.7% | 9.62 | 8.67 |
| Baseline: seasonal naive (same week last year) | 11.83 | 14.02 | 10.53 | 12.63 | 22.3% | 10.52 | 10.56 |

### 2.3 Selection

One model family is chosen for both targets. Score = average over the two targets of (validation MAE ÷ naive validation MAE). The best-scoring family is compared with every other one by a block bootstrap over validation origins (4,000 resamples). Among the families that are not significantly worse, the **simplest** wins.

| Model | Relative score (val) | Δ vs best | 95% interval | Tied with best? |
|---|---:|---:|---|---|
| Ridge autoregression (lags + trend) | 0.647 | +0.000 | (+0.000, +0.000) | yes |
| Moving average ← chosen | 0.669 | +0.022 | (-0.019, +0.059) | yes |
| Holt's linear trend (damped) | 0.677 | +0.030 | (+0.004, +0.054) | no |
| Linear regression trend, all weeks (blueprint 3.1 model) | 0.681 | +0.034 | (+0.009, +0.056) | no |
| Linear regression trend, tuned training window | 0.682 | +0.035 | (-0.011, +0.083) | yes |
| Simple exponential smoothing | 0.685 | +0.038 | (-0.021, +0.092) | yes |
| Gradient boosting on lags | 0.721 | +0.074 | (-0.002, +0.139) | yes |
| Baseline: historical mean | 0.760 | +0.113 | (+0.046, +0.173) | no |
| Baseline: naive (last week repeated) | 0.969 | +0.322 | (+0.162, +0.490) | no |
| Baseline: seasonal naive (same week last year) | 1.111 | +0.464 | (+0.371, +0.557) | no |

**Result:** Ridge autoregression (lags + trend) scored best on validation, but **Moving average** is statistically tied with it and simpler, so it is selected. On the test weeks its relative error is 0.740 versus 0.761 for Ridge autoregression (lags + trend) (the validation winner overfitted). The best test score was Linear regression trend, all weeks (blueprint 3.1 model) (0.710); choosing it would mean using the test set to choose, which the protocol does not allow.

**Interpretation:**

* **Appointments per week** are close to random noise around a stable level (no seasonality: the same week last year is the *worst* forecast). The best forecast is essentially a long-run average, and all sensible methods are within about 1 appointment per week of each other.
* **No-shows per week** drift upward. A 12-week average follows the level; trend models (Holt, linear) follow it slightly better on the test weeks, but the difference is not significant on validation.
* **All selected forecasts beat the naive baselines clearly.** The current system model (blueprint linear trend) is competitive. Replacing it changes accuracy by well under one appointment per week, so keeping it for blueprint consistency is defensible.

**Exported:** `research/ml/models/timeseries_model.json` holds the chosen family, the per-target settings, the metrics and the next 4 weeks after the data:

| Week starting | Appointments | Did not attend |
|---|---:|---:|
| 2024-12-30 | 575 ± 16 | 47 ± 6 |
| 2025-01-06 | 575 ± 16 | 47 ± 6 |
| 2025-01-13 | 575 ± 16 | 47 ± 6 |
| 2025-01-20 | 575 ± 16 | 47 ± 6 |

![ms_noshow_pr_curves.png](img/ms_noshow_pr_curves.png)

![ms_noshow_calibration.png](img/ms_noshow_calibration.png)

![ms_noshow_importance.png](img/ms_noshow_importance.png)

![ms_forecast_leaderboard.png](img/ms_forecast_leaderboard.png)

![ms_forecast_test.png](img/ms_forecast_test.png)

## Limitations and responsible use

* **Moderate predictive power.** A ROC-AUC around 0.75 is useful for ranking (whom to remind first), not for certainty. Most flagged clients will still attend.
* **Advisory use only.** Never auto-cancel, reject, deprioritize or overbook because of a score. Show it to staff with its meaning.
* **Fairness.** The full-feature model uses age and sex. The AGENDE feature set excludes both, which is preferable for deployment.
* **Transfer.** The dataset is synthetic historical data from other organizations. Models must be re-trained and re-validated on the partner organization's own records before their numbers are cited as AGENDE results.
* **Drift.** The no-show rate rises over time, so retrain regularly and monitor precision and recall.
* **Small forecasting test.** 21 test weeks: differences of a few percent between forecasting methods are within noise.
* LightGBM / XGBoost could not be installed in the build environment; scikit-learn's HistGradientBoosting (the same algorithm family) was used.

## Reproduce

```bash
python -m pip install -r research/requirements.txt
python research/model_selection.py data/AGENDE_dataset_package.zip
```
