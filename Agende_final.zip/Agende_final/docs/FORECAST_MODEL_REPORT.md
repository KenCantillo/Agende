# AGENDE Forecast Model: CRISP-DM Modeling Report

_Generated October 23, 2026 by `research/forecast_experiment.py` from `AGENDE_appointment_history.csv`. Every number below is reproduced by running the tool again on the same file._

The forecasting component follows blueprint sections 15 (linear regression forecasting) and 16 (CRISP-DM). It estimates **aggregate weekly totals**: the number of appointments and the number of did-not-attend (no-show) cases per week. It does not predict whether any individual client will attend (assumptions A-011 and A-012).

## 1. Business understanding

Administrators need a planning estimate of next weeks' demand (staffing, opening hours) and of expected missed appointments (reminder effort, overbooking policy). Success criterion for deployment: a model that is trained only on enough history, evaluated on unseen later weeks, reports its error honestly, and never shows impossible (negative) counts.

## 2. Data understanding

| Item | Value |
|---|---|
| Records | 60,000 |
| Columns | 26 (appointment_id, appointment_date, appointment_time, appointment_duration, patient_id, sex, ...) |
| Appointment dates | 01/01/2023 to 12/31/2024 |
| Duplicate appointment IDs | 0 |
| Missing appointment dates | 0 |
| Rows not usable (unknown status / no date) | 0 |
| Status `completed` | 45,980 (76.6%) |
| Status `cancelled` | 9,683 (16.1%) |
| Status `no_show` | 4,337 (7.2%) |

Patient details (sex, age, patient ID) are not needed for aggregate forecasting and are not imported into AGENDE (blueprint section 40, separation of data layers).

## 3. Data preparation

1. Each record is counted on its appointment date by status (completed, cancelled, no_show).
2. Days are grouped into Monday-Sunday weeks. Only **complete weeks** inside the data coverage are kept (a partial first or last week would look like a sudden drop). Weeks inside the coverage with no records count as 0.
3. Each week gets a sequential number X = 1, 2, 3 ... (the model's only feature).

Result: **104 complete weeks** (01/02/2023 to 12/29/2024), saved as `forecast_dataset_weekly.csv` (the blueprint's forecasting dataset).

| Weekly count | Mean | SD | Min | Median | Max |
|---|---:|---:|---:|---:|---:|
| Appointments | 575.0 | 23.4 | 480 | 575.5 | 635 |
| Did not attend | 41.5 | 8.4 | 18 | 41.0 | 66 |
| Completed | 440.8 | 27.0 | 364 | 440.5 | 494 |
| Cancelled | 92.7 | 16.6 | 63 | 91.5 | 144 |

## 4. Modeling

Two separate simple linear regressions (blueprint 15.2, BR-033), fitted by ordinary least squares:

```text
Model 1:  appointments per week   Y = b0 + b1 * X
Model 2:  did-not-attend per week Y = b0 + b1 * X        X = week number
b1 = sum((x - mean_x)(y - mean_y)) / sum((x - mean_x)^2),   b0 = mean_y - b1 * mean_x
```

Final models (refit on all weeks, the version that is deployed):

| Model | Equation | Slope per week | Std. error | t | p (two-sided) | Trend |
|---|---|---:|---:|---:|---:|---|
| 1 Appointments | Y = 572.972 + 0.0386·X | +0.0386 | 0.0767 | 0.50 | 0.6143 | no significant trend (flat) |
| 2 Did not attend | Y = 34.312 + 0.1373·X | +0.1373 | 0.0239 | 5.73 | <0.0001 | significant rising |

_p-values use the normal approximation to the t distribution (n > 100 weeks, so the difference is negligible)._

**Cross-check:** the same coefficients were computed with scikit-learn `LinearRegression`; the largest difference was 3.47e-17, so AGENDE's built-in OLS (no external library) is numerically identical.

## 5. Evaluation

### 5.1 Chronological train/test split (blueprint 15.8)

First 83 weeks train, last 21 weeks test (from 08/05/2024). Never shuffled, so no future week is used for training (TC040). Metrics use the raw, unclamped predictions.

**Model 1: appointments** (test-week mean: 577.5 appointments/week)

| Candidate | MAE | RMSE | R² |
|---|---:|---:|---:|
| **Trend  Y = b0 + b1*week  (blueprint 15.4/15.5)** | 16.63 | 20.72 | -0.009 |
| Baseline: average training week | 16.91 | 20.85 | -0.023 |
| Baseline: average of last 8 training weeks | 16.39 | 21.55 | -0.093 |
| Baseline: last training week repeated | 18.43 | 22.69 | -0.211 |
| Trend + previous-week count (15.6, one step ahead) | 16.80 | 20.79 | -0.016 |
| Trend + month of year (15.6) | 17.75 | 22.52 | -0.193 |

**Model 2: did not attend** (test-week mean: 47.1 cases/week)

| Candidate | MAE | RMSE | R² |
|---|---:|---:|---:|
| **Trend  Y = b0 + b1*week  (blueprint 15.4/15.5)** | 5.89 | 7.54 | 0.008 |
| Baseline: average training week | 7.99 | 10.30 | -0.852 |
| Baseline: average of last 8 training weeks | 6.18 | 7.61 | -0.009 |
| Baseline: last training week repeated | 6.62 | 8.18 | -0.167 |
| Trend + previous-week count (15.6, one step ahead) | 6.46 | 8.18 | -0.168 |
| Trend + month of year (15.6) | 8.15 | 9.26 | -0.497 |

### 5.2 Interpretation

* **Appointments.** The test MAE is 16.6 appointments per week, about 2.9% of a typical week. Weekly volume has no significant linear trend (p = 0.61), so the line is almost flat and performs about the same as always predicting the average week (1.7% lower error than that baseline; a moving average of the last 8 weeks reaches MAE 16.4 but a higher RMSE, a difference well inside week-to-week noise). R² on the test weeks is close to 0 because there is little variation for any model to explain, not because the forecasts are far off. In practice the model says: plan for about 577 appointments a week, give or take 17.
* **Did not attend.** Missed appointments rise by about 0.14 cases per week (p < 0.0001). The trend model's test MAE is 5.9 cases (12.5% of a typical week), 26.3% lower than the average-week baseline, so the regression adds real planning information here.
* **Extra features (blueprint 15.6).** Adding the previous week's count or the month of year did not lower the test error for either target, so the MVP keeps the single-feature model Y = b0 + b1·X, as the blueprint recommends.
* MAE is the headline metric (easy to explain: "on average, how many appointments away is the forecast"); RMSE and R² are supporting metrics (blueprint 15.9).

### 5.3 Minimum history experiment (blueprint A-010 and 15.11)

Question: how many weeks of history must exist before a model is trained? Method: rolling-origin evaluation over 49 forecast origins (weeks 53 to 100). At each origin the model is trained on only the most recent k weeks and forecasts the next 4 weeks; the absolute errors are averaged. Rule: the smallest k whose error is within 10% of the error with 52 weeks.

| Weeks of history (k) | 4 | 6 | 8 | 10 | 12 | 16 | 20 | 26 | 32 | 39 | 52 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| Appointments MAE | 33.41 | 28.45 | 23.80 | 22.61 | 22.58 | 23.18 | 21.62 | **19.06** | 19.42 | 19.55 | 18.77 |
| Did-not-attend MAE | 13.07 | 11.57 | 10.42 | 9.10 | 8.34 | 6.99 | 7.32 | **6.83** | 6.88 | 6.56 | 6.34 |

Result: appointments stabilise at **26 weeks**, did-not-attend at **26 weeks**. With 8 weeks (the earlier default) errors were 27% and 64% higher. AGENDE therefore uses **26 complete weeks** as the default minimum (`forecast_min_weeks`, adjustable in Settings). Below it the Forecast page shows "Insufficient historical data" and no model is trained (BR-031, TC043).

![forecast_appointments.png](img/forecast_appointments.png)

![forecast_no_shows.png](img/forecast_no_shows.png)

![minimum_weeks.png](img/minimum_weeks.png)

## 6. Deployment

| Item | Implementation in AGENDE 3.1 |
|---|---|
| Model store | `forecast_models` (one row per model; the pair shares a version label such as FM-0007) and `forecast_results` (predictions, raw and displayed). |
| Deploy | Forecast page, **Train & deploy**, or `python -m flask --app app train-forecast`. The new pair becomes the single active model; older versions can be re-activated. |
| Use | Dashboard and Forecast page read the active model's b0/b1 and compute X for this week from the model's week-1 date, with no retraining on page views. |
| Negative values | Displayed as max(0, round(prediction)); the raw prediction is stored and exported (BR-035, TC042). |
| Retraining | Housekeeping retrains and deploys automatically when a new complete week of live records exists and at least the minimum number of weeks is available (`forecast_auto_retrain`). Admins are notified. |
| Out-of-date guard | A model is not used for forecasts more than 8 weeks past its data; the dashboard asks for retraining instead. |
| Monitoring | After deployment, each new complete week is compared with the model's prediction (live MAE on the Forecast page and in R007). |
| Model file | `forecast_model.json` (this experiment) and the **Model file** button (active model). |

Model trained on this dataset (all 104 weeks):

```text
Appointments:    Y = 572.9718 + 0.0386 * X     test MAE 16.63  RMSE 20.72  R2 -0.009
Did not attend:  Y = 34.3122 + 0.1373 * X     test MAE 5.89  RMSE 7.54  R2 0.008
Week 1 = 01/02/2023
```

| Forecast week (after the data) | Appointments | Did not attend |
|---|---:|---:|
| 12/30/2024 | 577 ± 17 | 49 ± 6 |
| 01/06/2025 | 577 ± 17 | 49 ± 6 |
| 01/13/2025 | 577 ± 17 | 49 ± 6 |
| 01/20/2025 | 577 ± 17 | 49 ± 6 |

The imported dataset comes from a different organization and ends in December 2024, so in production the model is **retrained on AGENDE's own records** once enough weeks exist. The dataset model demonstrates and validates the method; it is not meant to forecast the partner organization's current weeks.

## 7. Limitations

* A straight line cannot capture seasonality, holidays, organizational events, service changes or staff availability (blueprint 15.12). The forecast is a planning aid, not a guaranteed value (BR-034).
* A rising no-show trend should not be extended far into the future; that is why forecasts stop being shown 8 weeks after the training data and the model is retrained weekly.
* Results describe the historical dataset. They must be re-checked on the partner organization's data during Phase 6.

## 8. Reproduce

```bash
python research/forecast_experiment.py AGENDE_appointment_history.csv       # this report
python -m flask --app app train-forecast --csv AGENDE_appointment_history.csv # import + train + deploy in AGENDE
python -m unittest discover -s tests -v                                      # includes the forecast tests
```
