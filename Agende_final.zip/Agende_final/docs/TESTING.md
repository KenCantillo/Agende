# Testing AGENDE 3.2

## Running the automated tests

```bash
python -m unittest discover -s tests -v
```

- `tests/test_rules.py` needs no database.
- `tests/test_integration.py` connects with the MySQL settings in `agende/config.py` (or `AGENDE_DB_*` environment variables). It **drops and recreates a separate database named `agende_test`** (override with `AGENDE_TEST_DB`), so `agende_db` is never touched. If MySQL is unreachable, those tests are skipped.

Result at hand-over: **99 tests, all passing** (32 rule tests + 57 end-to-end + 10 model tests in `tests/test_models.py`; the model-study tests skip themselves if pandas/scikit-learn are not installed), also on the pinned Flask 3.0.3 / Werkzeug 3.0.3. Re-run on your own MySQL 8 / MariaDB server and record the result with date and environment, as §34 requires recorded results.

## Blueprint test cases (§34) → how each is covered

| TC | Test | Covered by |
|---|---|---|
| TC001–TC004 | Login, wrong password, duplicate email, logout | `T1_Authentication` |
| TC005 | Update profile | `test_TC005_profile_and_password` |
| TC006 | View services | Manual: open **Services** as a client |
| TC007–TC008 | Admin creates / updates a service | Manual: Admin → Services → Add / Edit |
| TC009 | Deactivated service not bookable | `test_TC009_inactive_service` |
| TC010–TC011 | Available dates / time slots | `test_slots_api` |
| TC012 | Outside working hours / break | `test_TC012_outside_hours_and_break`, rule tests |
| TC013 | Blocked time | `test_TC047_block_time_flags_existing`, `test_blocked_period_TC013` |
| TC014–TC016 | Valid booking, missing field, past date/time | `T2_Booking` |
| TC017–TC019 | Staff overlap, adjacent allowed, client overlap | `T2_Booking`, rule tests |
| TC020 | Simultaneous booking: only one succeeds | `test_TC020_simultaneous_booking` (3 parallel requests) |
| TC021–TC028 | Approve, reject, reschedule, cancel, cutoff, complete, did not attend | `T3_Workflow` |
| TC029–TC031 | Booking / approval / cancellation notifications | asserted in TC014, TC021, TC025 tests |
| TC032 | Reminder | `test_TC032_reminders_and_expiry` |
| TC033–TC037 | KPI counts, no-show formula, date/service/staff filters | `T6_…`, `test_rates_TC034` |
| TC038–TC043 | Weekly aggregation, training, chronological split, forecast, negative clamp, insufficient data | `Forecasting` rule tests + `test_TC043_TC053_forecast_with_history` |
| TC039, TC041 (3.1) | Train & deploy, versions, rollback, model file, prediction from saved coefficients, automatic retraining, CLI training, baseline, scikit-learn cross-check | `T9_ForecastModel` (4 tests) + `test_baseline_comparison`, `test_saved_model_predicts_any_week`, `test_matches_scikit_learn`, `test_dataset_csv_parsing` |
| TC044–TC045 | Admin creates user / deactivation blocks login | `test_TC044_TC045_…` |
| TC046–TC047 | Staff schedule / block time | `T5_AdminAndSecurity` |
| TC048 | Audit log created | asserted in TC002 and TC045 tests |
| TC049–TC051 | Unauthorized access, SQL injection, XSS | `T5_AdminAndSecurity` |
| TC052–TC053 | Appointment and forecast reports | `T6_…` |
| TC054 | Booking rule applied (buffer) | `test_TC054_setting_applied` |
| TC055 | Failed transaction leaves nothing | `test_TC055_failed_transaction_leaves_nothing` |

## Manual checks before UMUX (§35)

1. Open each role's screens on the actual devices respondents will use (phone + PC), in Chrome and one other browser.
2. Walk through the §35 task lists for Client, Staff and Administrator.
3. Use `python tools/seed_demo_data.py` **only for development**. For the evaluation, use a fresh database with realistic but non-personal test accounts. Demo records are marked `[demo]` and are illustrative, not study data.
4. Record UMUX responses exactly as given. Never fill in or estimate scores.

## Forecasting validation (Phase 6, item 8)

1. `python -m flask --app app train-forecast --csv AGENDE_appointment_history.csv` and record the printed coefficients and MAE / RMSE / R² for both models.
2. Compare them with `docs/FORECAST_MODEL_REPORT.md` (they must match: appointments Y = 572.9718 + 0.0386·X, test MAE 16.63; did not attend Y = 34.3122 + 0.1373·X, test MAE 5.89).
3. Open Forecast: check that the active version, training period, metrics and the "Out of date" notice (2024 data) are shown, then export R007 (deployed).
4. After 26+ weeks of real records, run `python -m flask --app app housekeeping` and confirm a new automatic version appears and admins get "Forecast model updated".

## No-show risk and staff forecasts (3.2)

`T9b_NoShowRiskAndStaffForecast` checks:
- the service category is saved, and an invalid one is refused;
- the risk inputs are built correctly from AGENDE's own tables;
- staff and admins see the risk, clients never do (lists, dashboard, appointment page);
- the setting turns it off;
- a missing model file switches the feature off without errors;
- each staff member's forecast uses only their own records;
- the admin Forecast page shows the breakdown by staff and service.

Manual check: open an upcoming appointment as staff and confirm the "Raises / Lowers the risk" reasons match the client's history.

