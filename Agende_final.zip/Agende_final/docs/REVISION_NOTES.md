# AGENDE 3.0 — Major Revision, Phase by Phase

Baseline: **AGENDE 2.1** (the uploaded zip).
Reference: *AGENDÉ — Complete System Analysis and Implementation Blueprint* (§43 development phases) and the *Dashboard Design Master Prompt*.

Each phase lists what 2.1 already had, what the blueprint still required, what 3.0 changes, and what the team still has to do itself.

**Verification of this revision:** 78 automated tests (28 rule tests + 50 end-to-end tests against a MySQL-compatible server) all pass. They also pass with the exact pinned versions in `requirements.txt` (Flask 3.0.3, Werkzeug 3.0.3, PyMySQL 1.1.1). Every page was opened for all three roles with no server errors, and the main screens were checked at desktop (1440 px) and phone (390 px) widths with no JavaScript errors or sideways scrolling. The `upgrade_to_v3.sql` path was tested on a database built from the 2.1 `schema.sql` + `seed.sql`.

---

## Phase 1 — Foundation

**2.1 had:** login, register, logout, hashed passwords, three roles with `role_required`, a profile page, admin pages for clients, providers and users, and service create/edit/deactivate.

**Gaps against the blueprint**

| Gap | Blueprint ref |
|---|---|
| No CSRF protection on any form (cookie sessions) | §32 |
| No session expiry; no new session on login; logout by GET | §32 |
| Weak validation: any password, no email/phone format check; a password could be changed without the current one | §27, F009 |
| A deactivated user stayed logged in until logout | BR-026 |
| No forgot/reset password | F010, S04, S05 |
| Admin could not create client/admin accounts or change roles | F011, F090, BR-025 |
| One service per staff member (`providers.service_id`) | §18.6 `staff_services`, F019 |
| `system_settings` table existed but was unused; no settings screen | F043, F091, S39 |
| Every route in one 2,349-line `app.py` | NFR-006 |

**3.0 changes**
- `security.py`: a CSRF token on every POST form, a password policy (8+ characters, letter and number), email/phone/name validation, and safe redirects.
- Sessions: 2-hour lifetime, HttpOnly and SameSite cookies, a new session on login, POST-only logout, security headers.
- A deactivated account, or one whose role changed, is signed out on its next request. The last active administrator cannot be deactivated.
- Password reset: one-time hashed tokens valid for 1 hour. The link is emailed when SMTP is configured. Otherwise the admins are notified and an admin generates the link from Users & Roles.
- Users & Roles: create client/admin accounts, switch Client ↔ Administrator, activate/deactivate, generate reset links, filter, paginate.
- **`provider_services`**: staff can offer several services. The Staff form has service checkboxes, and booking enforces BR-003.
- **Settings screen (S39)** for 10 typed rules: minimum notice, booking window, slot spacing, buffer, cancellation cutoff, reason required, reminder timing, pending expiry, minimum forecast weeks, forecast horizon.
- Code split into modules (NFR-006): `routes_auth / routes_client / routes_staff / routes_admin / routes_shared` plus `scheduling, appointments, notifications, analytics, forecasting, audit, settings_store, security`. Routes still use the familiar plain `@app.route` style.
- `database.db_cursor()` opens one explicit transaction per block: commit on success, full rollback on any error.

**Still for the team:** validating requirements with the real stakeholder organization (Phase 1, item 1); setting `AGENDE_SECRET_KEY` before deployment.

---

## Phase 2 — Core Appointment System

**2.1 had:** free-text date and time booking, overlap checks for provider and client, blocked periods, approve/reject/complete/no-show/cancel, client reschedule, status history.

**Gaps against the blueprint**

| Gap | Blueprint ref |
|---|---|
| **Past times on today's date could be booked.** Confirmed in 2.1: an 08:00 booking was accepted at 10:45 | BR-009 |
| No slot generation; clients guessed times | F022, F023, F044, S11 |
| Check-then-insert in separate connections, so two people could take the same slot | TC020, §9 step 7 |
| Admin could set **any** status from any status (e.g. Completed → Pending) | §4.2, BR-015/016 |
| Completed / no-show could be recorded for **future** appointments | §4.3 |
| Cancel/reject had no reason; no cancellation cutoff | S16, BR-012/013 |
| Reschedule notified only the client; staff and admin could not reschedule | F036, N005 |
| Client cancellations did not notify staff | N006 |
| Weekly windows could overlap; no delete; schedule changes silently stranded bookings | S24, BR-021/022 |
| Admin could not block time; staff/admin had no appointment detail page | S32, S23, S34 |

**3.0 changes**
- **Slot engine** (`scheduling.generate_slots`) implements §11: working windows − breaks (gaps between windows) − blocked time − active bookings (± buffer) − minimum notice − booking window. Each slot is labelled available, booked, blocked, past, or clashing with the client's other booking.
- **Booking wizard** (S07–S12 in one screen): service cards → staff cards → month calendar showing open-slot counts → time chips → review. It is backed by `/api/available-dates` and `/api/slots`. Admins can book on a client's behalf; those bookings are confirmed immediately.
- **One source of truth for validation:** the server rebuilds the day's slots and accepts only a slot marked available, so the checklist in §10.3 is enforced in one place.
- **Double-booking protection:** each booking takes a named lock per staff member and per client (`GET_LOCK`), starts a fresh transaction, then takes row locks before re-validating. Tested with three simultaneous requests for one slot: exactly one succeeds.
- **State machine:** only §4.2 transitions are allowed. Completed / Did not attend can be recorded only after the start time. Terminal statuses are final. The optional **Expired** status is implemented for unanswered requests whose start time passes.
- Reasons are required to reject, required to cancel (client requirement configurable), and required for staff/admin reschedules. They are stored in `cancellation_reason` / `rejection_reason` / `cancelled_by` and in the status history.
- Client cancel/reschedule closes at the configurable cutoff (default 2 h). Staff and admins can still act, with a reason. A client reschedule returns the booking to Pending for re-approval; staff/admin reschedules keep the status. Reschedules are counted and shown with a "Rescheduled" badge.
- Schedules: overlapping windows are rejected; windows can be deleted. After any hours or blocked-time change, affected upcoming bookings are **kept**, listed under "Needs attention", and their clients get N011.
- Admin Schedules page: per-staff hours, blocked time, a coverage grid, and affected bookings.
- One appointment detail page for all roles, showing the full status history (who, when, why) and role-appropriate actions through a shared confirmation dialog.

**Still for the team:** confirm the default rules with the organization (60-minute notice, 2-hour cutoff, 30-minute slot spacing, no buffer).

---

## Phase 3 — Monitoring & Notifications

**2.1 had:** three dashboards (KPI cards, Gantt timeline, lists), plain-text notifications for clients and staff, and an audit table used in a few places.

**Gaps:** admins had no notifications page (S40); no reminders (N007/N008, F061, TC032); notifications had no title or link; the conflict alert matched identical start times only; audit coverage was thin (no logins, approvals, schedule changes or settings); no audit filters (F093). The dashboards did not follow the new design brief.

**3.0 changes**
- **Notifications for every role**, with title, event code (N001–N012), and a link to the appointment. Header bell with unread count and a latest-five dropdown; mark one/all read; All/Unread filter. Admins can send **announcements (N012)** to a role group.
- **Housekeeping job:** creates N007 (configurable hours before) and N008 (same-day) reminders for client and staff, expires stale pending requests, and sends queued emails. It runs automatically at most once a minute on page loads, and on demand via `flask --app app housekeeping` (Task Scheduler/cron).
- **Optional email (F065):** set `AGENDE_MAIL_*` variables. Failed sends stay queued and retry without affecting the booking.
- **Audit trail** in the same transaction as each change, recording old and new values plus IP. Covers login (including failures), logout, registration, every appointment action, schedule/block changes, users, roles, staff, services, settings, forecasts and report exports. Filters by user, action, entity and dates, with CSV export.
- **Dashboards rebuilt** to the design brief:
  - Admin: welcome/date banner; four KPIs with month-over-month change; a status strip for all seven statuses; 7/30/90-day trend; service donut; recent-appointments table; mini calendar with a Book button; upcoming list; quick actions; weekly overview; staff workload with conflict counts; forecast summary; alerts for conflicts, stranded bookings, unusual cancellation/no-show activity, and insufficient forecast data.
  - Staff: today's agenda with Complete/Did-not-attend actions; pending requests with Approve/Decline; this week's chart; upcoming confirmed; availability; recent cancellations.
  - Client: next-appointment card with allowed actions; upcoming; history; mini calendar; latest updates.
- Conflict detection uses true time-interval overlap.
- Global header search, scoped by role. Client and staff lists gained search by #ID, date range, service, status and sort order (§29).

---

## Phase 4 — Analytics

**2.1 had:** completed and cancelled totals, a six-month trend, a status doughnut whose four fixed colors did not match six statuses, and by-provider and by-service bars.

**Gaps:** no rates (A006–A008), no utilization (A009), no date/service/staff filters (F073–F075), no busiest days or hours, no staff analytics (S27), no exports (F077, R002–R006).

**3.0 changes** (`analytics.py`, one function for admin and staff)
- KPIs use the exact blueprint formulas, consistent everywhere (BR-029): no-show rate = no_show ÷ (completed + no_show); cancellation rate = cancelled ÷ total requests; completion rate = completed ÷ (completed + no_show).
- Staff utilization = booked minutes ÷ scheduled minutes minus blocked time. Service utilization = slots held ÷ potential slots; the page states the upper-bound caveat.
- Filters for date range (quick 7d/30d/90d/1y), service and staff apply to every number and chart (BR-030), with validation (§27).
- Charts: trend that switches automatically between daily, weekly and monthly; status distribution with correct per-status colors; staff workload stacked by status; busiest weekdays; weekday × hour **heatmap**; tables for service and staff utilization; formula definitions on the page.
- **Staff analytics (S27)** shows only the staff member's own records; any other staff filter is rejected.
- **Reports page:** R001–R007 CSV downloads, all honoring the chosen filters.

---

## Phase 5 — Forecasting

**2.1 had:** OLS on weekly counts with an 80/20 split and MAE/RMSE/R², a table of four weeks, and an 8-week minimum.

**Methodology problems in 2.1, now fixed**
1. **Gap weeks were skipped,** so week numbers (X) were unevenly spaced. 3.0 fills empty weeks inside the data period with zeros.
2. **Incomplete weeks were included**, including the current week and future weeks holding scheduled bookings. 3.0 uses only complete Monday–Sunday weeks; partial first and last weeks are dropped.
3. **Evaluation used clamped predictions.** 3.0 evaluates raw predictions and clamps only for display. Raw values are kept and stored (§15.10).
4. Nothing was stored or visualized (F086, F088). 3.0 adds both.

**3.0 changes** (`forecasting.py`, every formula visible, no ML library)
- Chart per model: actual (solid), fitted line, forecast (dashed cyan) and a shaded test period. Shows equation `Y = b0 + b1·X`, MAE/RMSE/R² on the test weeks, training R² as supporting information, and a plain-language trend sentence.
- Shows data sufficiency, model data period, the split date (BR-036) and an "aggregate, not individual" statement (A-011/A-012). Warns about long runs of zero weeks.
- Options: data source, training window, horizon (1–26 weeks). Minimum weeks and horizon are settings (§15.11).
- **Save forecast** writes `forecast_models` + `forecast_results` and lists saved runs. **R007** export includes coefficients, metrics, history and raw predictions.
- **Dataset import:** `tools/import_dataset_history.py` loads `AGENDE_appointment_history.csv` (60,000 rows, 2023–2024) into a separate `historical_appointments` table that only forecasting reads (§40 data layers). No patient details are imported, and no fake user accounts are created.

**Finding the team should know for the defense:** on the imported dataset (104 complete weeks) the appointment trend is nearly flat (slope ≈ 0.04 per week). Test MAE is about 16.6 appointments on roughly 575 per week (≈3%), and test R² ≈ 0. Present MAE/RMSE as the main evidence. A near-zero R² here means time alone explains little week-to-week variation; it does not mean the forecast is unusable. That is exactly the "supporting metric only" caution in §15.9.

**Still for the team:** decide the minimum number of weeks experimentally (§15.11, currently 8); write the CRISP-DM evaluation narrative using your own run.

---

## Phase 6 — Testing & Evaluation

**2.1 had:** no tests.

**3.0 changes**
- `tests/test_rules.py`: 28 tests of the pure rules (overlap, adjacency, buffer, breaks, blocked time, past times, client clash, lifecycle, KPI formulas, OLS, chronological split, negative clamp, insufficient data, validation).
- `tests/test_integration.py`: 40 end-to-end tests through the real app on a throw-away `agende_test` database. They cover TC001–TC005, TC009, TC012–TC055 where automatable, plus CSRF, ownership, the password-reset flow and the last-admin rule. See `docs/TESTING.md` for the mapping.
- Run both with `python -m unittest discover -s tests -v`. No extra packages are needed.

**Still for the team (cannot be automated):** record actual execution results on your own MySQL server (§34 says results must be recorded); manual browser checks on the phones and PCs respondents will use; the UMUX task walkthrough and questionnaire (§35), which must not be filled with invented scores.

---

## Design system (Dashboard Design Master Prompt)

- Exact palette tokens (Midnight Navy → Deep Ocean → Royal → Electric Blue, Cyan-Teal accent, #F3F7FD background) and the gradients specified for brand, active and sidebar.
- Glass only on the header, KPI cards, banner and overlays (white at 80–88%, 14 px blur); tables and forms stay solid. Text is never translucent.
- 232 px sidebar that collapses to icons (remembered per browser), 64 px header with search, bell and role label, 22 px padding, 16 px gaps, four KPIs per row (two on smaller screens).
- The specified status badge colors, always with an icon and a word (never color alone).
- Inter type scale, 40–44 px controls, 16 px card radius, 10 px button radius.
- Charts: blue gradients for volume, cyan dashed lines for forecasts, neutral gridlines.
- Accessibility: visible focus ring, skip link, labelled controls, `aria-live` on the pickers, reduced-motion and reduced-transparency fallbacks, high-contrast mode, print styles.
- **Libraries are bundled locally** (`static/vendor`: Bootstrap 5.3.3, Bootstrap Icons 1.11.3, Chart.js 4.4.4, Inter), so the system works offline during the defense.
- The 2.1 Gantt month timeline is kept on the Calendar pages, re-skinned. A 2.1 bug is fixed: it ignored the selected month because the macro was imported without context.

## Files

New: `web.py`, `routes_*.py`, `scheduling.py`, `appointments.py`, `notifications.py`, `analytics.py`, `forecasting.py`, `audit.py`, `security.py`, `settings_store.py`, `upgrade_to_v3.sql`, `tools/`, `tests/`, `docs/`, `static/vendor/`, `static/js/booking.js`, and most templates.
Removed: `upgrade_existing_database.sql` (replaced by `upgrade_to_v3.sql`) and the old per-role duplicates of profile, notification and calendar templates (now shared).


---

## 3.0.1 fixes (after first hand-over)

- **Staff login crash fixed** ("TypeError: can only concatenate tuple (not list) to tuple"). PyMySQL returns an empty *tuple* when a query has no rows but a *list* when it has rows. The staff dashboard joined two result lists, so it crashed on any day the staff member had no appointments. `database.DictCursor` now always returns lists, so this cannot happen anywhere else either. The test `T0_RoleDashboards` covers it.
- **No more trapped sessions.** The login page now opens even while signed in, says who is signed in, and lets you log in as another account. Previously a crashed dashboard kept sending you back to itself.
- **Every action reports its outcome.** Success shows a green message. A refused action (no permission, record removed, expired form, busy database) sends you back to the page you were on with a red message, and nothing is saved. Unexpected errors show "Something went wrong and nothing was saved" with an error reference (the full details are printed in the server console) instead of a crash page. Error pages keep the sidebar so you can always navigate or log out. The test `T7_ActionFeedback` checks 25 actions.
- **Database setup problems** (MySQL stopped, wrong password, missing database, 2.1 database not upgraded) show a page naming the fix; `python tools/check_setup.py` diagnoses them from the command line.

## 3.0.2 changes

- **Menu button beside the search bar:** it opens the sidebar on phones and tablets, where the sidebar is hidden. A CSS ordering mistake also showed it on desktop, where it did nothing; it now appears only on small screens.
- **Administrators are notified of schedule changes:**
  - every reschedule, whether requested by a client or made by staff (N005);
  - every change to staff working hours or blocked time, saying what changed, who changed it, and how many booked appointments are affected (N011).
  The admin who makes a change is not notified of their own action. When an admin changes a staff member's schedule, that staff member is notified, and affected clients are notified as before.
- **Approved or declined requests** notify the client **and** the staff member. The wording says whether it was a reschedule request or a new booking, and includes the reason when declined. Admins also hear the outcome of reschedule requests.
- **Appointment lists** (admin, staff, client) are sorted by default with upcoming appointments first, from soonest to farthest (date, then time, then ID), and past appointments after a "Past appointments" divider. An "Appointment ID" sort is also available. Rescheduled appointments keep their "Rescheduled" badge.
- **Dashboard calendars** show a dot for each status on each day: yellow = pending, blue = confirmed, green = completed, red = cancelled/declined, pink = did not attend. There is a legend, and hovering a day shows its breakdown (e.g. "1 pending, 1 cancelled / declined").

## 3.1 — Trained and deployed forecast model (blueprint 15–16, F078–F088)

The model follows the blueprint: two weekly linear-regression models (appointment count and did-not-attend count), Y = b0 + b1·X with X = week number. There is no individual no-show prediction (A-011, A-012). 3.0 computed a forecast each time a page opened; 3.1 adds a full model lifecycle.

**CRISP-DM study** (`tools/forecast_experiment.py` → `docs/FORECAST_MODEL_REPORT.md`, `forecast_dataset_weekly.csv`, `forecast_model.json`, charts), trained on the 60,000-record history dataset (104 complete weeks, 2023–2024):

| Model | Equation | Test MAE | Baseline MAE (average week) | Finding |
|---|---|---:|---:|---|
| Appointments | Y = 572.97 + 0.0386·X | 16.63 (≈2.9% of a week) | 16.91 | flat, no significant trend (p = 0.61) |
| Did not attend | Y = 34.31 + 0.1373·X | 5.89 | 7.99 | rising trend (p < 0.0001), 26% better than baseline |

- The blueprint's 15.6 extra features (previous-week count, month of year) did not reduce test error, so the single-feature model is kept.
- **Minimum history (A-010 / 15.11):** a rolling-origin experiment found errors level off at **26 weeks**; with 8 weeks they were 27% and 64% higher. The `forecast_min_weeks` default is now 26.
- AGENDE's built-in least-squares fit matches scikit-learn to within 1e-16.

**In the system:**
- **Train & deploy** (Forecast page) or `flask --app app train-forecast [--csv file]` saves the pair as a version (FM-0001, FM-0002 …) and makes it the **active model**.
- The dashboard and Forecast page predict from the saved b0/b1 and do not retrain on page views. The dashboard shows "this week (predicted) ± MAE" next to "booked so far".
- Each model is evaluated against a naive baseline, and `training_record_count` is stored (blueprint 18.13).
- **Automatic retraining:** once enough live weeks exist, housekeeping retrains on each new complete week, deploys the result, notifies admins and writes an audit entry. It can be switched off in Settings.
- **Rollback:** any earlier version can be re-activated.
- **Out-of-date guard:** a model is not shown more than 8 weeks past its data.
- **Live monitoring:** each week after training, actual counts are compared with predicted (live MAE).
- **Model file:** the active model can be downloaded as JSON.
- R007 can export the deployed forecast.
- Upgrade 3.0.x with `upgrade_to_v3_1.sql`. `check_setup.py` and the error page detect a database that has not been upgraded.
- Demo seeding now creates 30 weeks of history, so the live model can be trained.
- **Tests:** 86 automated tests, all passing (8 new forecast-model tests).

## 3.1 — Model selection study: no-show prediction and time forecasting

`tools/model_selection.py` → `docs/MODEL_SELECTION_REPORT.md` (charts in `docs/img/ms_*.png`; models in `ml/models/`). Every candidate is compared with baselines, tuned on a **chronological** validation period, and chosen on validation metrics only. The test period is used once, for the final numbers. When a simpler model is statistically tied with the top scorer (bootstrap), the simpler one wins.

| Task | Baselines | Tuned candidates | Selected | Test result |
|---|---|---|---|---|
| **No-show prediction** (per appointment, non-cancelled) | always "attends"; rule "missed before → will miss"; default logistic regression | logistic regression, binned logistic (scorecard), decision tree, random forest, gradient boosting | **Logistic regression** (L1, C = 0.1) | PR-AUC 0.291 (rule 0.142, chance 0.098), ROC-AUC 0.750; flagging the riskiest 20% catches 52% of no-shows |
| …same, with only the features AGENDE records | | | **Logistic regression** (prior-corrected) | PR-AUC 0.271, ROC-AUC 0.726 |
| **Time forecasting** (weekly appointments and no-shows, 1–4 weeks ahead, walk-forward) | naive, mean, seasonal naive, blueprint linear trend | moving average, tuned-window linear trend, simple exponential smoothing, Holt (damped), Ridge autoregression, gradient boosting on lags | **Moving average** (52 weeks for appointments, 12 for no-shows) | MAE 16.3 appointments/week (2.8%) and 6.3 no-shows/week: 27% and 25% better than naive |

- Strongest no-show signal: earlier no-shows (the rate goes from 5.6% with none to 35% with four or more). Then service category, reminders, deposits and booking lead time.
- The blueprint linear trend stays competitive for forecasting (best test score, but not the validation choice), so keeping it in the system is defensible.
- No-show models are exported as plain JSON and scored in pure Python (`ml/noshow_scorer.py`), matching scikit-learn to within 1e-15.
- **Scope note:** using individual no-show prediction in AGENDE changes blueprint A-011 / A-012. It must stay an advisory staff indicator.
- Tests: 95 (9 new in `tests/test_models.py`).

## 3.2 — No-show risk for staff, per-staff forecasts

**What each role sees**

| | Client | Staff | Admin |
|---|---|---|---|
| No-show risk (Low / Medium / High · %) | never | own upcoming appointments: lists, dashboard "Reminder priorities", appointment page with reasons | all upcoming appointments, plus dashboard counts |
| Weekly forecast | – | **My forecast**: their own appointments and did-not-attend, linear regression on their own records (26-week minimum) | organization model (deployed) + **breakdown** by staff and by service |

**No-show risk**
- **Model:** one logistic-regression model for all services (selected in the model study, AGENDE features). Each service's **no-show category** (Services page: Dental, Healthcare, Legal & Financial, Education …) is an input, so the domain is built in. Separate models per domain would each have far less data.
- **Inputs** come only from AGENDE's own tables: lead time, the client's earlier appointments / no-shows / cancellations, first visit with this staff member, the service category, day, time, and bookings that day.
- **Robustness:** history counts are log-scaled and every input is clipped to the training range. This keeps regular clients with long histories from being scored as extreme; demo clients now range from 3% to 41%.
- **Reasons:** shown in plain language ("Missed 4 of 16 earlier appointments", "Attended all 10 earlier visits").
- **Safeguards:** advisory wording everywhere; never shown to clients; never changes a booking; switch-off setting; if the model file is missing the feature turns itself off.
- Scored in pure Python, so **no new packages** are needed.

**Other changes**
- `upgrade_to_v3_2.sql` adds `services.risk_category` (sample services pre-mapped; IT Support has no match and is treated as average) and the `noshow_risk_enabled` setting.
- The demo seeder now creates 150 demo clients, each with their own attendance habit, so histories look realistic.
- The model study was re-run with log-scaled counts. Logistic regression now wins outright on both feature sets: test PR-AUC 0.293 (all features) and 0.275 (AGENDE features).
- **Tests:** 99, all passing.

## 3.2 final — refactor and one-click deployment

**Structure**
- The code is one package, `agende/`. The 1,150-line admin routes file is split into `routes/admin.py` (dashboard,
  appointments, clients), `routes/admin_manage.py` (staff, users, schedules, services, settings) and
  `routes/admin_insights.py` (analytics, forecast, reports, audit logs).
- SQL lives in `database/` (with `upgrades/`), the dataset in `data/`, and the deployed no-show model in `agende/models/`.
- Lint-clean (ruff): unused imports removed, along with one dead compatibility function.

**Settings**
- Settings now live in `.env`, which updates never overwrite. Your MySQL password no longer lives in `config.py`.
- The secret key is generated randomly instead of a fixed default.

**Install, update, back up**
- `install.bat` / `install.sh` creates the environment and installs packages with `python -m pip`, which works where
  `pip.exe` is blocked. It then runs `tools/setup_wizard.py`.
- The wizard asks for the MySQL login, saves `.env`, and creates the database or upgrades an older one automatically
  (2.1 → 3.0 → 3.1 → 3.2, with a backup first). It can also add demo data, train the forecast model, and runs the check.
- `start.bat` / `start.sh` / `python app.py` serves with **waitress** (production server). `--lan` serves
  respondents' devices on the same network and prints the address to share.
- Housekeeping (reminders, expiry, retraining) runs every 5 minutes in the background, so Task Scheduler is no longer
  needed.
- New commands: `backup.bat` / `flask backup-db` (pure-Python SQL backup) and `flask upgrade-db`.
- `app.py` refuses to start against a missing or outdated database, with a clear message.

**Documentation and verification**
- New `DEPLOY.md` covers installation, network use for UMUX sessions, updating, backup/restore and troubleshooting.
- Verified:
  - 99 tests pass;
  - a fresh install via the wizard works, followed by serving on the network;
  - upgrades from real 2.1 and 3.0 databases work;
  - a backup of 65,949 rows restores identically.
- One test used a 9:00 slot that collides with a seed booking whenever the tests run on a Saturday. It was moved to
  14:00; this was a test-data issue, not an app bug.

**Final package (trimmed)**
- The database is **two SQL files**: `database/schema.sql` (every table plus the roles and default settings) and
  `database/seed.sql` (sample accounts, services, schedules, appointments).
- The three upgrade scripts and the automatic-upgrade code are removed. An older database is recreated fresh by the
  installer after a backup (`python tools/setup_wizard.py --reset`).
- Removed `tools/import_dataset_history.py` (superseded by `train-forecast --csv` and the installer),
  `backup.bat`, and the macOS/Linux scripts (manual steps are in `DEPLOY.md`).
- Removed the `install.bat` / `start.bat` helpers: installation is four commands (README / DEPLOY.md section 2).

**Final package: manual installation only**
- No installer or deployment helpers. Setup is manual:
  1. import `database/schema.sql` then `database/seed.sql` in phpMyAdmin;
  2. check the MySQL login in `agende/config.py`;
  3. `python -m pip install -r requirements.txt`;
  4. `python app.py`.
- Removed the setup wizard, setup check, `init_db`, `DEPLOY.md` and `.env.example`. Settings are back in
  `agende/config.py`.
- The model study is grouped in `research/` (`model_selection.py`, `forecast_experiment.py`, `ml/`, `requirements.txt`).
  It is not needed to run AGENDE.
- The tests create their own `agende_test` database directly from the two SQL files.

