AGENDE DATASET PACKAGE
======================

Files
-----
1. AGENDE_no_show_model_dataset.csv
   A 60,000-row model-training dataset for predicting whether an appointment
   will be missed. Target:
     did_not_attend = 1 when the historical outcome was "did not attend"
     did_not_attend = 0 otherwise
   historical_outcome preserves the three-way historical outcome.

   The model dataset intentionally excludes check-in time, actual start/end
   times, waiting time, and actual appointment duration because those values
   are known only during/after the appointment and could leak the outcome.
   Do not use appointment_id as a predictive feature.

2. AGENDE_appointment_history.csv
   Historical appointment records with statuses renamed to AGENDE terminology:
     attended -> completed
     cancelled -> cancelled
     did not attend -> no_show
   In the UI, "no_show" should be displayed as "Did not attend".

3. AGENDE_service_catalog.csv
   Distinct service categories from the dataset, with the most common reason
   listed as an example. The 30-minute default duration is a placeholder and
   should be reviewed by an administrator before use.

Important integration note
--------------------------
These CSVs are not a direct MySQL import for the AGENDE application's
appointments table. That table requires valid user_id, provider_id, and
service_id foreign keys from your own agende_db. The patient_id/provider_id
values in the source dataset are synthetic historical identifiers and are
not automatically mapped to actual AGENDE user/provider accounts.

Recommended use
---------------
- Use AGENDE_no_show_model_dataset.csv for model development and evaluation.
- Use AGENDE_service_catalog.csv as a reference when configuring services.
- Use AGENDE_appointment_history.csv for historical analysis, after checking
  privacy, data quality, and whether importing historical records is needed.

Before deployment, split train/test data chronologically where possible and
evaluate recall, precision, F1, ROC-AUC, and class balance. Predictions should
support staff decisions, not automatically cancel or reject appointments.
