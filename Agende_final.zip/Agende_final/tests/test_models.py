"""
Tests for the model-selection code (ml/). Skipped automatically when pandas /
scikit-learn are not installed (the web app itself does not need them).

    python -m unittest tests.test_models -v
"""
import json
import math
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "research"))      # research/ml, research/model_selection.py

try:
    import numpy as np
    import pandas as pd  # noqa: F401
    import sklearn  # noqa: F401
    HAVE_ML = True
except ImportError:  # pragma: no cover
    HAVE_ML = False

from agende.noshow_scorer import derive, probability, risk  # noqa: E402  (pure Python, always available)

MODELS_DIR = os.path.join(ROOT, "agende", "models")


class PurePythonScorer(unittest.TestCase):
    def test_derived_features(self):
        r = derive({"prior_appointments": 4, "prior_no_shows": 1, "prior_cancellations": 2, "appointment_time": "14:30:00"})
        self.assertEqual(r["has_history"], 1)
        self.assertAlmostEqual(r["prior_no_show_rate"], 0.25)
        self.assertAlmostEqual(r["prior_cancel_rate"], 0.5)
        self.assertAlmostEqual(r["hour"], 14.5)
        self.assertEqual(derive({"prior_appointments": 0})["prior_no_show_rate"], 0.0)

    def test_inputs_are_clipped_to_training_range(self):
        model = {"intercept": -2.0, "numeric": [{"name": "log_prior_no_shows", "mean": 0.0, "scale": 1.0, "coef": 1.0,
                                                  "lo": 0.0, "hi": math.log1p(4)}],
                 "categorical": [], "tiers": {"high": 0.3, "medium": 0.1}}
        four = probability(model, {"prior_no_shows": 4, "prior_appointments": 10})
        self.assertAlmostEqual(probability(model, {"prior_no_shows": 26, "prior_appointments": 209}), four)

    def test_tiny_model(self):
        model = {"intercept": -2.0, "numeric": [{"name": "prior_no_shows", "mean": 0.0, "scale": 1.0, "coef": 1.0}],
                 "categorical": [{"name": "day_of_week", "values": {"Monday": 0.5}, "unknown": 0.0}],
                 "tiers": {"high": 0.3, "medium": 0.1}}
        self.assertAlmostEqual(probability(model, {"prior_no_shows": 0, "day_of_week": "Sunday"}), 1 / (1 + math.exp(2)))
        p, tier = risk(model, {"prior_no_shows": 2, "day_of_week": "Monday"})
        self.assertAlmostEqual(p, 1 / (1 + math.exp(-0.5)))
        self.assertEqual(tier, "high")

    def test_exported_models_are_valid(self):
        for path in (os.path.join(ROOT, "research", "ml", "models", "noshow_full.json"), os.path.join(MODELS_DIR, "noshow_agende.json")):
            if not os.path.exists(path):
                self.skipTest("run research/model_selection.py first")
            with open(path, encoding="utf-8") as handle:
                model = json.load(handle)
            self.assertIn("Advisory", model["use"])
            p, tier = risk(model, {"scheduling_interval": 5, "prior_appointments": 2, "prior_no_shows": 0,
                                   "appointment_category": "Healthcare", "day_of_week": "Monday", "appointment_time": "09:00"})
            self.assertTrue(0 < p < 1)
            risky, _ = risk(model, {"scheduling_interval": 30, "prior_appointments": 6, "prior_no_shows": 5,
                                    "appointment_category": "Healthcare", "day_of_week": "Monday", "appointment_time": "09:00"})
            self.assertGreater(risky, p)                       # more missed visits -> higher risk


@unittest.skipUnless(HAVE_ML, "pandas / scikit-learn not installed")
class NoShowPipeline(unittest.TestCase):
    def frame(self, n=600, seed=1):
        rng = np.random.default_rng(seed)
        prior = rng.integers(0, 6, n)
        ns = np.minimum(prior, rng.integers(0, 3, n))
        z = -2.5 + 0.9 * ns + rng.normal(0, 1, n)
        return pd.DataFrame({"scheduling_interval": rng.integers(1, 30, n), "is_first_visit": (prior == 0).astype(int),
                             "prior_appointments": prior, "prior_no_shows": ns, "prior_cancellations": rng.integers(0, 2, n),
                             "prior_no_show_rate": np.where(prior > 0, ns / np.maximum(prior, 1), 0.0), "prior_cancel_rate": 0.0,
                             "has_history": (prior > 0).astype(int), "daily_bookings_in_category": rng.integers(3, 20, n),
                             "hour": rng.integers(8, 18, n).astype(float),
                             "appointment_category": rng.choice(["Dental", "Healthcare", "Legal & Financial"], n),
                             "day_of_week": rng.choice(["Monday", "Tuesday", "Friday"], n),
                             "did_not_attend": (rng.random(n) < 1 / (1 + np.exp(-z))).astype(int)}).assign(
            log_prior_appointments=lambda f: np.log1p(f["prior_appointments"]),
            log_prior_no_shows=lambda f: np.log1p(f["prior_no_shows"]),
            log_prior_cancellations=lambda f: np.log1p(f["prior_cancellations"]))

    def test_json_export_matches_sklearn(self):
        from ml import noshow
        import model_selection as ms
        num, cat = noshow.FEATURE_SETS["agende"]
        d = self.frame()
        pipe = noshow.build("logistic", {"C": 1.0, "l1_ratio": 0}, num, cat).fit(d[num + cat], d["did_not_attend"])
        model = ms.export_logistic(pipe, num, cat, {"tiers": {"high": .3, "medium": .1}})
        self.assertLess(ms.verify_scorer(model, pipe, d, num, cat), 1e-9)

    def test_prior_correction_restores_base_rate(self):
        from ml import noshow
        num, cat = noshow.FEATURE_SETS["agende"]
        d = self.frame(3000, seed=3)
        weighted = noshow.build("logistic", {"C": 1.0, "l1_ratio": 0, "class_weight": "balanced"}, num, cat)
        weighted.fit(d[num + cat], d["did_not_attend"])
        raw = weighted.predict_proba(d[num + cat])[:, 1]
        n1 = d["did_not_attend"].sum()
        fixed = noshow.prior_correct(raw, math.log((len(d) - n1) / n1))
        rate = d["did_not_attend"].mean()
        self.assertGreater(raw.mean(), 2 * rate)                 # weighting inflates probabilities
        self.assertLess(abs(fixed.mean() - rate), 0.03)          # correction brings them back
        self.assertEqual(list(np.argsort(raw)), list(np.argsort(fixed)))   # ranking unchanged

    def test_split_is_chronological(self):
        from ml import noshow
        d = pd.DataFrame({"appointment_date": pd.to_datetime(["2023-05-01", "2024-03-31", "2024-04-01", "2024-08-31", "2024-09-01"]),
                          "historical_outcome": ["attended", "cancelled", "attended", "did_not_attend", "attended"],
                          "did_not_attend": [0, 0, 0, 1, 0]})
        tr, va, te = noshow.split(d, "active")
        self.assertEqual(len(tr), 1)                             # cancelled row removed
        self.assertTrue(tr["appointment_date"].max() < va["appointment_date"].min() <= va["appointment_date"].max() < te["appointment_date"].min())


@unittest.skipUnless(HAVE_ML, "pandas / scikit-learn not installed")
class TimeSeries(unittest.TestCase):
    def test_walk_forward_never_sees_the_future(self):
        from ml import timeseries as ts
        y = np.arange(100, dtype=float)
        for name in ts.MODELS:
            fn, params = ts.MODELS[name][1], ts.MODELS[name][2][0]
            a = fn(y[:70], 4, **params)
            spoiled = y.copy()
            spoiled[70:] = 1e6
            b = fn(spoiled[:70], 4, **params)
            np.testing.assert_allclose(a, b, err_msg=name)

    def test_simple_models(self):
        from ml import timeseries as ts
        y = np.array([10, 12, 14, 16, 18], float)
        np.testing.assert_allclose(ts.linear_trend(y, 2), [20, 22])
        np.testing.assert_allclose(ts.moving_average(y, 2, window=2), [17, 17])
        np.testing.assert_allclose(ts.naive(y, 3), [18, 18, 18])
        np.testing.assert_allclose(ts.holt(y, 2, alpha=1.0, beta=1.0, phi=1.0), [20, 22])
        self.assertAlmostEqual(ts.ses(y, 1, alpha=1.0)[0], 18)

    def test_metrics_only_score_inside_segment(self):
        from ml import timeseries as ts
        y = np.r_[np.full(90, 10.0), np.full(10, 1000.0)]
        r = ts.walk_forward(y, ts.mean, {}, 80, 90)              # weeks 90+ must not be scored
        self.assertAlmostEqual(r["mae"], 0.0)


if __name__ == "__main__":
    unittest.main()
