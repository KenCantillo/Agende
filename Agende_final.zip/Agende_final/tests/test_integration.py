"""
Integration tests: the real Flask app + a real MySQL test database.

    python -m unittest discover -s tests -v

Uses a SEPARATE database (default name agende_test, override with the
AGENDE_TEST_DB environment variable) which is dropped and recreated from
schema.sql + seed.sql. Your agende_db is never touched. Connection settings
(host, user, password) come from config.py / AGENDE_DB_* variables.
The whole module is skipped if MySQL cannot be reached.

Test-case IDs refer to blueprint section 34.
"""
import os
import re
import sys
import threading
import unittest
from datetime import date, datetime, time, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "tools"))
os.environ["AGENDE_DB_NAME"] = os.environ.get("AGENDE_TEST_DB", "agende_test")

from agende import config  # noqa: E402
import pymysql  # noqa: E402

try:
    _probe = pymysql.connect(host=config.DB_HOST, port=config.DB_PORT, user=config.DB_USER, password=config.DB_PASSWORD)
    _probe.close()
    DB_AVAILABLE = True
except Exception:  # pragma: no cover
    DB_AVAILABLE = False


def next_weekday(weekday, min_days=3):
    day = date.today() + timedelta(days=min_days)
    while day.weekday() != weekday:
        day += timedelta(days=1)
    return day


def setUpModule():
    if not DB_AVAILABLE:
        raise unittest.SkipTest("MySQL is not reachable with the settings in config.py")
    from agende import migrations           # drop + create the TEST database from schema.sql + seed.sql
    server = migrations.server_connection()
    cursor = server.cursor()
    migrations.drop_database(cursor)
    migrations.create_database(cursor, seed=True, log=lambda *_: None)
    server.close()
    global A, db_cursor, run_housekeeping, get_settings
    import app as A  # noqa: F811
    from agende.database import db_cursor  # noqa: F811
    from agende.notifications import run_housekeeping  # noqa: F811
    from agende.settings_store import get_settings  # noqa: F811
    A.app.config.update(TESTING=True, HOUSEKEEPING_ON_REQUEST=False)


def q(sql, params=()):
    with db_cursor() as cursor:
        cursor.execute(sql, params)
        return cursor.fetchall()


def run(sql, params=()):
    with db_cursor(commit=True) as cursor:
        cursor.execute(sql, params)
        return cursor.lastrowid


class Browser:
    """A logged-in test client that adds the CSRF token to every POST."""
    def __init__(self, email=None, password=None):
        self.c = A.app.test_client()
        if email:
            r = self.login(email, password)
            assert r.status_code == 302, f"login failed for {email}"

    def token(self):
        self.c.get("/login")
        with self.c.session_transaction() as s:
            if "_csrf_token" not in s:
                s["_csrf_token"] = "test-token"
            return s["_csrf_token"]

    def login(self, email, password):
        return self.c.post("/login", data={"email": email, "password": password, "csrf_token": self.token()})

    def get(self, url, **kw):
        return self.c.get(url, **kw)

    def post(self, url, data=None, **kw):
        data = dict(data or {})
        data.setdefault("csrf_token", self.token())
        return self.c.post(url, data=data, **kw)

    def flash(self, response):
        html = self.c.get("/notifications").get_data(as_text=True) if response.status_code == 302 else response.get_data(as_text=True)
        return " ".join(m.strip() for m in re.findall(r'role="alert">\s*([^<]+)', html))


def admin():
    return Browser("admin@agende.com", "admin123")


def staff():
    return Browser("provider@agende.com", "provider123")      # provider 1, General Consultation, Mon-Fri


def client():
    return Browser("user@agende.com", "user123")              # user 5


def book(browser, day, start, service_id=1, provider_id=1, notes=""):
    return browser.post("/user/book", {"service_id": service_id, "provider_id": provider_id,
                                       "appointment_date": day.isoformat(), "start_time": start, "notes": notes})


def appt_at(day, start, provider_id=1):
    rows = q("SELECT * FROM appointments WHERE provider_id=%s AND appointment_date=%s AND start_time=%s ORDER BY id DESC",
             (provider_id, day, start))
    return rows[0] if rows else None


STAFF_ACCOUNTS = [("provider@agende.com", "provider123"), ("karen.villareal@agende.com", "password123"),
                  ("paolo.reyes@agende.com", "password123"), ("liza.mendoza@agende.com", "password123")]


class T0_RoleDashboards(unittest.TestCase):
    """Regression: staff dashboards crashed with 'can only concatenate tuple (not list)
    to tuple' on days when the staff member had no appointments."""

    def test_every_account_reaches_its_dashboard(self):
        for email, password in STAFF_ACCOUNTS + [("user@agende.com", "user123"), ("admin@agende.com", "admin123")]:
            b = Browser(email, password)
            r = b.get("/login", follow_redirects=False)
            self.assertEqual(r.status_code, 200)
            r = b.c.get("/", follow_redirects=True)
            self.assertEqual(r.status_code, 200, email)

    def test_empty_day_staff_pages(self):
        b = Browser("liza.mendoza@agende.com", "password123")
        for url in ("/provider/dashboard", "/provider/appointments", "/provider/appointments?view=requests",
                    "/provider/appointments?view=history", "/provider/calendar", "/provider/schedule",
                    "/provider/blocked-periods", "/provider/analytics", "/notifications"):
            self.assertEqual(b.get(url).status_code, 200, url)

    def test_switch_account_while_signed_in(self):
        b = staff()
        page = b.get("/login").get_data(as_text=True)
        self.assertIn("You are signed in as", page)
        r = b.login("admin@agende.com", "admin123")
        self.assertIn("/admin/dashboard", r.headers["Location"])
        self.assertEqual(b.get("/admin/dashboard").status_code, 200)

    def test_unexpected_error_is_reported_not_crashed(self):
        from agende.routes import staff as RS
        original = RS.analytics.unusual_activity
        RS.analytics.unusual_activity = lambda *a, **k: 1 / 0
        try:
            b = staff()
            r = b.get("/provider/dashboard")
            self.assertEqual(r.status_code, 500)
            html = r.get_data(as_text=True)
            self.assertIn("Something went wrong", html)
            self.assertIn("Log out", html)                             # sidebar still there: user is not stuck
        finally:
            RS.analytics.unusual_activity = original


class T1_Authentication(unittest.TestCase):
    def test_TC001_valid_login(self):
        r = Browser().login("admin@agende.com", "admin123")
        self.assertEqual(r.status_code, 302)
        self.assertIn("/admin/dashboard", r.headers["Location"])

    def test_TC002_invalid_password(self):
        b = Browser()
        r = b.login("admin@agende.com", "wrong-password")
        self.assertEqual(r.status_code, 200)
        self.assertIn("Invalid email or password", r.get_data(as_text=True))
        self.assertTrue(q("SELECT id FROM audit_logs WHERE action='Failed login'"))

    def test_TC003_duplicate_registration(self):
        b = Browser()
        r = b.post("/register", {"name": "Dup", "email": "user@agende.com", "phone": "", "password": "abcdefg1",
                                 "confirm_password": "abcdefg1", "agree": "1"})
        self.assertIn("already exists", r.get_data(as_text=True))

    def test_registration_valid_and_weak_password(self):
        b = Browser()
        r = b.post("/register", {"name": "New Client", "email": "new.client@example.com", "phone": "0917 111 2222",
                                 "password": "short", "confirm_password": "short", "agree": "1"})
        self.assertIn("at least 8 characters", r.get_data(as_text=True))
        r = b.post("/register", {"name": "New Client", "email": "new.client@example.com", "phone": "0917 111 2222",
                                 "password": "goodpass1", "confirm_password": "goodpass1", "agree": "1"})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(q("SELECT id FROM users WHERE email='new.client@example.com'"))

    def test_TC004_logout(self):
        b = client()
        self.assertEqual(b.get("/logout").status_code, 405)          # GET is not allowed (CSRF-safe)
        b.post("/logout")
        self.assertEqual(b.get("/user/dashboard").status_code, 302)

    def test_csrf_required(self):
        b = client()
        r = b.c.post("/user/profile", data={"name": "Hacker", "phone": ""})
        self.assertEqual(r.status_code, 302)                          # sent back with a message
        self.assertIn("form expired", b.flash(r))
        self.assertNotEqual(q("SELECT name FROM users WHERE id=5")[0]["name"], "Hacker")

    def test_TC005_profile_and_password(self):
        b = client()
        r = b.post("/user/profile", {"name": "Juan Dela Cruz", "phone": "0917-300-0001", "current_password": "nope",
                                     "new_password": "newpass12", "confirm_password": "newpass12"})
        self.assertIn("current password is incorrect", b.flash(r))
        r = b.post("/user/profile", {"name": "Juan D. Cruz", "phone": "0917-300-0001"})
        self.assertEqual(q("SELECT name FROM users WHERE id=5")[0]["name"], "Juan D. Cruz")
        b.post("/user/profile", {"name": "Juan Dela Cruz", "phone": "0917-300-0001"})

    def test_password_reset_link(self):
        a = admin()
        a.post("/admin/users/11/reset-link")
        html = a.get("/admin/users").get_data(as_text=True)
        link = re.search(r'value="(http://localhost/reset-password/[^"]+)"', html).group(1)
        b = Browser()
        path = link.replace("http://localhost", "")
        r = b.post(path, {"password": "resetpass9", "confirm_password": "resetpass9"})
        self.assertEqual(r.status_code, 302)
        self.assertEqual(Browser().login("melchora.flores@example.com", "resetpass9").status_code, 302)
        self.assertEqual(b.get(path).status_code, 302)               # link works only once


class T2_Booking(unittest.TestCase):
    def test_TC014_valid_booking_creates_pending(self):
        day = next_weekday(0)
        r = book(client(), day, "13:00", notes="first visit")
        self.assertEqual(r.status_code, 302, client().flash(r))
        a = appt_at(day, "13:00")
        self.assertEqual(a["status"], "pending")
        self.assertEqual(str(a["end_time"]), "13:30:00")
        self.assertTrue(q("SELECT id FROM appointment_history WHERE appointment_id=%s AND action='created'", (a["id"],)))
        codes = {r["event_code"] for r in q("SELECT event_code FROM notifications WHERE appointment_id=%s", (a["id"],))}
        self.assertEqual(codes, {"N001", "N002"})                      # TC029

    def test_TC015_missing_field(self):
        b = client()
        before = len(q("SELECT id FROM appointments"))
        r = b.post("/user/book", {"service_id": 1, "provider_id": 1, "appointment_date": "", "start_time": ""})
        self.assertIn("Please choose", r.get_data(as_text=True))
        self.assertEqual(before, len(q("SELECT id FROM appointments")))

    def test_TC016_past_date_and_past_time(self):
        b = client()
        r = book(b, date.today() - timedelta(days=1), "09:00")
        self.assertIn("future date", r.get_data(as_text=True))
        monday = next_weekday(0, 8)
        A.app.config["NOW_OVERRIDE"] = datetime.combine(monday, time(10, 0))
        try:
            r = book(b, monday, "08:30")
            self.assertIn("already passed", r.get_data(as_text=True))       # BR-009
            r = book(b, monday, "10:30")
            self.assertIn("too soon", r.get_data(as_text=True))            # minimum notice 60 min
        finally:
            A.app.config["NOW_OVERRIDE"] = None

    def test_TC012_outside_hours_and_break(self):
        day = next_weekday(1)
        for start in ("07:00", "12:00", "11:45", "16:45"):
            r = book(client(), day, start)
            self.assertIn("unavailable", r.get_data(as_text=True).lower(), start)
        self.assertIsNone(appt_at(day, "12:00"))

    def test_TC017_TC018_conflicts(self):
        day = next_weekday(2)
        self.assertEqual(book(client(), day, "09:00").status_code, 302)
        other = Browser("maria.santos@example.com", "password123")
        r = book(other, day, "09:00")
        self.assertIn("no longer available", r.get_data(as_text=True))
        self.assertEqual(book(other, day, "09:30").status_code, 302)    # adjacent is fine

    def test_TC019_client_overlap(self):
        day = next_weekday(1)                                           # Tuesday: providers 1 and 3 work
        # 14:00 - seed.sql's sample bookings sit in the mornings (one is "today + 3 days, 09:00, provider 3",
        # which is this Tuesday whenever the tests run on a Saturday).
        self.assertEqual(book(client(), day, "14:00").status_code, 302)
        r = book(client(), day, "14:00", service_id=3, provider_id=3)
        self.assertIn("another of your appointments", r.get_data(as_text=True))

    def test_staff_must_offer_service_BR003(self):
        r = book(client(), next_weekday(0), "15:00", service_id=2, provider_id=1)
        self.assertIn("does not offer", r.get_data(as_text=True))

    def test_TC009_inactive_service(self):
        a = admin()
        a.post("/admin/services/5/toggle")
        r = book(client(), next_weekday(1), "10:00", service_id=5, provider_id=3)
        self.assertIn("currently unavailable", r.get_data(as_text=True))
        a.post("/admin/services/5/toggle")

    def test_TC020_simultaneous_booking(self):
        day = next_weekday(3)
        browsers = [client(), Browser("jose.ramos@example.com", "password123"),
                    Browser("andres.cruz@example.com", "password123")]
        barrier = threading.Barrier(len(browsers))
        results = []

        def attempt(b):
            barrier.wait()
            results.append(book(b, day, "14:00").status_code)
        threads = [threading.Thread(target=attempt, args=(b,)) for b in browsers]
        [t.start() for t in threads]
        [t.join() for t in threads]
        rows = q("SELECT id FROM appointments WHERE provider_id=1 AND appointment_date=%s AND start_time='14:00:00' AND status IN ('pending','confirmed')", (day,))
        self.assertEqual(len(rows), 1)

    def test_slots_api(self):
        day = next_weekday(4)
        book(client(), day, "08:00")
        data = client().get(f"/api/slots?provider_id=1&service_id=1&date={day.isoformat()}").get_json()
        states = {s["time"]: s["state"] for s in data["slots"]}
        self.assertEqual(states["08:00"], "booked")
        self.assertEqual(states["08:30"], "available")
        self.assertNotIn("12:00", states)
        days = client().get(f"/api/available-dates?provider_id=1&service_id=1&month={day.strftime('%Y-%m')}").get_json()["days"]
        self.assertIn(day.isoformat(), days)
        self.assertNotIn(next_weekday(5).isoformat(), days)          # Saturday: no hours


class T3_Workflow(unittest.TestCase):
    counter = 0

    def setUp(self):
        T3_Workflow.counter += 1
        self.day = next_weekday(T3_Workflow.counter % 5, 3 + 7 * (T3_Workflow.counter // 5))   # a fresh weekday per test
        book(client(), self.day, "15:00")
        self.appt = appt_at(self.day, "15:00")

    def status(self):
        return q("SELECT status FROM appointments WHERE id=%s", (self.appt["id"],))[0]["status"]

    def act(self, browser, status, reason=""):
        return browser.post(f"/appointments/{self.appt['id']}/status", {"status": status, "reason": reason})

    def test_TC021_approve(self):
        self.act(staff(), "confirmed")
        self.assertEqual(self.status(), "confirmed")
        self.assertTrue(q("SELECT id FROM notifications WHERE appointment_id=%s AND event_code='N003'", (self.appt["id"],)))

    def test_TC022_reject_needs_reason_and_releases_slot(self):
        s = staff()
        self.act(s, "rejected")
        self.assertEqual(self.status(), "pending")
        self.act(s, "rejected", "Fully booked")
        self.assertEqual(self.status(), "rejected")
        self.assertEqual(book(Browser("maria.santos@example.com", "password123"), self.day, "15:00").status_code, 302)

    def test_TC023_TC024_reschedule(self):
        b = client()
        self.act(staff(), "confirmed")
        r = b.post(f"/appointments/{self.appt['id']}/reschedule", {"appointment_date": self.day.isoformat(), "start_time": "16:00"})
        self.assertEqual(r.status_code, 302)
        row = q("SELECT * FROM appointments WHERE id=%s", (self.appt["id"],))[0]
        self.assertEqual((str(row["start_time"]), row["status"], row["reschedule_count"]), ("16:00:00", "pending", 1))
        book(Browser("jose.ramos@example.com", "password123"), self.day, "16:30")
        r = b.post(f"/appointments/{self.appt['id']}/reschedule", {"appointment_date": self.day.isoformat(), "start_time": "16:30"})
        self.assertIn("no longer available", b.flash(r))
        self.assertEqual(str(q("SELECT start_time FROM appointments WHERE id=%s", (self.appt["id"],))[0]["start_time"]), "16:00:00")
        self.assertEqual(book(Browser("andres.cruz@example.com", "password123"), self.day, "15:00").status_code, 302)  # old slot freed

    def test_staff_reschedule_requires_reason(self):
        s = staff()
        r = s.post(f"/appointments/{self.appt['id']}/reschedule", {"appointment_date": self.day.isoformat(), "start_time": "13:30"})
        self.assertIn("reason", s.flash(r))
        s.post(f"/appointments/{self.appt['id']}/reschedule", {"appointment_date": self.day.isoformat(), "start_time": "13:30", "reason": "Clinic meeting"})
        self.assertEqual(str(q("SELECT start_time FROM appointments WHERE id=%s", (self.appt["id"],))[0]["start_time"]), "13:30:00")

    def test_TC025_client_cancel_with_reason(self):
        b = client()
        self.act(b, "cancelled")
        self.assertEqual(self.status(), "pending")                       # reason required by default
        self.act(b, "cancelled", "Out of town")
        row = q("SELECT * FROM appointments WHERE id=%s", (self.appt["id"],))[0]
        self.assertEqual((row["status"], row["cancellation_reason"], row["cancelled_by"]), ("cancelled", "Out of town", 5))
        self.assertTrue(q("SELECT id FROM notifications WHERE appointment_id=%s AND event_code='N006' AND user_id=2", (self.appt["id"],)))  # TC031

    def test_TC026_cancel_cutoff_and_terminal(self):
        self.act(staff(), "confirmed")
        A.app.config["NOW_OVERRIDE"] = datetime.combine(self.day, time(14, 0))   # 1 hour before; cutoff is 2
        try:
            self.act(client(), "cancelled", "Late")
            self.assertEqual(self.status(), "confirmed")
        finally:
            A.app.config["NOW_OVERRIDE"] = None

    def test_TC027_TC028_complete_only_after_start(self):
        s = staff()
        self.act(s, "confirmed")
        self.act(s, "completed")
        self.assertEqual(self.status(), "confirmed")                     # start time not reached
        A.app.config["NOW_OVERRIDE"] = datetime.combine(self.day, time(15, 40))
        try:
            self.act(s, "no_show")
            self.assertEqual(self.status(), "no_show")
            self.act(admin(), "confirmed")
            self.assertEqual(self.status(), "no_show")                   # BR-016: terminal
        finally:
            A.app.config["NOW_OVERRIDE"] = None

    def test_ownership(self):
        other = Browser("maria.santos@example.com", "password123")
        self.assertEqual(other.get(f"/appointments/{self.appt['id']}").status_code, 403)
        for browser, status in ((other, "cancelled"), (Browser("karen.villareal@agende.com", "password123"), "confirmed"),
                                (client(), "confirmed")):
            r = self.act(browser, status, "x")
            self.assertEqual(r.status_code, 302)
            self.assertIn("not allowed", browser.flash(r))
            self.assertEqual(self.status(), "pending")


class T4_Housekeeping(unittest.TestCase):
    def test_TC032_reminders_and_expiry(self):
        day = next_weekday(0, 15)
        book(client(), day, "10:00")
        book(Browser("maria.santos@example.com", "password123"), day, "10:30")
        confirmed, pending = appt_at(day, "10:00"), appt_at(day, "10:30")
        staff().post(f"/appointments/{confirmed['id']}/status", {"status": "confirmed"})
        summary = run_housekeeping(db_cursor, get_settings, datetime.combine(day - timedelta(days=1), time(11, 0)))
        self.assertGreaterEqual(summary["reminders"], 1)
        self.assertTrue(q("SELECT id FROM notifications WHERE appointment_id=%s AND event_code='N007'", (confirmed["id"],)))
        run_housekeeping(db_cursor, get_settings, datetime.combine(day, time(7, 0)))
        self.assertTrue(q("SELECT id FROM notifications WHERE appointment_id=%s AND event_code='N008'", (confirmed["id"],)))
        run_housekeeping(db_cursor, get_settings, datetime.combine(day, time(10, 45)))
        self.assertEqual(q("SELECT status FROM appointments WHERE id=%s", (pending["id"],))[0]["status"], "expired")
        self.assertEqual(q("SELECT status FROM appointments WHERE id=%s", (confirmed["id"],))[0]["status"], "confirmed")


class T5_AdminAndSecurity(unittest.TestCase):
    def test_TC044_TC045_create_and_deactivate_user(self):
        a = admin()
        a.post("/admin/users", {"name": "Temp Client", "email": "temp.client@example.com", "phone": "", "role": "user", "password": "temppass1"})
        uid = q("SELECT id FROM users WHERE email='temp.client@example.com'")[0]["id"]
        session_browser = Browser("temp.client@example.com", "temppass1")
        a.post(f"/admin/users/{uid}/toggle")
        self.assertEqual(session_browser.get("/user/dashboard").status_code, 302)     # kicked out
        self.assertEqual(Browser().login("temp.client@example.com", "temppass1").status_code, 200)
        self.assertTrue(q("SELECT id FROM audit_logs WHERE action='Deactivated user' AND entity_id=%s", (uid,)))  # TC048

    def test_last_admin_protected(self):
        a = admin()
        a.post("/admin/users/1/toggle")
        self.assertEqual(q("SELECT is_active FROM users WHERE id=1")[0]["is_active"], 1)

    def test_TC046_schedule_overlap_rejected(self):
        s = staff()
        r = s.post("/provider/schedule", {"day_of_week": 0, "start_time": "11:00", "end_time": "14:00"})
        self.assertIn("overlaps", s.flash(r))

    def test_TC047_block_time_flags_existing(self):
        day = next_weekday(4, 20)
        book(client(), day, "09:00")
        s = staff()
        r = s.post("/provider/blocked-periods", {"start_datetime": f"{day}T08:30", "end_datetime": f"{day}T10:00", "reason": "Training"})
        self.assertIn("affects 1 upcoming", s.flash(r))
        self.assertEqual(appt_at(day, "09:00")["status"], "pending")          # kept, not deleted
        self.assertTrue(q("SELECT id FROM notifications WHERE event_code='N011' AND user_id=5"))
        self.assertIn("blocked", book(client(), day, "08:30").get_data(as_text=True).lower() + "blocked")
        r = book(Browser("jose.ramos@example.com", "password123"), day, "09:30")
        self.assertIn("unavailable", r.get_data(as_text=True))

    def test_TC049_unauthorized(self):
        c = client()
        for url in ("/admin/dashboard", "/admin/users", "/provider/dashboard", "/admin/reports/appointments.csv"):
            self.assertEqual(c.get(url).status_code, 403, url)
        s = staff()
        self.assertEqual(s.get("/provider/analytics?provider_id=2").status_code, 200)
        self.assertEqual(Browser().get("/user/dashboard").status_code, 302)

    def test_TC050_sql_injection_safe(self):
        r = client().get("/search?q=' OR 1=1 --")
        self.assertEqual(r.status_code, 200)
        self.assertNotIn("Maria Clara", r.get_data(as_text=True))
        r = admin().get("/admin/appointments?q=1%27%3B%20DROP%20TABLE%20users%3B--")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(q("SELECT id FROM users LIMIT 1"))

    def test_TC051_xss_escaped(self):
        b = Browser()
        b.post("/register", {"name": "<script>alert(1)</script>", "email": "xss@example.com", "phone": "",
                             "password": "xsspass12", "confirm_password": "xsspass12", "agree": "1"})
        html = admin().get("/admin/users?q=xss").get_data(as_text=True)
        self.assertNotIn("<script>alert(1)</script>", html)
        self.assertIn("&lt;script&gt;", html)

    def test_TC054_setting_applied(self):
        a = admin()
        form = {k: v for k, v in get_settings_dict().items()}
        form["buffer_minutes"] = 30
        a.post("/admin/settings", form)
        try:
            day = next_weekday(2, 17)
            book(client(), day, "09:00")
            r = book(Browser("maria.santos@example.com", "password123"), day, "09:30")
            self.assertIn("no longer available", r.get_data(as_text=True))
        finally:
            form["buffer_minutes"] = 0
            a.post("/admin/settings", form)

    def test_TC055_failed_transaction_leaves_nothing(self):
        from agende import appointments as AP
        original = AP.notify
        AP.notify = lambda *a, **k: (_ for _ in ()).throw(RuntimeError("notification store down"))
        day = next_weekday(1, 24)
        b = client()
        try:
            r = book(b, day, "15:00")
        finally:
            AP.notify = original
        self.assertEqual(r.status_code, 302)
        self.assertIn("nothing was saved", b.flash(r))                # user is told, not shown a crash
        self.assertIsNone(appt_at(day, "15:00"))


class T7_ActionFeedback(unittest.TestCase):
    """Every action tells the user whether it worked."""

    def test_every_form_action_shows_a_message(self):
        a, s, c = admin(), staff(), client()
        day = next_weekday(2, 31)
        book(c, day, "10:00")
        appt = appt_at(day, "10:00")
        sid = q("SELECT id FROM provider_schedules WHERE provider_id=1 ORDER BY id LIMIT 1")[0]["id"]
        future = date.today() + timedelta(days=40)
        nid = q("SELECT id FROM notifications WHERE user_id=5 ORDER BY id DESC LIMIT 1")[0]["id"]
        actions = [
            (c, f"/appointments/{appt['id']}/status", {"status": "cancelled"}, "why you are cancelling"),  # failure
            (s, f"/appointments/{appt['id']}/status", {"status": "completed"}, "cannot be changed"),  # failure: still pending
            (s, f"/appointments/{appt['id']}/status", {"status": "confirmed"}, "confirmed"),         # success
            (s, f"/appointments/{appt['id']}/status", {"status": "completed"}, "start time"),        # failure: not started
            (c, f"/appointments/{appt['id']}/reschedule", {"appointment_date": day.isoformat(), "start_time": "03:00"}, "unavailable"),
            (c, f"/notifications/{nid}/read", {}, "marked as read"),
            (c, "/notifications/read-all", {}, "Marked"),
            (c, "/user/profile", {"name": "", "phone": ""}, "Name is required"),
            (c, "/user/profile", {"name": "Juan Dela Cruz", "phone": "0917-300-0001"}, "Profile updated"),
            (s, "/provider/schedule", {"day_of_week": 6, "start_time": "10:00", "end_time": "09:00"}, "earlier than"),
            (s, f"/provider/schedule/{sid}/toggle", {}, "Availability updated"),
            (s, f"/provider/schedule/{sid}/toggle", {}, "Availability updated"),
            (s, "/provider/blocked-periods", {"start_datetime": f"{future}T09:00", "end_datetime": f"{future}T08:00"}, "after the start"),
            (s, "/provider/blocked-periods/999999/delete", {}, "no longer exists"),
            (a, "/admin/services", {"name": "", "duration": "30"}, "service name"),
            (a, "/admin/services/999999/toggle", {}, "no longer exists"),
            (a, "/admin/users", {"name": "X", "email": "bad", "role": "user", "password": "short"}, "valid email"),
            (a, "/admin/users/1/toggle", {}, "cannot deactivate your own"),
            (a, "/admin/users/5/reset-link", {}, "reset link created"),
            (a, "/admin/schedules", {"provider_id": 1, "kind": "window", "day_of_week": 0, "start_time": "08:30", "end_time": "09:30"}, "overlaps"),
            (a, "/admin/settings", {"booking_min_lead_minutes": "abc"}, "whole number"),
            (a, "/admin/announcements", {"audience": "all", "title": "", "message": ""}, "Choose an audience"),
            (a, "/admin/forecast", {"source": "live"}, "Insufficient"),
            (a, "/admin/appointments/new", {"client_id": 5}, "Choose a client"),
            (c, "/admin/users/5/toggle", {}, "not allowed"),
        ]
        for browser, url, data, expected in actions:
            r = browser.post(url, data)
            self.assertIn(r.status_code, (200, 302), url)              # 200 = form shown again with the message
            self.assertIn(expected.lower(), browser.flash(r).lower(), url)


class T8_ScheduleNoticesOrderCalendar(unittest.TestCase):
    def admin_notes(self, code, since_id):
        return q("SELECT * FROM notifications WHERE user_id = 1 AND event_code = %s AND id > %s", (code, since_id))

    def last_note_id(self):
        return q("SELECT COALESCE(MAX(id), 0) AS m FROM notifications")[0]["m"]

    def test_admins_hear_about_reschedule_requests(self):
        day = next_weekday(1, 38)
        book(c := client(), day, "09:00")
        appt = appt_at(day, "09:00")
        mark = self.last_note_id()
        c.post(f"/appointments/{appt['id']}/reschedule", {"appointment_date": day.isoformat(), "start_time": "10:00"})
        notes = self.admin_notes("N005", mark)
        self.assertTrue(notes, "admin was not notified of the client's reschedule request")
        self.assertIn("requested a schedule change", notes[0]["message"])
        mark = self.last_note_id()
        staff().post(f"/appointments/{appt['id']}/reschedule",
                     {"appointment_date": day.isoformat(), "start_time": "11:00", "reason": "Doctor running late"})
        self.assertTrue(self.admin_notes("N005", mark), "admin was not notified of the staff reschedule")

    def test_schedule_updates_notify_admins_staff_and_clients(self):
        day = next_weekday(0, 45)
        book(client(), day, "16:00")
        window = q("""SELECT id FROM provider_schedules WHERE provider_id = 1 AND day_of_week = 0
                      AND start_time = '13:00:00'""")[0]["id"]
        mark = self.last_note_id()
        staff().post(f"/provider/schedule/{window}/toggle")              # staff disables Monday afternoon
        admin_notes = self.admin_notes("N011", mark)
        self.assertTrue(admin_notes)
        self.assertIn("disabled Monday 1:00 PM", admin_notes[0]["message"])
        self.assertRegex(admin_notes[0]["message"], r"\d+ upcoming appointment")
        self.assertTrue(q("SELECT id FROM notifications WHERE user_id = 5 AND event_code = 'N011' AND id > %s", (mark,)))
        mark = self.last_note_id()
        admin().post(f"/admin/schedules/{window}/toggle")                     # admin re-enables it
        staff_notes = q("SELECT message FROM notifications WHERE user_id = 2 AND event_code = 'N011' AND id > %s", (mark,))
        self.assertTrue(staff_notes and "changed your schedule" in staff_notes[0]["message"])
        self.assertFalse(self.admin_notes("N011", mark), "the admin who made the change should not notify themself")
        mark = self.last_note_id()
        future = date.today() + timedelta(days=50)
        staff().post("/provider/blocked-periods", {"start_datetime": f"{future}T08:00", "end_datetime": f"{future}T09:00"})
        self.assertTrue(self.admin_notes("N011", mark), "admins not told about blocked time")

    def test_appointments_upcoming_soonest_first(self):
        a = admin()
        html = a.get("/admin/appointments").get_data(as_text=True)
        ids = [int(x) for x in re.findall(r'<td class="mono"><a href="/appointments/(\d+)"', html)]
        rows = {r["id"]: r for r in q("SELECT id, appointment_date, start_time FROM appointments")}
        upcoming = [i for i in ids if rows[i]["appointment_date"] >= date.today()]
        past = [i for i in ids if rows[i]["appointment_date"] < date.today()]
        self.assertEqual(ids[:len(upcoming)], upcoming, "upcoming appointments must come before past ones")
        keys = [(rows[i]["appointment_date"], rows[i]["start_time"], i) for i in upcoming]
        self.assertEqual(keys, sorted(keys), "upcoming appointments must run soonest -> farthest, then by ID")
        if past:
            self.assertIn("Past appointments", html)
        by_id = [int(x) for x in re.findall(r'<td class="mono"><a href="/appointments/(\d+)"',
                                              a.get("/admin/appointments?sort=id").get_data(as_text=True))]
        self.assertEqual(by_id, sorted(by_id))
        mine = [int(x) for x in re.findall(r'<td class="mono"><a href="/appointments/(\d+)"',
                                             client().get("/user/appointments").get_data(as_text=True))]
        keys = [(rows[i]["appointment_date"], rows[i]["start_time"], i) for i in mine]
        self.assertEqual(keys, sorted(keys))

    def test_request_decisions_notify_client_and_staff(self):
        day = next_weekday(4, 39)
        book(c := client(), day, "09:00")
        appt = appt_at(day, "09:00")
        staff().post(f"/appointments/{appt['id']}/status", {"status": "confirmed"})
        c.post(f"/appointments/{appt['id']}/reschedule", {"appointment_date": day.isoformat(), "start_time": "10:00"})
        mark = self.last_note_id()
        admin().post(f"/appointments/{appt['id']}/status", {"status": "confirmed"})       # admin approves the request
        client_note = q("SELECT * FROM notifications WHERE user_id = 5 AND id > %s", (mark,))
        staff_note = q("SELECT * FROM notifications WHERE user_id = 2 AND id > %s", (mark,))
        self.assertIn("reschedule request was approved", client_note[0]["message"])
        self.assertIn("approved Juan", staff_note[0]["message"])
        c.post(f"/appointments/{appt['id']}/reschedule", {"appointment_date": day.isoformat(), "start_time": "11:00"})
        mark = self.last_note_id()
        staff().post(f"/appointments/{appt['id']}/status", {"status": "rejected", "reason": "Fully booked"})
        client_note = q("SELECT * FROM notifications WHERE user_id = 5 AND id > %s", (mark,))
        staff_note = q("SELECT * FROM notifications WHERE user_id = 2 AND id > %s", (mark,))
        admin_note = q("SELECT * FROM notifications WHERE user_id = 1 AND id > %s", (mark,))
        self.assertIn("reschedule request for", client_note[0]["message"])
        self.assertIn("declined", client_note[0]["message"])
        self.assertIn("Fully booked", client_note[0]["message"])
        self.assertIn("You declined", staff_note[0]["message"])
        self.assertTrue(admin_note, "admins should hear the outcome of a reschedule request")

    def test_calendar_shows_status_dots(self):
        day = next_weekday(2, 5)
        book(c := client(), day, "15:00")
        book(c, day, "16:00")
        cancel = appt_at(day, "16:00")
        c.post(f"/appointments/{cancel['id']}/status", {"status": "cancelled", "reason": "Conflict"})
        html = c.get(f"/user/dashboard?month={day.strftime('%Y-%m')}").get_data(as_text=True)
        cell = re.search(rf'date_from={day.isoformat()}.*?</a>', html, re.S).group(0)
        self.assertIn("dot-pending", cell)
        self.assertIn("dot-cancelled", cell)
        self.assertIn("1 pending", cell)
        self.assertIn("mc-legend", html)
        self.assertIn("dot-cancelled", admin().get(f"/admin/dashboard?month={day.strftime('%Y-%m')}").get_data(as_text=True))


def get_settings_dict():
    with db_cursor() as cursor:
        return get_settings(cursor)


class T6_AnalyticsReportsForecast(unittest.TestCase):
    def test_TC033_TC035_kpis_match_records(self):
        start, end = date.today() - timedelta(days=30), date.today() + timedelta(days=60)
        a = admin()
        html = a.get(f"/admin/analytics?start={start}&end={end}").get_data(as_text=True)
        total = q("SELECT COUNT(*) AS n FROM appointments WHERE appointment_date BETWEEN %s AND %s", (start, end))[0]["n"]
        self.assertRegex(html, rf'kpi-value">{total}<')

    def test_TC036_TC037_filters(self):
        csv_text = admin().get(f"/admin/reports/analytics.csv?start={date.today()}&end={date.today() + timedelta(days=60)}&service_id=1&provider_id=1").get_data(as_text=True)
        total = q("SELECT COUNT(*) AS n FROM appointments WHERE appointment_date BETWEEN %s AND %s AND service_id=1 AND provider_id=1",
                  (date.today(), date.today() + timedelta(days=60)))[0]["n"]
        self.assertIn(f"Total appointments (A001),{total}", csv_text)

    def test_TC052_appointment_report(self):
        text = admin().get("/admin/reports/appointments.csv").get_data(as_text=True)
        rows = [line for line in text.strip().splitlines()[1:] if line]
        self.assertEqual(len(rows), q("SELECT COUNT(*) AS n FROM appointments")[0]["n"])

    def test_TC043_TC053_forecast_with_history(self):
        a = admin()
        self.assertIn("Insufficient historical data", a.get("/admin/forecast?source=live").get_data(as_text=True))
        rows = []
        monday = date(2024, 1, 1)
        for w in range(30):
            for i in range(30 + 2 * w):
                rows.append((monday + timedelta(days=7 * w + i % 7), "no_show" if i % 10 == 0 else "completed"))
        with db_cursor(commit=True) as cursor:
            cursor.executemany("INSERT INTO historical_appointments (appointment_date, status) VALUES (%s, %s)", rows)
        html = a.get("/admin/forecast?source=imported").get_data(as_text=True)
        self.assertIn("Sufficient", html)
        a.post("/admin/forecast", {"source": "imported", "horizon": 4})
        model = q("SELECT * FROM forecast_models WHERE model_type='appointments' ORDER BY id DESC LIMIT 1")[0]
        self.assertAlmostEqual(float(model["slope"]), 2.0, places=3)
        self.assertEqual(len(q("SELECT id FROM forecast_results WHERE model_id=%s", (model["id"],))), 4)
        text = a.get("/admin/reports/forecast.csv?source=imported").get_data(as_text=True)
        self.assertIn("Forecast,2024-07-29", text)


def ensure_history(weeks=30):
    if not q("SELECT id FROM historical_appointments LIMIT 1"):
        monday, rows = date(2024, 1, 1), []
        for w in range(weeks):
            for i in range(30 + 2 * w):
                rows.append((monday + timedelta(days=7 * w + i % 7), "no_show" if i % 10 == 0 else "completed"))
        with db_cursor(commit=True) as cursor:
            cursor.executemany("INSERT INTO historical_appointments (appointment_date, status) VALUES (%s, %s)", rows)


class T9_ForecastModel(unittest.TestCase):
    """Trained / deployed forecast model (3.1): F081-F088, TC039, TC041, TC042."""

    def test_a_train_deploy_activate_and_model_file(self):
        ensure_history()
        a = admin()
        r = a.post("/admin/forecast", {"source": "imported", "horizon": 4})
        self.assertIn("trained and deployed", a.flash(r))
        first = q("SELECT * FROM forecast_models WHERE is_active=1 ORDER BY id")
        self.assertEqual([m["model_type"] for m in first], ["appointments", "no_shows"])
        version1 = first[0]["version_label"]
        self.assertTrue(version1.startswith("FM-"))
        self.assertEqual(first[0]["version_label"], first[1]["version_label"])
        self.assertAlmostEqual(float(first[0]["slope"]), 2.0, places=3)
        self.assertIsNotNone(first[0]["baseline_mae"])
        self.assertGreater(first[0]["training_record_count"], 0)
        self.assertEqual(len(q("SELECT id FROM forecast_results WHERE model_id=%s", (first[0]["id"],))), 4)

        a.post("/admin/forecast", {"source": "imported", "horizon": 2})
        active = q("SELECT version_label FROM forecast_models WHERE is_active=1")
        self.assertEqual(len(active), 2)
        self.assertNotEqual(active[0]["version_label"], version1)

        r = a.post("/admin/forecast/activate", {"version": version1})
        self.assertIn(f"{version1} is now the active forecast model", a.flash(r))
        self.assertEqual({m["version_label"] for m in q("SELECT version_label FROM forecast_models WHERE is_active=1")}, {version1})
        r = a.post("/admin/forecast/activate", {"version": "FM-9999"})
        self.assertIn("not found", a.flash(r))
        self.assertEqual(len(q("SELECT id FROM forecast_models WHERE is_active=1")), 2)

        r = a.get("/admin/forecast/model.json")
        self.assertEqual(r.status_code, 200)
        model = r.get_json()
        self.assertEqual(model["version"], version1)
        self.assertAlmostEqual(model["models"]["appointments"]["slope_b1"], 2.0, places=3)

        # Data ends in 2024, so the model is out of date for this week and the dashboard says so.
        self.assertIn("Out of date", a.get("/admin/forecast").get_data(as_text=True))
        self.assertIn("Forecast model out of date", a.get("/admin/dashboard").get_data(as_text=True))
        csv_text = a.get("/admin/reports/forecast.csv?deployed=1").get_data(as_text=True)
        self.assertIn(f"Deployed model,{version1}", csv_text)
        self.assertEqual(staff().get("/admin/forecast/model.json").status_code, 403)

    def test_b_prediction_from_saved_coefficients(self):
        from agende import forecasting
        with db_cursor() as cursor:
            models = forecasting.active_models(cursor)
        week = date(2024, 8, 26)
        x = (week - models["training_start"]).days // 7 + 1
        raw, shown = forecasting.predict(models["appointments"], week)
        self.assertAlmostEqual(raw, float(models["appointments"]["intercept"]) + float(models["appointments"]["slope"]) * x)
        self.assertEqual(shown, max(0, round(raw)))
        far_past = forecasting.predict({"intercept": 5, "slope": -1, "training_start": date(2024, 1, 1)}, date(2024, 6, 3))
        self.assertLess(far_past[0], 0)
        self.assertEqual(far_past[1], 0)                      # TC042: never displayed below zero

    def test_c_auto_retrain_on_live_records(self):
        today = date.today()
        last_sunday = today - timedelta(days=today.weekday() + 1)
        first_monday = last_sunday - timedelta(days=7 * 28 - 1)
        rows = []
        for w in range(28):
            for i in range(10 + w):
                day = first_monday + timedelta(days=7 * w + i % 7)
                start = time(8 + i % 9, 0)
                rows.append((5, 1, 1, day, start, time(start.hour, 30), "no_show" if i % 5 == 0 else "completed"))
        with db_cursor(commit=True) as cursor:
            cursor.executemany("""INSERT INTO appointments (user_id, provider_id, service_id, appointment_date, start_time,
                                  end_time, status) VALUES (%s, %s, %s, %s, %s, %s, %s)""", rows)
        try:
            summary = run_housekeeping(db_cursor, get_settings, force_retrain_check=True)
            self.assertTrue(summary["model_retrained"].startswith("FM-"))
            active = q("SELECT * FROM forecast_models WHERE is_active=1 ORDER BY id")
            self.assertEqual({m["data_source"] for m in active}, {"live"})
            self.assertEqual({m["train_trigger"] for m in active}, {"auto"})
            self.assertEqual(active[0]["training_end"], last_sunday)
            self.assertGreater(float(active[0]["slope"]), 0.5)
            self.assertTrue(q("SELECT id FROM notifications WHERE user_id=1 AND title='Forecast model updated'"))
            self.assertTrue(q("SELECT id FROM audit_logs WHERE action='Retrained forecast model'"))
            # No new complete week -> no new version.
            self.assertEqual(run_housekeeping(db_cursor, get_settings, force_retrain_check=True)["model_retrained"], "")
            html = admin().get("/admin/dashboard").get_data(as_text=True)
            self.assertIn("This week (predicted)", html)
            self.assertIn(active[0]["version_label"], html)
            # Auto retraining off -> nothing happens even with a new week of data.
            run("UPDATE system_settings SET setting_value='0' WHERE setting_key='forecast_auto_retrain'")
            run("UPDATE forecast_models SET training_end = training_end - INTERVAL 7 DAY WHERE is_active=1")
            self.assertEqual(run_housekeeping(db_cursor, get_settings, force_retrain_check=True)["model_retrained"], "")
        finally:
            run("UPDATE system_settings SET setting_value='1' WHERE setting_key='forecast_auto_retrain'")
            run("DELETE FROM appointments WHERE appointment_date BETWEEN %s AND %s AND user_id=5 AND notes IS NULL "
                "AND status IN ('completed','no_show') AND id NOT IN (SELECT appointment_id FROM appointment_history)",
                (first_monday, last_sunday))

    def test_d_cli_train_forecast(self):
        import tempfile
        runner = A.app.test_cli_runner()
        with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False, newline="") as handle:
            handle.write("appointment_id,appointment_date,appointment_status,appointment_duration\n")
            monday = date(2023, 1, 2)
            n = 0
            for w in range(30):
                for i in range(20 + w):
                    n += 1
                    status = "did not attend" if i % 8 == 0 else ("cancelled" if i % 9 == 0 else "attended")
                    handle.write(f"{n},{monday + timedelta(days=7 * w + i % 7)},{status},30\n")
            path = handle.name
        try:
            out = runner.invoke(args=["train-forecast", "--csv", path, "--replace", "--source", "imported", "--no-deploy"])
            self.assertEqual(out.exit_code, 0, out.output)
            self.assertIn("Evaluation only", out.output)
            self.assertIn("baseline MAE", out.output)
            self.assertEqual(q("SELECT COUNT(*) AS n FROM historical_appointments")[0]["n"], n)
            export = path + ".json"
            out = runner.invoke(args=["train-forecast", "--source", "imported", "--export", export])
            self.assertEqual(out.exit_code, 0, out.output)
            self.assertIn("Deployed FM-", out.output)
            active = q("SELECT * FROM forecast_models WHERE is_active=1")
            self.assertEqual({m["train_trigger"] for m in active}, {"cli"})
            import json
            with open(export, encoding="utf-8") as fh:
                self.assertAlmostEqual(json.load(fh)["models"]["appointments"]["slope_b1"], 1.0, places=6)
        finally:
            os.unlink(path)
            if os.path.exists(path + ".json"):
                os.unlink(path + ".json")



class T9b_NoShowRiskAndStaffForecast(unittest.TestCase):
    """3.2: advisory no-show risk (staff/admin only), service categories, per-staff forecasts."""

    def test_a_service_category(self):
        a = admin()
        svc = q("SELECT * FROM services WHERE id=3")[0]
        self.assertIsNone(svc["risk_category"])               # IT Support has no matching category
        r = a.post("/admin/services", {"service_id": 3, "name": svc["name"], "description": svc["description"] or "",
                                       "duration": svc["duration"], "risk_category": "Government & Admin"})
        self.assertIn("Service saved", a.flash(r))
        self.assertEqual(q("SELECT risk_category FROM services WHERE id=3")[0]["risk_category"], "Government & Admin")
        r = a.post("/admin/services", {"service_id": 3, "name": svc["name"], "duration": svc["duration"], "risk_category": "Spaceflight"})
        self.assertIn("Choose a no-show category", a.flash(r))
        a.post("/admin/services", {"service_id": 3, "name": svc["name"], "description": svc["description"] or "",
                                   "duration": svc["duration"], "risk_category": ""})
        self.assertIsNone(q("SELECT risk_category FROM services WHERE id=3")[0]["risk_category"])
        self.assertIn("No-show category", a.get("/admin/services").get_data(as_text=True))

    def test_b_features_and_visibility(self):
        from agende import noshow_risk
        day = next_weekday(1, 20)
        book(client(), day, "09:00")
        appt = appt_at(day, "09:00")
        past = [(5, 1, 2, date(2025, 1, 6 + i), time(9, 0), time(9, 30), st)
                for i, st in enumerate(["completed", "completed", "no_show", "no_show", "cancelled"])]
        with db_cursor(commit=True) as cursor:
            cursor.executemany("""INSERT INTO appointments (user_id, provider_id, service_id, appointment_date, start_time, end_time, status)
                                  VALUES (%s, %s, %s, %s, %s, %s, %s)""", past)
            settings = get_settings(cursor)
            rows = [dict(appt)]
            feats = noshow_risk.features(cursor, rows)[appt["id"]]
            noshow_risk.annotate(cursor, rows, settings, datetime.now(), with_reasons=True)
        self.assertGreaterEqual(feats["prior_appointments"], 5)
        self.assertGreaterEqual(feats["prior_no_shows"], 2)
        self.assertGreaterEqual(feats["prior_cancellations"], 1)
        self.assertEqual(feats["appointment_category"], "Healthcare")      # General Consultation
        self.assertEqual(feats["day_of_week"], day.strftime("%A"))
        self.assertEqual(feats["hour"], 9.0)
        risk = rows[0]["risk"]
        self.assertTrue(0 < risk["p"] < 1)
        self.assertIn(risk["tier"], ("low", "medium", "high"))
        self.assertTrue(any("Missed" in r for r in risk["raises"]))

        # Staff (own appointment) and admin see it; the client never does.
        s, a, c = staff(), admin(), client()
        self.assertIn("No-show risk", s.get(f"/appointments/{appt['id']}").get_data(as_text=True))
        self.assertIn("risk-badge", s.get("/provider/appointments").get_data(as_text=True))
        self.assertIn("Reminder priorities", s.get("/provider/dashboard").get_data(as_text=True))
        self.assertIn("risk-badge", a.get("/admin/appointments").get_data(as_text=True))
        for url in (f"/appointments/{appt['id']}", "/user/appointments", "/user/dashboard"):
            html = c.get(url).get_data(as_text=True)
            self.assertNotIn("risk-badge", html, url)
            self.assertNotIn("No-show risk", html, url)

        # Turning the setting off hides it everywhere.
        run("UPDATE system_settings SET setting_value='0' WHERE setting_key='noshow_risk_enabled'")
        try:
            self.assertNotIn("risk-badge", s.get("/provider/appointments").get_data(as_text=True))
            self.assertNotIn("No-show risk", s.get(f"/appointments/{appt['id']}").get_data(as_text=True))
        finally:
            run("UPDATE system_settings SET setting_value='1' WHERE setting_key='noshow_risk_enabled'")

        # A missing model file switches the feature off instead of breaking pages.
        original = noshow_risk.MODEL_PATH
        noshow_risk.MODEL_PATH, noshow_risk._cache["mtime"] = "/nonexistent/model.json", None
        try:
            r = s.get("/provider/appointments")
            self.assertEqual(r.status_code, 200)
            self.assertNotIn("risk-badge", r.get_data(as_text=True))
        finally:
            noshow_risk.MODEL_PATH, noshow_risk._cache["mtime"] = original, None
        run("DELETE FROM appointments WHERE user_id=5 AND provider_id=1 AND appointment_date BETWEEN '2025-01-06' AND '2025-01-10'")

    def test_c_staff_forecast_is_own_records(self):
        today = date.today()
        last_sunday = today - timedelta(days=today.weekday() + 1)
        first_monday = last_sunday - timedelta(days=7 * 28 - 1)
        rows = []
        for w in range(28):
            for i in range(6 + w // 4):
                day = first_monday + timedelta(days=7 * w + i % 5)
                rows.append((6, 2, 2, day, time(8 + i % 8, 0), time(8 + i % 8, 45), "no_show" if i % 6 == 0 else "completed"))
        with db_cursor(commit=True) as cursor:
            cursor.executemany("""INSERT INTO appointments (user_id, provider_id, service_id, appointment_date, start_time, end_time, status)
                                  VALUES (%s, %s, %s, %s, %s, %s, %s)""", rows)
        try:
            karen = Browser("karen.villareal@agende.com", "password123").get("/provider/dashboard").get_data(as_text=True)
            self.assertIn("My forecast", karen)
            self.assertIn("This week (predicted)", karen)
            self.assertIn("myForecastChart", karen)
            miguel = staff().get("/provider/dashboard").get_data(as_text=True)      # provider 1: little history
            self.assertIn("Not enough history yet", miguel)
            html = admin().get("/admin/forecast").get_data(as_text=True)
            self.assertIn("Breakdown", html)
            self.assertIn("Dr. Karen Villareal", html)
            self.assertIn("Dental Cleaning", html)
        finally:
            run("DELETE FROM appointments WHERE user_id=6 AND provider_id=2 AND appointment_date BETWEEN %s AND %s AND notes IS NULL "
                "AND id NOT IN (SELECT appointment_id FROM appointment_history)", (first_monday, last_sunday))

if __name__ == "__main__":
    unittest.main()
