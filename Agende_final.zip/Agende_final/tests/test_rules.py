"""
Unit tests for the rules that do not need a database.
Run:  python -m unittest discover -s tests -v

Test-case IDs refer to blueprint section 34.
"""
import os
import sys
import unittest
from datetime import date, datetime, time, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agende import analytics  # noqa: E402
from agende import forecasting  # noqa: E402
from agende import scheduling as S  # noqa: E402
from agende import security  # noqa: E402

MONDAY = date(2026, 10, 26)
WINDOWS = [(time(8), time(12)), (time(13), time(17))]


def dt(h, m=0, day=MONDAY):
    return datetime.combine(day, time(h, m))


class OverlapRules(unittest.TestCase):
    def test_overlap_detected_TC017(self):
        self.assertTrue(S.overlaps(dt(10), dt(11), dt(10, 30), dt(11, 30)))

    def test_adjacent_allowed_TC018(self):
        self.assertFalse(S.overlaps(dt(10), dt(11), dt(11), dt(12)))

    def test_contained_and_identical(self):
        self.assertTrue(S.overlaps(dt(10), dt(12), dt(10, 30), dt(11)))
        self.assertTrue(S.overlaps(dt(10), dt(11), dt(10), dt(11)))


class SlotGeneration(unittest.TestCase):
    def states(self, slots):
        return {s["start"].strftime("%H:%M"): s["state"] for s in slots}

    def test_working_hours_and_break_TC012(self):
        slots = self.states(S.generate_slots(MONDAY, 60, WINDOWS, [], [], interval_minutes=30))
        self.assertIn("08:00", slots)
        self.assertNotIn("11:30", slots)       # would run into the 12:00 break
        self.assertNotIn("12:00", slots)       # break
        self.assertIn("16:00", slots)
        self.assertNotIn("16:30", slots)       # would end after 17:00

    def test_booked_and_adjacent(self):
        slots = self.states(S.generate_slots(MONDAY, 60, WINDOWS, [(dt(10), dt(11))], [], interval_minutes=30))
        self.assertEqual(slots["09:00"], S.SLOT_AVAILABLE)   # ends exactly at 10:00
        self.assertEqual(slots["09:30"], S.SLOT_BOOKED)
        self.assertEqual(slots["10:30"], S.SLOT_BOOKED)
        self.assertEqual(slots["11:00"], S.SLOT_AVAILABLE)   # starts exactly at 11:00

    def test_buffer_blocks_adjacent(self):
        slots = self.states(S.generate_slots(MONDAY, 60, WINDOWS, [(dt(10), dt(11))], [], interval_minutes=30, buffer_minutes=15))
        self.assertEqual(slots["11:00"], S.SLOT_BOOKED)      # blueprint 10.2 example
        self.assertEqual(slots["09:00"], S.SLOT_BOOKED)

    def test_blocked_period_TC013(self):
        slots = self.states(S.generate_slots(MONDAY, 30, WINDOWS, [], [(dt(14), dt(15))], interval_minutes=30))
        self.assertEqual(slots["14:00"], S.SLOT_BLOCKED)
        self.assertEqual(slots["14:30"], S.SLOT_BLOCKED)
        self.assertEqual(slots["15:00"], S.SLOT_AVAILABLE)

    def test_past_times_TC016(self):
        slots = self.states(S.generate_slots(MONDAY, 30, WINDOWS, [], [], interval_minutes=30, earliest_start=dt(10, 15)))
        self.assertEqual(slots["10:00"], S.SLOT_PAST)
        self.assertEqual(slots["10:30"], S.SLOT_AVAILABLE)

    def test_client_conflict_TC019(self):
        slots = self.states(S.generate_slots(MONDAY, 30, WINDOWS, [], [], interval_minutes=30, client_busy=[(dt(9), dt(9, 45))]))
        self.assertEqual(slots["09:30"], S.SLOT_CLASH)
        self.assertEqual(slots["10:00"], S.SLOT_AVAILABLE)

    def test_booking_window(self):
        slots = S.generate_slots(MONDAY, 30, WINDOWS, [], [], latest_day=MONDAY - timedelta(days=1))
        self.assertTrue(all(s["state"] == S.SLOT_TOO_FAR for s in slots))

    def test_time_conversion(self):
        self.assertEqual(S.to_time(timedelta(hours=9, minutes=30)), time(9, 30))
        self.assertEqual(S.to_time("14:05"), time(14, 5))
        self.assertIsNone(S.to_time("25:99"))


class StatusLifecycle(unittest.TestCase):
    def test_allowed(self):
        self.assertTrue(S.can_transition("pending", "confirmed"))
        self.assertTrue(S.can_transition("confirmed", "no_show"))

    def test_terminal_states_BR015_BR016(self):
        for terminal in ("completed", "no_show", "cancelled", "rejected", "expired"):
            for target in S.ALL_STATUSES:
                self.assertFalse(S.can_transition(terminal, target), (terminal, target))

    def test_no_skipping(self):
        self.assertFalse(S.can_transition("pending", "completed"))
        self.assertFalse(S.can_transition("confirmed", "rejected"))

    def test_role_permissions(self):
        self.assertTrue(S.role_may_set("user", "cancelled"))
        self.assertFalse(S.role_may_set("user", "confirmed"))
        self.assertTrue(S.role_may_set("provider", "no_show"))
        self.assertFalse(S.role_may_set("provider", "expired"))


class AnalyticsFormulas(unittest.TestCase):
    def test_rates_TC034(self):
        kpis = analytics.summarize_status_counts({"completed": 8, "no_show": 2, "cancelled": 5, "pending": 5})
        self.assertEqual(kpis["total"], 20)
        self.assertEqual(kpis["no_show_rate"], 20.0)          # 2 / (8 + 2)
        self.assertEqual(kpis["completion_rate"], 80.0)
        self.assertEqual(kpis["cancellation_rate"], 25.0)      # 5 / 20

    def test_cancelled_not_completed_BR028(self):
        kpis = analytics.summarize_status_counts({"cancelled": 3})
        self.assertEqual(kpis["completed"], 0)
        self.assertIsNone(kpis["completion_rate"])

    def test_available_minutes(self):
        minutes = analytics.available_minutes({0: WINDOWS}, [(dt(14), dt(15))], MONDAY, MONDAY + timedelta(days=6))
        self.assertEqual(minutes, 8 * 60 - 60)


class Forecasting(unittest.TestCase):
    def daily(self, weeks, per_week, start=MONDAY):
        data = {}
        for w in range(weeks):
            data[start + timedelta(days=7 * w + 2)] = {"total": per_week(w), "no_show": 1, "completed": 3, "cancelled": 0}
        return data

    def test_weekly_aggregation_fills_gaps_TC038(self):
        daily = {MONDAY: {"total": 5, "no_show": 1, "completed": 4, "cancelled": 0},
                 MONDAY + timedelta(days=14): {"total": 7, "no_show": 0, "completed": 7, "cancelled": 0}}
        weeks = forecasting.weekly_series(daily, MONDAY, MONDAY + timedelta(days=20))
        self.assertEqual([w["appointments"] for w in weeks], [5, 0, 7])

    def test_partial_edge_weeks_dropped(self):
        weeks = forecasting.weekly_series({}, MONDAY + timedelta(days=2), MONDAY + timedelta(days=30))
        self.assertEqual(weeks[0]["week_start"], MONDAY + timedelta(days=7))
        self.assertTrue(weeks[-1]["week_start"] + timedelta(days=6) <= MONDAY + timedelta(days=30))

    def test_ols_recovers_line_TC039(self):
        b0, b1 = forecasting.fit_ols([1, 2, 3, 4], [12, 14, 16, 18])
        self.assertAlmostEqual(b0, 10)
        self.assertAlmostEqual(b1, 2)

    def test_chronological_split_TC040(self):
        model = forecasting.build_model(list(range(10)), 2)
        self.assertEqual(model["train_weeks"], 8)
        self.assertEqual(model["test_actual"], [8, 9])          # the LAST weeks are the test set

    def test_forecast_values_TC041(self):
        result = forecasting.run_forecast(self.daily(10, lambda w: 20 + 3 * w), MONDAY, MONDAY + timedelta(days=69), 8, 4, "live")
        self.assertTrue(result["available"])
        self.assertEqual([f["appointments"] for f in result["future"]], [50, 53, 56, 59])
        self.assertAlmostEqual(result["appointment_model"]["mae"], 0)

    def test_negative_clamped_TC042(self):
        model = forecasting.build_model([10, 8, 6, 4, 2, 1, 0, 0, 0, 0], 3)
        self.assertTrue(all(v == 0 for v in model["future_display"]))
        self.assertTrue(any(v < 0 for v in model["future_raw"]))   # raw value retained

    def test_insufficient_data_TC043(self):
        result = forecasting.run_forecast(self.daily(5, lambda w: 10), MONDAY, MONDAY + timedelta(days=34), 8, 4, "live")
        self.assertFalse(result["available"])
        self.assertIn("Insufficient historical data", result["message"])

    def test_baseline_comparison(self):
        values = [10, 10, 10, 10, 10, 10, 10, 10, 14, 16]
        model = forecasting.build_model(values, 2)
        self.assertAlmostEqual(model["baseline_mae"], 5.0)        # train mean 10 vs test 14, 16
        self.assertAlmostEqual(model["skill_pct"], (1 - model["mae"] / 5.0) * 100)

    def test_saved_model_predicts_any_week(self):
        row = {"intercept": 20, "slope": 3, "training_start": MONDAY}
        self.assertEqual(forecasting.week_number(row, MONDAY), 1)
        self.assertEqual(forecasting.week_number(row, MONDAY + timedelta(days=7 * 12)), 13)
        self.assertEqual(forecasting.predict(row, MONDAY + timedelta(days=7 * 12)), (59.0, 59))
        # Same answer as the forecast produced at training time (TC041)
        result = forecasting.run_forecast(self.daily(10, lambda w: 20 + 3 * w), MONDAY, MONDAY + timedelta(days=69), 8, 4, "live")
        saved = {"intercept": result["appointment_model"]["intercept"], "slope": result["appointment_model"]["slope"],
                 "training_start": result["training_start"]}
        self.assertEqual([forecasting.predict(saved, f["week_start"])[1] for f in result["future"]],
                         [f["appointments"] for f in result["future"]])

    def test_matches_scikit_learn(self):
        try:
            from sklearn.linear_model import LinearRegression
        except ImportError:
            self.skipTest("scikit-learn not installed (optional cross-check)")
        ys = [575, 560, 584, 590, 571, 602, 566, 580, 593, 559, 588, 611]
        b0, b1 = forecasting.fit_ols(list(range(1, 13)), ys)
        sk = LinearRegression().fit([[x] for x in range(1, 13)], ys)
        self.assertAlmostEqual(b0, sk.intercept_, places=9)
        self.assertAlmostEqual(b1, sk.coef_[0], places=9)

    def test_dataset_csv_parsing(self):
        import tempfile
        with tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False, newline="") as handle:
            handle.write("appointment_id,appointment_date,appointment_status,appointment_duration,sex\n"
                         "1,2023-01-02,completed,196.0,Female\n2,2023-01-02,no_show,,Male\n3,2023-01-03,did not attend,30,F\n"
                         "4,,completed,30,M\n5,2023-01-04,unknown,30,M\n")
            path = handle.name
        try:
            rows, skipped = forecasting.read_history_csv(path)
        finally:
            os.unlink(path)
        self.assertEqual(skipped, 2)
        self.assertEqual([r[6] for r in rows], ["completed", "no_show", "no_show"])
        self.assertEqual(rows[0][3], 196)
        self.assertTrue(all(len(r) == 7 for r in rows))             # patient details are not kept


class Validation(unittest.TestCase):
    def test_password_policy(self):
        self.assertIsNotNone(security.validate_password("short1"))
        self.assertIsNotNone(security.validate_password("onlyletters"))
        self.assertIsNone(security.validate_password("goodpass1"))
        self.assertIsNotNone(security.validate_password("goodpass1", "different1"))

    def test_email_and_phone(self):
        self.assertIsNone(security.validate_email("a.b@example.com"))
        self.assertIsNotNone(security.validate_email("not-an-email"))
        self.assertIsNone(security.validate_phone("0917-000-0000"))
        self.assertIsNotNone(security.validate_phone("<script>"))

    def test_open_redirect_blocked(self):
        self.assertIsNone(security.safe_next_url("https://evil.example"))
        self.assertIsNone(security.safe_next_url("//evil.example"))
        self.assertEqual(security.safe_next_url("/user/dashboard"), "/user/dashboard")


if __name__ == "__main__":
    unittest.main()
