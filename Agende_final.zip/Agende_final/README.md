# AGENDÉ 3.2
### A Web-Based Multi-Appointment System for Scheduling, Managing, and Monitoring Appointments

Python (Flask) · MySQL (XAMPP) · Bootstrap 5 · Chart.js. Fonts, icons and charts are bundled, so it runs offline.

---

## Installation (manual)

**Needed:** Python 3.9+ ([python.org](https://www.python.org/downloads/), tick *Add python.exe to PATH*) and XAMPP.

### 1. Database (XAMPP / phpMyAdmin)
1. Open the XAMPP Control Panel and **Start** Apache and MySQL.
2. Open http://localhost/phpmyadmin and click the **Import** tab (with no database selected).
3. Import **`database/schema.sql`**. It creates `agende_db` with all tables, roles and default settings.
4. Import **`database/seed.sql`**. It adds the sample accounts, services, schedules and appointments.

### 2. MySQL login
Open **`agende/config.py`** and check `DB_USER` / `DB_PASSWORD` at the top. XAMPP's default is `root` with an empty
password, which is already set, so you only need to change it if your MySQL has a password.

### 3. Python libraries
Open PowerShell in the `AGENDE` folder (File Explorer → click the address bar → type `powershell` → Enter):
```
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
```
(`requirements.txt`: Flask, Werkzeug, PyMySQL, waitress. `python -m pip` also works on PCs that block `pip.exe`.)

### 4. Run
```
.venv\Scripts\python.exe app.py
```
Open **http://127.0.0.1:5000**. Keep the window open; press Ctrl+C to stop. Next time, only this step is needed.
Add `--lan` to let phones and laptops on the same Wi-Fi open it (the window prints the address).

| Role | Email | Password |
|---|---|---|
| Administrator | admin@agende.com | admin123 |
| Staff | provider@agende.com | provider123 |
| Client | user@agende.com | user123 |

### 5. Optional
- **Forecast model:** extract `AGENDE_appointment_history.csv` from `data/AGENDE_dataset_package.zip` into the folder, then
  ```
  .venv\Scripts\python.exe -m flask --app app train-forecast --csv AGENDE_appointment_history.csv
  ```
- **Demo data** (30 weeks of appointments, 150 demo clients, for trying dashboards):
  `.venv\Scripts\python.exe tools\seed_demo_data.py`
- **Tests:** `.venv\Scripts\python.exe -m unittest discover -s tests -v` (uses a separate `agende_test` database).
- **Backup:** phpMyAdmin → `agende_db` → Export, or `.venv\Scripts\python.exe -m flask --app app backup-db`.

---

## Features by role

**Client**: book from live availability (service → staff → date → time); view, reschedule or cancel within the cutoff;
history, calendar, notifications, profile.

**Staff**: dashboard with today's agenda, reminder priorities (advisory no-show risk on their own upcoming
appointments) and their own weekly forecast. Approve or decline requests, mark completed / did not attend,
reschedule or cancel with a reason, set weekly availability with breaks, block time, view their own analytics.

**Administrator**: organization dashboard (KPIs, trends, service mix, workload, alerts, forecast, no-show risk counts).
Manage all appointments and book for clients; manage clients, staff, services (with a no-show category), schedules,
users & roles and password resets. Analytics with filters. A trained, deployed forecast model with evaluation,
versions, rollback, automatic weekly retraining and a staff/service breakdown. CSV reports R001–R007, audit logs,
settings.

**System**: conflict detection, double-booking protection, appointment lifecycle with history, reminders and expiry
(run every 5 minutes while `app.py` runs), optional email, CSRF and session security, audit trail.

## Folder structure

```
app.py                     starts AGENDÉ (python app.py [--lan] [--port N] [--dev])
requirements.txt           Python libraries for the web app
agende/                    the application
    config.py              MySQL login and other settings   <-- the only file you may need to edit
    web.py                 Flask app, filters, request hooks, error pages
    routes/                pages: auth, shared, client, staff, admin, admin_manage, admin_insights
    scheduling.py          availability and conflict detection
    appointments.py        booking, reschedule, status changes
    notifications.py       notifications, reminders, housekeeping
    analytics.py           descriptive analytics
    forecasting.py         weekly linear-regression forecast model
    noshow_risk.py         advisory no-show risk (uses models/noshow_agende.json)
    noshow_scorer.py       scores that model in pure Python
    security.py audit.py settings_store.py database.py migrations.py db_diagnostics.py cli.py version.py
    models/                the deployed no-show model
    templates/ static/     pages, CSS, JavaScript, offline libraries
database/
    schema.sql             tables + reference data      (import 1st)
    seed.sql               sample accounts and data     (import 2nd)
data/
    AGENDE_dataset_package.zip   historical dataset (forecast training, model study)
tools/
    seed_demo_data.py      optional demo appointments
tests/                     99 automated tests
research/                  model study for the paper (not needed to run AGENDÉ)
    model_selection.py     baselines, tuning, model selection  -> docs/MODEL_SELECTION_REPORT.md
    forecast_experiment.py forecast CRISP-DM study            -> docs/FORECAST_MODEL_REPORT.md
    ml/                    study code and exported models
    requirements.txt       pandas, numpy, scikit-learn, matplotlib
docs/                      REVISION_NOTES, TESTING, FORECAST_MODEL_REPORT, MODEL_SELECTION_REPORT (+ charts)
```

## Troubleshooting

| Message | Fix |
|---|---|
| "MySQL server is not running" | Start MySQL in the XAMPP Control Panel. |
| "MySQL rejected the username or password" | Set `DB_USER` / `DB_PASSWORD` in `agende/config.py`. |
| "Database agende_db does not exist" | Import `database/schema.sql`, then `database/seed.sql`, in phpMyAdmin. |
| "The database is empty or from an older AGENDE version" | Export a backup, drop `agende_db`, import both SQL files again. |
| `pip.exe` / `flask.exe` blocked by an Application Control policy | Use `.venv\Scripts\python.exe -m pip ...` / `... -m flask ...` as shown above. |
| Other devices cannot connect | Start with `--lan`, allow Python in Windows Firewall (Private), use the printed `192.168.x.x` address. |
| Port 5000 in use | `.venv\Scripts\python.exe app.py --port 8080` |

## Notes for developers
- All SQL uses `%s` placeholders; `with db_cursor(commit=True) as cursor:` saves everything in the block, or nothing.
- Every POST form contains `{{ csrf_field() }}`.
- Booking rules are changed in the app (Admin → Settings). The lifecycle (`TRANSITIONS`) is at the top of
  `agende/scheduling.py`; KPI formulas at the top of `agende/analytics.py`.
- Model study: `python -m pip install -r research/requirements.txt`, then
  `python research/model_selection.py data/AGENDE_dataset_package.zip`.
