# =========================================================
# APP.PY - start AGENDÉ
#
#   python app.py                 serve on http://127.0.0.1:5000 (this computer only)
#   python app.py --lan           serve to other devices on the same Wi-Fi / network
#   python app.py --port 8080     another port
#   python app.py --dev           Flask development mode (auto-reload, debugger) - never for respondents
#
# Production server: waitress (installed from requirements.txt). Without it,
# a multi-threaded Werkzeug server is used. Reminders/expiry/forecast
# retraining run every 5 minutes in the background while the server is up.
#
# Settings (MySQL login, port) are in agende/config.py.
# The Flask app object is `app`, so commands work as:
#   python -m flask --app app housekeeping | train-forecast | backup-db
# =========================================================
import argparse
import socket
import sys
import threading

from agende import VERSION, app, config  # noqa: F401  (app is used by "flask --app app")

HOUSEKEEPING_EVERY_SECONDS = 300


def lan_address():
    """This computer's address on the local network (for the --lan message)."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def start_housekeeping_thread():
    """Run reminders / expiry / forecast retraining / email every few minutes."""
    from agende.database import db_cursor
    from agende.notifications import run_housekeeping
    from agende.settings_store import get_settings

    stop = threading.Event()

    def loop():
        while not stop.wait(HOUSEKEEPING_EVERY_SECONDS):
            try:
                run_housekeeping(db_cursor, get_settings)
            except Exception as error:          # never stop the loop
                app.logger.warning("Housekeeping failed: %s", error)

    threading.Thread(target=loop, name="agende-housekeeping", daemon=True).start()
    return stop


def preflight():
    """Stop early with a clear message if the database is not reachable or not up to date."""
    from agende import migrations
    from agende.db_diagnostics import explain
    try:
        conn = migrations.server_connection()
        cursor = conn.cursor()
        if not migrations.database_exists(cursor):
            print(f"\n  Database '{config.DB_NAME}' does not exist yet. In phpMyAdmin, import database/schema.sql, then database/seed.sql.\n")
            return False
        cursor.execute(f"USE `{config.DB_NAME}`")
        missing = migrations.missing_parts(cursor)
        conn.close()
        if missing is None or missing:
            print("\n  The database is empty or from an older AGENDE version.")
            print("  In phpMyAdmin: export it as a backup, drop agende_db, then import database/schema.sql and database/seed.sql.\n")
            return False
        return True
    except Exception as error:
        title, advice = explain(error) if hasattr(error, "args") else ("Database error", str(error))
        print(f"\n  {title}.\n  {advice}\n  Details: {error}\n")
        return False


def main(argv=None):
    parser = argparse.ArgumentParser(description="Start AGENDÉ")
    parser.add_argument("--lan", action="store_true", help="serve to other devices on the network (host 0.0.0.0)")
    parser.add_argument("--host", default=None, help=f"address to listen on (default {config.HOST})")
    parser.add_argument("--port", type=int, default=config.PORT)
    parser.add_argument("--dev", action="store_true", help="Flask development server with auto-reload and debugger")
    parser.add_argument("--skip-check", action="store_true", help="start even if the database check fails")
    args = parser.parse_args(argv)
    host = args.host or ("0.0.0.0" if args.lan else config.HOST)

    print(f"AGENDÉ {VERSION}")
    if not args.skip_check and not preflight():
        return 1

    if args.dev:
        app.run(host=host, port=args.port, debug=True)
        return 0

    start_housekeeping_thread()
    local = f"http://127.0.0.1:{args.port}"
    print(f"  Open {local} in your browser.")
    if host == "0.0.0.0":
        print(f"  Other devices on this network: http://{lan_address()}:{args.port}"
              "  (allow Python through Windows Firewall if asked)")
    print("  Press Ctrl+C to stop.")
    try:
        from waitress import serve
        serve(app, host=host, port=args.port, threads=config.THREADS, ident="AGENDE")
    except ImportError:
        from werkzeug.serving import run_simple
        print("  (waitress is not installed; using the built-in threaded server. "
              "Install it with: python -m pip install waitress)")
        run_simple(host, args.port, app, threaded=True, use_reloader=False, use_debugger=False)
    return 0


if __name__ == "__main__":
    sys.exit(main())
