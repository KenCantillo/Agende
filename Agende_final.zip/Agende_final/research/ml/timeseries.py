"""
Weekly time-series forecasting: baselines, tuned candidate models and walk-forward
evaluation. Used by research/model_selection.py.

Targets (blueprint 15.2): appointments per week and did-not-attend (no-show) count per week,
built exactly like the system does (complete Monday-Sunday weeks, forecasting.weekly_series).

Evaluation is walk-forward (rolling origin): at every origin the model sees only the weeks
before it, forecasts the next 4 weeks (the system's horizon), and the errors over all
origins and horizons are averaged.
    weeks  1-62   : warm-up / training only
    weeks 63-83   : VALIDATION origins (hyper-parameters and model choice)
    weeks 84-104  : TEST origins (touched once, for the report)
"""
import itertools
import warnings

import numpy as np
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.linear_model import Ridge

H = 4
VAL_START, TEST_START = 62, 83          # 0-based week index where each segment begins


# ---------------------------------------------------------------- models
# Each model: f(history: np.ndarray, h: int, **params) -> np.ndarray of h forecasts
def naive(y, h):
    return np.full(h, y[-1], float)


def mean(y, h):
    return np.full(h, y.mean())


def seasonal_naive(y, h, season=52):
    return np.array([y[len(y) - season + i] for i in range(h)], float)


def moving_average(y, h, window):
    return np.full(h, y[-window:].mean())


def linear_trend(y, h, window=None):
    """The blueprint model: OLS on week number (optionally only the last `window` weeks)."""
    yy = y if window is None else y[-window:]
    x = np.arange(len(yy), dtype=float)
    b1, b0 = np.polyfit(x, yy, 1)
    return b0 + b1 * np.arange(len(yy), len(yy) + h)


def ses(y, h, alpha):
    level = y[0]
    for v in y[1:]:
        level = alpha * v + (1 - alpha) * level
    return np.full(h, level)


def holt(y, h, alpha, beta, phi):
    """Holt's linear trend with damping phi (phi = 1: undamped)."""
    level, trend = y[0], y[1] - y[0]
    for v in y[1:]:
        prev = level
        level = alpha * v + (1 - alpha) * (level + phi * trend)
        trend = beta * (level - prev) + (1 - beta) * phi * trend
    return np.array([level + sum(phi ** k for k in range(1, i + 1)) * trend for i in range(1, h + 1)])


def _lag_matrix(y, p, trend):
    rows, target = [], []
    for t in range(p, len(y)):
        row = list(y[t - p:t][::-1])
        if trend:
            row.append(t)
        rows.append(row)
        target.append(y[t])
    return np.array(rows, float), np.array(target, float)


def _recursive(model, y, h, p, trend):
    hist = list(y)
    out = []
    for _ in range(h):
        t = len(hist)
        row = hist[-p:][::-1] + ([t] if trend else [])
        v = float(model.predict(np.array([row], float))[0])
        out.append(v)
        hist.append(v)
    return np.array(out)


def ridge_ar(y, h, p, alpha, trend):
    X, t = _lag_matrix(y, p, trend)
    return _recursive(Ridge(alpha=alpha).fit(X, t), y, h, p, trend)


def hgb_lags(y, h, p, learning_rate, max_iter, max_leaf_nodes, trend):
    X, t = _lag_matrix(y, p, trend)
    model = HistGradientBoostingRegressor(learning_rate=learning_rate, max_iter=max_iter, max_leaf_nodes=max_leaf_nodes,
                                          min_samples_leaf=5, random_state=42).fit(X, t)
    return _recursive(model, y, h, p, trend)


def grid(**axes):
    keys = list(axes)
    return [dict(zip(keys, combo)) for combo in itertools.product(*(axes[k] for k in keys))]


MODELS = {
    # name: (label, function, parameter grid, family)
    "naive": ("Baseline: naive (last week repeated)", naive, [{}], "baseline"),
    "mean": ("Baseline: historical mean", mean, [{}], "baseline"),
    "seasonal_naive": ("Baseline: seasonal naive (same week last year)", seasonal_naive, [{}], "baseline"),
    "linear_all": ("Linear regression trend, all weeks (blueprint 3.1 model)", linear_trend, [{"window": None}], "baseline"),
    "moving_average": ("Moving average", moving_average, grid(window=[2, 4, 6, 8, 12, 16, 26, 39, 52]), "tuned"),
    "linear_window": ("Linear regression trend, tuned training window", linear_trend,
                      grid(window=[13, 20, 26, 39, 52, 78]), "tuned"),
    "ses": ("Simple exponential smoothing", ses, grid(alpha=[0.02, 0.05, 0.1, 0.15, 0.2, 0.3, 0.5, 0.7]), "tuned"),
    "holt": ("Holt's linear trend (damped)", holt,
             grid(alpha=[0.05, 0.1, 0.2, 0.3], beta=[0.01, 0.05, 0.1, 0.2], phi=[0.8, 0.9, 0.98, 1.0]), "tuned"),
    "ridge_ar": ("Ridge autoregression (lags + trend)", ridge_ar,
                 grid(p=[1, 2, 4, 8, 13], alpha=[0.1, 1, 10, 100, 1000], trend=[False, True]), "tuned"),
    "hgb_lags": ("Gradient boosting on lags", hgb_lags,
                 grid(p=[4, 8, 13], learning_rate=[0.03, 0.1], max_iter=[50, 150], max_leaf_nodes=[4, 8], trend=[False, True]),
                 "tuned"),
}


# ---------------------------------------------------------------- evaluation
def walk_forward(y, fn, params, start, end):
    """Errors of h-step forecasts for every origin in [start, end); only weeks < end are scored."""
    errs, by_h, preds = [], {i: [] for i in range(1, H + 1)}, []
    for origin in range(start, end):
        f = fn(y[:origin], H, **params)
        for i in range(H):
            t = origin + i
            if t >= end:
                break
            e = y[t] - f[i]
            errs.append(e)
            by_h[i + 1].append(abs(e))
        preds.append((origin, f[0]))
    e = np.array(errs)
    actual = y[start:end]
    return {"mae": float(np.abs(e).mean()), "rmse": float(np.sqrt((e ** 2).mean())),
            "mape": float(np.mean(np.abs(e) / np.mean(actual)) * 100),
            "mae_h": {k: float(np.mean(v)) for k, v in by_h.items()}, "one_step": preds}


def evaluate_target(y, log=print):
    """Tune every model on validation origins, then score the chosen configuration on test origins."""
    warnings.filterwarnings("ignore")
    y = np.asarray(y, float)
    out = {}
    for name, (label, fn, space, family) in MODELS.items():
        trials = []
        for params in space:
            r = walk_forward(y, fn, params, VAL_START, TEST_START)
            trials.append((r["mae"], params))
        trials.sort(key=lambda t: t[0])
        best = trials[0][1]
        out[name] = {"label": label, "family": family, "params": best, "configs": len(space),
                     "val": walk_forward(y, fn, best, VAL_START, TEST_START),
                     "test": walk_forward(y, fn, best, TEST_START, len(y))}
    return out


def fit_final(y, name, params, h=H):
    """Forecast the next h weeks after the last observed week with all data."""
    return MODELS[name][1](np.asarray(y, float), h, **params)


# ---------------------------------------------------------------- selection
SIMPLICITY = {"naive": 0, "mean": 1, "seasonal_naive": 1, "moving_average": 2, "ses": 3, "linear_all": 4,
              "linear_window": 4, "holt": 5, "ridge_ar": 6, "hgb_lags": 7}


def origin_errors(y, name, params, start, end):
    """Mean absolute error per origin (over its horizons) -> array, for block bootstrap."""
    fn = MODELS[name][1]
    y = np.asarray(y, float)
    out = []
    for origin in range(start, end):
        f = fn(y[:origin], H, **params)
        k = min(H, end - origin)
        out.append(np.abs(y[origin:origin + k] - f[:k]).mean())
    return np.array(out)


def select(series, results, n_boot=4000, seed=42):
    """One model family for both targets.
    Score = mean over targets of (validation MAE / naive validation MAE).
    The best-scoring family is compared with every simpler family by a block bootstrap over
    validation origins; the simplest family whose score is not significantly worse
    (95% interval of the difference includes 0) is chosen."""
    targets = list(series)
    per = {t: {n: origin_errors(series[t], n, results[t][n]["params"], VAL_START, TEST_START) / results[t]["naive"]["val"]["mae"]
               for n in MODELS} for t in targets}
    score = {n: float(np.mean([per[t][n].mean() for t in targets])) for n in MODELS}
    best = min(score, key=score.get)
    rng = np.random.default_rng(seed)
    n = len(next(iter(per.values()))[best])
    idx = rng.integers(0, n, size=(n_boot, n))
    tests = {}
    for name in MODELS:
        diff = np.mean([per[t][name][idx].mean(axis=1) - per[t][best][idx].mean(axis=1) for t in targets], axis=0)
        lo, hi = np.percentile(diff, [2.5, 97.5])
        tests[name] = {"score": score[name], "diff": score[name] - score[best], "ci": (float(lo), float(hi)),
                       "tied": bool(lo <= 0)}
    tied = [m for m in MODELS if tests[m]["tied"]]
    chosen = min(tied, key=lambda m: (SIMPLICITY[m], score[m]))
    return {"best_score": best, "chosen": chosen, "tests": tests}
