"""
No-show (did-not-attend) prediction: data preparation, baselines, tuned candidate
models, model selection and evaluation. Used by research/model_selection.py.

Target: did_not_attend (1 = the client did not attend).
Population: appointments that were NOT cancelled. A cancelled booking can never be
"attended" or "missed", and cancellations are known before the appointment, so at the
moment staff would use a risk score (reminder time) only still-active bookings matter.
The README's all-rows definition is evaluated too, as a sensitivity check.

Split: chronological by appointment date (never random), because the no-show rate drifts
upward over 2023-2024:
    train       2023-01-01 .. 2024-03-31
    validation  2024-04-01 .. 2024-08-31   (hyper-parameter tuning, model choice, threshold)
    test        2024-09-01 .. 2024-12-31   (touched once, for the final report)
"""
import time
import warnings

import numpy as np
import sklearn
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, average_precision_score, brier_score_loss, f1_score,
                             precision_recall_curve, precision_score, recall_score, roc_auc_score)
from sklearn.model_selection import ParameterSampler
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import KBinsDiscretizer, OneHotEncoder, OrdinalEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

SEED = 42
TRAIN_END, VAL_END = pd.Timestamp("2024-03-31"), pd.Timestamp("2024-08-31")

# Feature sets ---------------------------------------------------------------
# FULL: everything in the dataset that is known before the appointment (no IDs, no outcome).
# History counts enter as log(1 + count): a regular client with 200 visits must not look 40x
# "riskier" than the clients the model learned from (median 3 earlier visits).
FULL_NUM = ["scheduling_interval", "age", "is_first_visit", "log_prior_appointments", "log_prior_no_shows",
            "log_prior_cancellations", "prior_no_show_rate", "prior_cancel_rate", "has_history", "reminder_sent",
            "deposit_paid", "daily_bookings_in_category", "hour"]
FULL_CAT = ["sex", "appointment_category", "reason_for_appointment", "provider_id", "booking_channel",
            "day_of_week", "weather"]
# AGENDE: only what AGENDE records or can compute from its own tables
# (lead time, service, time, day, the client's own appointment history, bookings that day).
AGENDE_NUM = ["scheduling_interval", "is_first_visit", "log_prior_appointments", "log_prior_no_shows", "log_prior_cancellations",
              "prior_no_show_rate", "prior_cancel_rate", "has_history", "daily_bookings_in_category", "hour"]
AGENDE_CAT = ["appointment_category", "day_of_week"]
FEATURE_SETS = {"full": (FULL_NUM, FULL_CAT), "agende": (AGENDE_NUM, AGENDE_CAT)}
EXCLUDED = {"appointment_id": "identifier (README: never a feature)",
            "historical_outcome": "is the outcome (leakage)",
            "scheduling_date / appointment_date": "used only to split by time",
            "age_group": "duplicate of age"}


def load(path):
    d = pd.read_csv(path, parse_dates=["scheduling_date", "appointment_date"])
    t = d["appointment_time"].str.split(":", expand=True).astype(int)
    d["hour"] = t[0] + t[1] / 60
    d["has_history"] = (d["prior_appointments"] > 0).astype(int)
    denom = d["prior_appointments"].where(d["prior_appointments"] > 0)
    d["prior_no_show_rate"] = (d["prior_no_shows"] / denom).fillna(0.0)
    d["prior_cancel_rate"] = (d["prior_cancellations"] / denom).fillna(0.0)
    for c in ("prior_appointments", "prior_no_shows", "prior_cancellations"):
        d["log_" + c] = np.log1p(d[c])
    return d


def audit(d):
    """Data understanding facts for the report."""
    return {
        "rows": len(d), "columns": d.shape[1] - 4,
        "start": d["appointment_date"].min().date(), "end": d["appointment_date"].max().date(),
        "missing": int(d.isna().sum().sum()), "duplicate_ids": int(d["appointment_id"].duplicated().sum()),
        "outcomes": d["historical_outcome"].value_counts().to_dict(),
        "booking_before_appointment": bool((d["scheduling_date"] <= d["appointment_date"]).all()),
        "interval_matches_dates": bool(((d["appointment_date"] - d["scheduling_date"]).dt.days == d["scheduling_interval"]).all()),
        "first_visit_with_prior": int(((d["is_first_visit"] == 1) & (d["prior_appointments"] > 0)).sum()),
        "rate_by_quarter": d.groupby(d["appointment_date"].dt.to_period("Q"))["did_not_attend"].mean().round(4).to_dict(),
        "rate_by_prior_no_shows": d.groupby(d["prior_no_shows"].clip(0, 4))["did_not_attend"].mean().round(4).to_dict(),
    }


def split(d, population="active"):
    if population == "active":
        d = d[d["historical_outcome"] != "cancelled"]
    tr = d[d["appointment_date"] <= TRAIN_END]
    va = d[(d["appointment_date"] > TRAIN_END) & (d["appointment_date"] <= VAL_END)]
    te = d[d["appointment_date"] > VAL_END]
    return tr, va, te


# Preprocessing ----------------------------------------------------------------
def linear_prep(num, cat):
    return ColumnTransformer([("num", StandardScaler(), num),
                              ("cat", OneHotEncoder(handle_unknown="ignore", min_frequency=20), cat)])


def tree_prep(num, cat):
    return ColumnTransformer([("num", "passthrough", num),
                              ("cat", OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1,
                                                     encoded_missing_value=-1), cat)])


BINARY = {"is_first_visit", "has_history", "reminder_sent", "deposit_paid"}
SKLEARN_18 = tuple(int(x) for x in sklearn.__version__.split(".")[:2]) >= (1, 8)


def logistic(params):
    """l1_ratio 0/1 = L2/L1. scikit-learn >= 1.8 deprecates 'penalty'; older versions need it."""
    p = dict(params)
    ratio = p.pop("l1_ratio", 0)
    if SKLEARN_18:
        p["l1_ratio"] = ratio
    else:
        p["penalty"] = "l1" if ratio == 1 else "l2"
    return LogisticRegression(max_iter=3000, solver="liblinear", random_state=SEED, **p)


def binned_prep(num, cat, n_bins):
    cont = [c for c in num if c not in BINARY]
    binary = [c for c in num if c in BINARY]
    kw = {"quantile_method": "averaged_inverted_cdf"} if SKLEARN_18 else {}
    return ColumnTransformer([("bins", KBinsDiscretizer(n_bins=n_bins, encode="onehot", strategy="quantile", **kw), cont),
                              ("bin", "passthrough", binary),
                              ("cat", OneHotEncoder(handle_unknown="ignore", min_frequency=20), cat)])


def build(name, params, num, cat):
    p = dict(params)
    if name == "logistic":
        return Pipeline([("prep", linear_prep(num, cat)), ("model", logistic(p))])
    if name == "logistic_binned":
        n_bins = p.pop("n_bins")
        return Pipeline([("prep", binned_prep(num, cat, n_bins)), ("model", logistic(p))])
    if name == "tree":
        return Pipeline([("prep", tree_prep(num, cat)), ("model", DecisionTreeClassifier(random_state=SEED, **p))])
    if name == "forest":
        return Pipeline([("prep", tree_prep(num, cat)),
                         ("model", RandomForestClassifier(random_state=SEED, n_jobs=-1, **p))])
    if name == "hgb":
        cat_mask = [False] * len(num) + [True] * len(cat)
        return Pipeline([("prep", tree_prep(num, cat)),
                         ("model", HistGradientBoostingClassifier(random_state=SEED, categorical_features=cat_mask, **p))])
    raise ValueError(name)


SPACES = {
    "logistic": {"C": [0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1, 3, 10], "l1_ratio": [0, 1],
                 "class_weight": [None, "balanced"]},
    "logistic_binned": {"n_bins": [4, 6, 8, 10, 12], "C": [0.01, 0.03, 0.1, 0.3, 1, 3], "l1_ratio": [0, 1],
                        "class_weight": [None, "balanced"]},
    "tree": {"max_depth": [3, 4, 5, 6, 8, 10, 12], "min_samples_leaf": [20, 50, 100, 200, 400],
             "class_weight": [None, "balanced"], "criterion": ["gini", "entropy"]},
    "forest": {"n_estimators": [200, 400], "max_depth": [6, 8, 10, 14, None], "min_samples_leaf": [5, 10, 20, 50, 100],
               "max_features": ["sqrt", 0.3, 0.5], "class_weight": [None, "balanced_subsample"]},
    "hgb": {"learning_rate": [0.02, 0.03, 0.05, 0.08, 0.1], "max_iter": [150, 300, 500], "max_leaf_nodes": [7, 15, 31],
            "max_depth": [3, 4, 6, None], "min_samples_leaf": [50, 100, 200, 400], "l2_regularization": [0, 0.1, 1, 5],
            "class_weight": [None, "balanced"]},
}
N_ITER = {"logistic": 36, "logistic_binned": 30, "tree": 30, "forest": 18, "hgb": 40}
LABELS = {"logistic": "Logistic regression", "logistic_binned": "Logistic regression with binned numbers (scorecard)",
          "tree": "Decision tree", "forest": "Random forest",
          "hgb": "Gradient boosting (HistGradientBoosting)"}


def scores(y, p, threshold=None):
    out = {"pr_auc": average_precision_score(y, p), "roc_auc": roc_auc_score(y, p), "brier": brier_score_loss(y, p)}
    if threshold is not None:
        pred = (p >= threshold).astype(int)
        out.update({"threshold": threshold, "precision": precision_score(y, pred, zero_division=0),
                    "recall": recall_score(y, pred), "f1": f1_score(y, pred), "accuracy": accuracy_score(y, pred),
                    "flagged_pct": pred.mean() * 100})
    return out


def prior_correct(p, shift):
    p = np.clip(p, 1e-12, 1 - 1e-12)
    return 1 / (1 + np.exp(-(np.log(p / (1 - p)) - shift)))


def best_f1_threshold(y, p):
    prec, rec, thr = precision_recall_curve(y, p)
    f1 = 2 * prec * rec / np.clip(prec + rec, 1e-12, None)
    i = int(np.nanargmax(f1[:-1]))
    return float(thr[i])


def tune(name, tr, va, num, cat, log=print):
    """Random search; every configuration is trained on TRAIN and scored on VALIDATION (PR-AUC)."""
    X_tr, y_tr, X_va, y_va = tr[num + cat], tr["did_not_attend"], va[num + cat], va["did_not_attend"]
    trials = []
    t0 = time.time()
    for params in ParameterSampler(SPACES[name], n_iter=N_ITER[name], random_state=SEED):
        model = build(name, params, num, cat).fit(X_tr, y_tr)
        p = model.predict_proba(X_va)[:, 1]
        trials.append({"params": params, "pr_auc": average_precision_score(y_va, p), "roc_auc": roc_auc_score(y_va, p)})
    trials.sort(key=lambda t: -t["pr_auc"])
    log(f"    {name}: {len(trials)} configs in {time.time() - t0:.0f}s, best val PR-AUC {trials[0]['pr_auc']:.4f}")
    return trials


SIMPLICITY = {"logistic": 0, "logistic_binned": 1, "tree": 2, "forest": 3, "hgb": 4}


def select(results, fs, y_va, n_boot=2000, seed=SEED):
    cands = {k[1]: r for k, r in results.items() if k[0] == fs}
    top = max(cands, key=lambda n: cands[n]["val"]["pr_auc"])
    rng = np.random.default_rng(seed)
    y = np.asarray(y_va)
    idx = [rng.integers(0, len(y), len(y)) for _ in range(n_boot)]
    tests = {}
    for name, r in cands.items():
        diffs = []
        for i in idx:
            if y[i].sum() == 0:
                continue
            diffs.append(average_precision_score(y[i], r["p_val"][i]) - average_precision_score(y[i], cands[top]["p_val"][i]))
        lo, hi = np.percentile(diffs, [2.5, 97.5])
        tests[name] = {"pr_auc": r["val"]["pr_auc"], "diff": r["val"]["pr_auc"] - cands[top]["val"]["pr_auc"],
                       "ci": (float(lo), float(hi)), "tied": bool(hi >= 0)}
    tied = [n for n in cands if tests[n]["tied"]]
    chosen = min(tied, key=lambda n: (SIMPLICITY[n], -tests[n]["pr_auc"]))
    return {"top": top, "chosen": chosen, "tests": tests}


def run(path, log=print):
    warnings.filterwarnings("ignore", category=UserWarning)      # KBins duplicate-edge notices
    warnings.filterwarnings("ignore", category=FutureWarning)
    d = load(path)
    info = {"audit": audit(d)}
    tr, va, te = split(d, "active")
    info["split"] = {k: {"rows": len(x), "rate": x["did_not_attend"].mean(), "start": x["appointment_date"].min().date(),
                         "end": x["appointment_date"].max().date()} for k, x in (("train", tr), ("validation", va), ("test", te))}
    y_va, y_te = va["did_not_attend"].values, te["did_not_attend"].values
    results = {}

    # Baselines ----------------------------------------------------------------
    base = {}
    prior = tr["did_not_attend"].mean()
    base["majority"] = {"label": "Baseline: always 'attends' (majority class)",
                        "val": scores(y_va, np.full(len(va), prior), 0.5), "test": scores(y_te, np.full(len(te), prior), 0.5)}
    rule_va, rule_te = (va["prior_no_shows"] > 0).astype(float).values, (te["prior_no_shows"] > 0).astype(float).values
    base["rule"] = {"label": "Baseline: rule 'missed before -> will miss'", "val": scores(y_va, rule_va, 0.5),
                    "test": scores(y_te, rule_te, 0.5)}
    num, cat = FEATURE_SETS["full"]
    lr0 = build("logistic", {}, num, cat).fit(tr[num + cat], tr["did_not_attend"])
    p_va, p_te = lr0.predict_proba(va[num + cat])[:, 1], lr0.predict_proba(te[num + cat])[:, 1]
    thr = best_f1_threshold(y_va, p_va)
    base["logistic_default"] = {"label": "Baseline: logistic regression, default settings",
                                "val": scores(y_va, p_va, thr), "test": scores(y_te, p_te, thr)}
    info["baselines"] = base
    log("  baselines done")

    # Tuned candidates on both feature sets ------------------------------------------
    for fs, (num, cat) in FEATURE_SETS.items():
        log(f"  feature set: {fs}")
        for name in SPACES:
            trials = tune(name, tr, va, num, cat, log)
            best = trials[0]
            model = build(name, best["params"], num, cat).fit(tr[num + cat], tr["did_not_attend"])
            p_va, p_te = model.predict_proba(va[num + cat])[:, 1], model.predict_proba(te[num + cat])[:, 1]
            shift = 0.0
            if name.startswith("logistic") and best["params"].get("class_weight") == "balanced":
                # Prior correction (King & Zeng 2001): class weighting only moves the intercept by
                # log(n0/n1); undo it so the probabilities are real no-show probabilities again.
                n1 = int(tr["did_not_attend"].sum())
                shift = float(np.log((len(tr) - n1) / n1))
                p_va, p_te = prior_correct(p_va, shift), prior_correct(p_te, shift)
            thr = best_f1_threshold(y_va, p_va)
            results[(fs, name)] = {"label": LABELS[name], "feature_set": fs, "params": best["params"], "trials": trials,
                                   "val": scores(y_va, p_va, thr), "test": scores(y_te, p_te, thr),
                                   "model": model, "p_val": p_va, "p_test": p_te, "intercept_shift": shift}
    info["candidates"] = results

    # Selection: highest VALIDATION PR-AUC; a simpler model that is not significantly worse
    # (paired bootstrap of the validation set, 95% interval of the difference includes 0) wins.
    info["selection"] = {}
    for fs in FEATURE_SETS:
        info["selection"][fs] = select(results, fs, y_va)
        log(f"  selected ({fs}): {info['selection'][fs]['chosen']} (top score: {info['selection'][fs]['top']})")
    info["best_full"] = ("full", info["selection"]["full"]["chosen"])
    info["best_agende"] = ("agende", info["selection"]["agende"]["chosen"])

    # Sensitivity: README target (cancelled rows as 0) with the chosen AGENDE config -----------
    fs, name = info["best_agende"]
    num, cat = FEATURE_SETS[fs]
    tr2, va2, te2 = split(d, "all")
    m2 = build(name, results[(fs, name)]["params"], num, cat).fit(tr2[num + cat], tr2["did_not_attend"])
    info["sensitivity_all_rows"] = {"val": scores(va2["did_not_attend"], m2.predict_proba(va2[num + cat])[:, 1]),
                                    "test": scores(te2["did_not_attend"], m2.predict_proba(te2[num + cat])[:, 1]),
                                    "rows": len(tr2) + len(va2) + len(te2)}
    info["frames"] = (tr, va, te, d)
    return info
