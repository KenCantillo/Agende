"""
CRISP-DM modeling experiment for the AGENDE forecast models (blueprint 15-16).

    python research/forecast_experiment.py path/to/AGENDE_appointment_history.csv
    python research/forecast_experiment.py history.csv --out docs

Reads the CSV directly (no database needed) and writes:
    <out>/FORECAST_MODEL_REPORT.md     the full write-up (data understanding -> deployment)
    <out>/forecast_dataset_weekly.csv  the prepared "forecasting dataset" (blueprint 40)
    <out>/forecast_model.json          the trained model file (same format the app exports)
    <out>/img/*.png                    charts (only if matplotlib is installed)

It uses the SAME functions the system uses (forecasting.py), so what the report
evaluates is exactly what the Forecast page trains and deploys. It also answers
the open design question in blueprint A-010 / 15.11: how many weeks of history
are needed before a model should be trained.
"""
import csv
import json
import math
import os
import sys
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "research"))

from agende import forecasting as fc  # noqa: E402

HORIZON = 4
CANDIDATE_WINDOWS = [4, 6, 8, 10, 12, 16, 20, 26, 32, 39, 52]
TOLERANCE = 0.10          # "within 10% of the error of the longest window"


# ---------------------------------------------------------------- helpers
def solve_least_squares(rows, ys):
    """Multiple linear regression by the normal equations (X'X)b = X'y, Gaussian elimination."""
    k = len(rows[0])
    a = [[sum(r[i] * r[j] for r in rows) for j in range(k)] + [sum(r[i] * y for r, y in zip(rows, ys))] for i in range(k)]
    for col in range(k):
        pivot = max(range(col, k), key=lambda r: abs(a[r][col]))
        a[col], a[pivot] = a[pivot], a[col]
        if abs(a[col][col]) < 1e-12:
            continue
        for r in range(k):
            if r != col:
                f = a[r][col] / a[col][col]
                a[r] = [x - f * y for x, y in zip(a[r], a[col])]
    return [a[i][k] / a[i][i] if abs(a[i][i]) > 1e-12 else 0.0 for i in range(k)]


def slope_inference(xs, ys):
    """Slope, its standard error, t statistic and a two-sided p-value (normal approximation)."""
    n = len(xs)
    b0, b1 = fc.fit_ols(xs, ys)
    resid = [y - (b0 + b1 * x) for x, y in zip(xs, ys)]
    s2 = sum(e * e for e in resid) / (n - 2)
    mean_x = sum(xs) / n
    se = math.sqrt(s2 / sum((x - mean_x) ** 2 for x in xs))
    t = b1 / se if se else float("inf")
    p = math.erfc(abs(t) / math.sqrt(2))
    return b0, b1, se, t, p


def fmt(v, d=3):
    return "N/A" if v is None else f"{v:.{d}f}"


def evaluate_candidates(weeks, key):
    """Chronological 80/20 comparison of the blueprint model with baselines and 15.6 extras."""
    y = [float(w[key]) for w in weeks]
    n = len(y)
    split = fc.chronological_split(n)
    xs = list(range(1, n + 1))
    test = y[split:]
    out = []

    b0, b1 = fc.fit_ols(xs[:split], y[:split])
    out.append(("Trend  Y = b0 + b1*week  (blueprint 15.4/15.5)", fc.metrics(test, [b0 + b1 * x for x in xs[split:]])))
    mean = sum(y[:split]) / split
    out.append(("Baseline: average training week", fc.metrics(test, [mean] * (n - split))))
    last8 = sum(y[split - 8:split]) / 8
    out.append(("Baseline: average of last 8 training weeks", fc.metrics(test, [last8] * (n - split))))
    out.append(("Baseline: last training week repeated", fc.metrics(test, [y[split - 1]] * (n - split))))

    # 15.6 extras: previous-period count (one-step-ahead, uses the actual previous week)
    rows = [[1.0, xs[i], y[i - 1]] for i in range(1, n)]
    coef = solve_least_squares(rows[:split - 1], y[1:split])
    pred = [sum(c * v for c, v in zip(coef, r)) for r in rows[split - 1:]]
    out.append(("Trend + previous-week count (15.6, one step ahead)", fc.metrics(y[split:], pred)))

    # 15.6 extras: month of year (11 dummy variables)
    def month_row(i):
        m = weeks[i]["week_start"].month
        return [1.0, xs[i]] + [1.0 if m == mm else 0.0 for mm in range(2, 13)]
    rows = [month_row(i) for i in range(n)]
    coef = solve_least_squares(rows[:split], y[:split])
    out.append(("Trend + month of year (15.6)", fc.metrics(test, [sum(c * v for c, v in zip(coef, r)) for r in rows[split:]])))
    return split, out


def minimum_weeks_study(weeks, key, first_origin=52):
    """Rolling-origin evaluation: train on the most recent k weeks before each origin,
    forecast the next HORIZON weeks, average the absolute error over all origins."""
    y = [float(w[key]) for w in weeks]
    n = len(y)
    results = {}
    origins = list(range(first_origin, n - HORIZON + 1))
    for k in CANDIDATE_WINDOWS:
        errs = []
        for origin in origins:
            xs = list(range(origin - k + 1, origin + 1))
            b0, b1 = fc.fit_ols(xs, y[origin - k:origin])
            preds = [b0 + b1 * x for x in range(origin + 1, origin + HORIZON + 1)]
            errs.append(sum(abs(a - p) for a, p in zip(y[origin:origin + HORIZON], preds)) / HORIZON)
        results[k] = sum(errs) / len(errs)
    best = results[CANDIDATE_WINDOWS[-1]]
    chosen = next(k for k in CANDIDATE_WINDOWS if results[k] <= best * (1 + TOLERANCE))
    return results, chosen, len(origins)


def sklearn_check(weeks):
    try:
        from sklearn.linear_model import LinearRegression
    except ImportError:
        return None
    lines = []
    for key in ("appointments", "no_shows"):
        y = [w[key] for w in weeks]
        xs = [[i] for i in range(1, len(y) + 1)]
        sk = LinearRegression().fit(xs, y)
        b0, b1 = fc.fit_ols([x[0] for x in xs], y)
        lines.append((key, b0, b1, float(sk.intercept_), float(sk.coef_[0]),
                      max(abs(b0 - sk.intercept_), abs(b1 - sk.coef_[0]))))
    return lines


def charts(weeks, result, study, out_dir):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return []
    os.makedirs(os.path.join(out_dir, "img"), exist_ok=True)
    files = []
    dates = [w["week_start"] for w in weeks]
    future = [f["week_start"] for f in result["future"]]
    for key, model_key, title, color, name in (("appointments", "appointment_model", "Weekly appointments", "#2676E8", "forecast_appointments.png"),
                                               ("no_shows", "no_show_model", "Weekly did-not-attend (no-show) count", "#C0287A", "forecast_no_shows.png")):
        m = result[model_key]
        fig, ax = plt.subplots(figsize=(10, 4.2), dpi=130)
        split_date = dates[m["train_weeks"]]
        ax.axvspan(split_date - timedelta(days=3), dates[-1] + timedelta(days=3), color="#20D3C2", alpha=.08, label="Test weeks (last 20%)")
        ax.plot(dates, [w[key] for w in weeks], color=color, lw=1.4, label="Actual")
        ax.plot(dates, m["fitted"], color="#8FA9D6", lw=1.6, label=f"Fitted line  Y = {m['intercept']:.2f} + {m['slope']:.3f}·X")
        ax.plot([dates[-1]] + future, [weeks[-1][key]] + [f[key] for f in result["future"]], color="#0B7A70", ls="--", marker="o", ms=3,
                label=f"Forecast (next {len(future)} weeks)")
        ax.set_title(title)
        ax.set_ylabel("count per week")
        ax.grid(alpha=.25)
        low, high = ax.get_ylim()
        ax.set_ylim(low, high + (high - low) * 0.22)       # head-room so the legend never covers data
        ax.legend(loc="upper left", fontsize=8, frameon=True, framealpha=.85, ncol=2)
        fig.tight_layout()
        fig.savefig(os.path.join(out_dir, "img", name))
        plt.close(fig)
        files.append(name)
    fig, ax = plt.subplots(figsize=(7.5, 3.6), dpi=130)
    for key, color, label in (("appointments", "#2676E8", "Appointments"), ("no_shows", "#C0287A", "Did not attend")):
        res, chosen, _ = study[key]
        best = res[CANDIDATE_WINDOWS[-1]]
        ax.plot(CANDIDATE_WINDOWS, [res[k] / best for k in CANDIDATE_WINDOWS], marker="o", color=color, label=label)
    ax.axhline(1 + TOLERANCE, color="#999", ls=":", lw=1)
    ax.axvline(max(study[k][1] for k in study), color="#0B7A70", ls="--", lw=1)
    ax.set_xlabel("weeks of history used to train")
    ax.set_ylabel("4-week MAE ÷ MAE with 52 weeks")
    ax.set_title("Minimum-weeks experiment (rolling origin)")
    ax.grid(alpha=.25)
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "img", "minimum_weeks.png"))
    plt.close(fig)
    files.append("minimum_weeks.png")
    return files


# ---------------------------------------------------------------- main
def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print(__doc__)
        sys.exit(1)
    path = args[0]
    out_dir = sys.argv[sys.argv.index("--out") + 1] if "--out" in sys.argv else os.path.join(ROOT, "docs")
    os.makedirs(out_dir, exist_ok=True)

    # ---- 2. Data understanding
    raw = []
    with open(path, newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        columns = reader.fieldnames
        for record in reader:
            raw.append(record)
    ids = Counter(r.get("appointment_id") for r in raw)
    duplicates = sum(c - 1 for c in ids.values() if c > 1)
    missing_date = sum(1 for r in raw if not r.get("appointment_date"))
    statuses = Counter((r.get("appointment_status") or "").strip().lower() for r in raw)
    rows, skipped = fc.read_history_csv(path)

    # ---- 3. Data preparation (identical to the system: daily -> complete Monday-Sunday weeks)
    daily = defaultdict(lambda: {"total": 0, "no_show": 0, "completed": 0, "cancelled": 0})
    for row in rows:
        day = datetime.strptime(row[1], "%Y-%m-%d").date()
        daily[day]["total"] += 1
        daily[day][row[6]] += 1
    first_day, last_day = min(daily), max(daily)
    result = fc.run_forecast(dict(daily), first_day, last_day, 4, HORIZON, "imported")
    weeks = result["weeks"]
    with open(os.path.join(out_dir, "forecast_dataset_weekly.csv"), "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["week_number", "week_start", "appointment_count", "completed_count", "cancelled_count",
                         "no_show_count", "no_show_rate_pct", "cancellation_rate_pct", "split"])
        split_at = result["appointment_model"]["train_weeks"]
        for i, w in enumerate(weeks):
            attended = w["completed"] + w["no_shows"]
            writer.writerow([i + 1, w["week_start"], w["appointments"], w["completed"], w["cancelled"], w["no_shows"],
                             round(w["no_shows"] / attended * 100, 2) if attended else "",
                             round(w["cancelled"] / w["appointments"] * 100, 2) if w["appointments"] else "",
                             "train" if i < split_at else "test"])

    def describe(key):
        vals = sorted(w[key] for w in weeks)
        n = len(vals)
        mean = sum(vals) / n
        sd = math.sqrt(sum((v - mean) ** 2 for v in vals) / (n - 1))
        return {"mean": mean, "sd": sd, "min": vals[0], "median": (vals[n // 2] + vals[(n - 1) // 2]) / 2, "max": vals[-1]}

    # ---- 4/5. Modeling and evaluation
    xs = list(range(1, len(weeks) + 1))
    inference = {key: slope_inference(xs, [w[key] for w in weeks]) for key in ("appointments", "no_shows")}
    candidates = {key: evaluate_candidates(weeks, key) for key in ("appointments", "no_shows")}
    study = {key: minimum_weeks_study(weeks, key) for key in ("appointments", "no_shows")}
    recommended_min = max(study["appointments"][1], study["no_shows"][1])
    check = sklearn_check(weeks)
    images = charts(weeks, result, study, out_dir)

    # ---- 6. Deployment artefact (same format as the app's "Model file")
    model_file = {
        "system": "AGENDE", "version": "dataset-baseline", "algorithm": fc.ALGORITHM, "feature": fc.FEATURE,
        "week_1_starts": str(result["training_start"]), "training_end": str(result["training_end"]),
        "data_source": "imported", "trigger": "experiment", "training_record_count": result["record_count"],
        "how_to_predict": "X = ((week_start - week_1_starts).days // 7) + 1;  display = max(0, round(b0 + b1 * X))",
        "recommended_min_weeks": recommended_min,
        "models": {key: {"model_type": key, "equation": f"Y = {m['intercept']:.6f} + {m['slope']:.6f} * X",
                         "intercept_b0": m["intercept"], "slope_b1": m["slope"], "test_mae": m["mae"], "test_rmse": m["rmse"],
                         "test_r2": m["r2"], "baseline_mae": m["baseline_mae"], "training_weeks": m["train_weeks"],
                         "test_weeks": m["test_weeks"]}
                   for key, m in (("appointments", result["appointment_model"]), ("no_shows", result["no_show_model"]))},
    }
    with open(os.path.join(out_dir, "forecast_model.json"), "w", encoding="utf-8") as handle:
        json.dump(model_file, handle, indent=2, default=str)

    # ---------------------------------------------------------------- report
    am, nm = result["appointment_model"], result["no_show_model"]
    L = []
    w = L.append
    w("# AGENDE Forecast Model: CRISP-DM Modeling Report")
    w("")
    w(f"_Generated {date.today().strftime('%B %d, %Y')} by `research/forecast_experiment.py` from `{os.path.basename(path)}`. "
      "Every number below is reproduced by running the tool again on the same file._")
    w("")
    w("The forecasting component follows blueprint sections 15 (linear regression forecasting) and 16 (CRISP-DM). "
      "It estimates **aggregate weekly totals**: the number of appointments and the number of did-not-attend (no-show) cases per week. "
      "It does not predict whether any individual client will attend (assumptions A-011 and A-012).")
    w("")
    w("## 1. Business understanding")
    w("")
    w("Administrators need a planning estimate of next weeks' demand (staffing, opening hours) and of expected missed appointments "
      "(reminder effort, overbooking policy). Success criterion for deployment: a model that is trained only on enough history, "
      "evaluated on unseen later weeks, reports its error honestly, and never shows impossible (negative) counts.")
    w("")
    w("## 2. Data understanding")
    w("")
    w("| Item | Value |")
    w("|---|---|")
    w(f"| Records | {len(raw):,} |")
    w(f"| Columns | {len(columns)} ({', '.join(columns[:6])}, ...) |")
    w(f"| Appointment dates | {first_day:%m/%d/%Y} to {last_day:%m/%d/%Y} |")
    w(f"| Duplicate appointment IDs | {duplicates} |")
    w(f"| Missing appointment dates | {missing_date} |")
    w(f"| Rows not usable (unknown status / no date) | {skipped} |")
    for status, count in statuses.most_common():
        w(f"| Status `{status}` | {count:,} ({count / len(raw) * 100:.1f}%) |")
    w("")
    w("Patient details (sex, age, patient ID) are not needed for aggregate forecasting and are not imported into AGENDE "
      "(blueprint section 40, separation of data layers).")
    w("")
    w("## 3. Data preparation")
    w("")
    w("1. Each record is counted on its appointment date by status (completed, cancelled, no_show).")
    w("2. Days are grouped into Monday-Sunday weeks. Only **complete weeks** inside the data coverage are kept "
      "(a partial first or last week would look like a sudden drop). Weeks inside the coverage with no records count as 0.")
    w("3. Each week gets a sequential number X = 1, 2, 3 ... (the model's only feature).")
    w("")
    w(f"Result: **{len(weeks)} complete weeks** ({weeks[0]['week_start']:%m/%d/%Y} to {weeks[-1]['week_start'] + timedelta(days=6):%m/%d/%Y}), "
      f"saved as `forecast_dataset_weekly.csv` (the blueprint's forecasting dataset).")
    w("")
    w("| Weekly count | Mean | SD | Min | Median | Max |")
    w("|---|---:|---:|---:|---:|---:|")
    for key, label in (("appointments", "Appointments"), ("no_shows", "Did not attend"), ("completed", "Completed"), ("cancelled", "Cancelled")):
        d = describe(key)
        w(f"| {label} | {d['mean']:.1f} | {d['sd']:.1f} | {d['min']} | {d['median']:.1f} | {d['max']} |")
    w("")
    w("## 4. Modeling")
    w("")
    w("Two separate simple linear regressions (blueprint 15.2, BR-033), fitted by ordinary least squares:")
    w("")
    w("```text")
    w("Model 1:  appointments per week   Y = b0 + b1 * X")
    w("Model 2:  did-not-attend per week Y = b0 + b1 * X        X = week number")
    w("b1 = sum((x - mean_x)(y - mean_y)) / sum((x - mean_x)^2),   b0 = mean_y - b1 * mean_x")
    w("```")
    w("")
    w("Final models (refit on all weeks, the version that is deployed):")
    w("")
    w("| Model | Equation | Slope per week | Std. error | t | p (two-sided) | Trend |")
    w("|---|---|---:|---:|---:|---:|---|")
    for key, label in (("appointments", "1 Appointments"), ("no_shows", "2 Did not attend")):
        b0, b1, se, t, p = inference[key]
        trend = "significant rising" if p < .05 and b1 > 0 else ("significant falling" if p < .05 else "no significant trend (flat)")
        w(f"| {label} | Y = {b0:.3f} + {b1:.4f}·X | {b1:+.4f} | {se:.4f} | {t:.2f} | {'<0.0001' if p < 1e-4 else f'{p:.4f}'} | {trend} |")
    w("")
    w("_p-values use the normal approximation to the t distribution (n > 100 weeks, so the difference is negligible)._")
    w("")
    if check:
        w("**Cross-check:** the same coefficients were computed with scikit-learn `LinearRegression`; "
          f"the largest difference was {max(c[5] for c in check):.2e}, so AGENDE's built-in OLS (no external library) is numerically identical.")
        w("")
    w("## 5. Evaluation")
    w("")
    w("### 5.1 Chronological train/test split (blueprint 15.8)")
    w("")
    w(f"First {am['train_weeks']} weeks train, last {am['test_weeks']} weeks test (from {result['test_start']:%m/%d/%Y}). "
      "Never shuffled, so no future week is used for training (TC040). Metrics use the raw, unclamped predictions.")
    w("")
    for key, label, unit in (("appointments", "Model 1: appointments", "appointments"), ("no_shows", "Model 2: did not attend", "cases")):
        split, cands = candidates[key]
        w(f"**{label}** (test-week mean: {(am if key == 'appointments' else nm)['test_mean']:.1f} {unit}/week)")
        w("")
        w("| Candidate | MAE | RMSE | R² |")
        w("|---|---:|---:|---:|")
        for name, (mae, rmse, r2) in cands:
            mark = "**" if name.startswith("Trend  Y") else ""
            w(f"| {mark}{name}{mark} | {fmt(mae, 2)} | {fmt(rmse, 2)} | {fmt(r2)} |")
        w("")
    a_skill, n_skill = am["skill_pct"], nm["skill_pct"]
    w("### 5.2 Interpretation")
    w("")
    w(f"* **Appointments.** The test MAE is {am['mae']:.1f} appointments per week, about {am['relative_error_pct']:.1f}% of a typical week. "
      f"Weekly volume has no significant linear trend (p = {inference['appointments'][4]:.2f}), so the line is almost flat and performs "
      f"about the same as always predicting the average week ({a_skill:.1f}% lower error than that baseline; a moving average of the last 8 "
      f"weeks reaches MAE {candidates['appointments'][1][2][1][0]:.1f} but a higher RMSE, a difference well inside week-to-week noise). "
      "R² on the test weeks is close to 0 because "
      "there is little variation for any model to explain, not because the forecasts are far off. In practice the model says: "
      f"plan for about {round(result['future'][0]['appointments'])} appointments a week, give or take {am['mae']:.0f}.")
    w(f"* **Did not attend.** Missed appointments rise by about {inference['no_shows'][1]:.2f} cases per week (p < 0.0001). "
      f"The trend model's test MAE is {nm['mae']:.1f} cases ({nm['relative_error_pct']:.1f}% of a typical week), "
      f"{n_skill:.1f}% lower than the average-week baseline, so the regression adds real planning information here.")
    w("* **Extra features (blueprint 15.6).** Adding the previous week's count or the month of year did not lower the test error for either "
      "target, so the MVP keeps the single-feature model Y = b0 + b1·X, as the blueprint recommends.")
    w("* MAE is the headline metric (easy to explain: \"on average, how many appointments away is the forecast\"); RMSE and R² are supporting metrics (blueprint 15.9).")
    w("")
    w("### 5.3 Minimum history experiment (blueprint A-010 and 15.11)")
    w("")
    origins = study["appointments"][2]
    w(f"Question: how many weeks of history must exist before a model is trained? Method: rolling-origin evaluation over {origins} forecast "
      f"origins (weeks 53 to {len(weeks) - HORIZON}). At each origin the model is trained on only the most recent k weeks and forecasts the "
      f"next {HORIZON} weeks; the absolute errors are averaged. Rule: the smallest k whose error is within {int(TOLERANCE * 100)}% of the error "
      f"with {CANDIDATE_WINDOWS[-1]} weeks.")
    w("")
    w("| Weeks of history (k) | " + " | ".join(str(k) for k in CANDIDATE_WINDOWS) + " |")
    w("|---|" + "---:|" * len(CANDIDATE_WINDOWS))
    for key, label in (("appointments", "Appointments MAE"), ("no_shows", "Did-not-attend MAE")):
        res, chosen, _ = study[key]
        w(f"| {label} | " + " | ".join(f"**{res[k]:.2f}**" if k == chosen else f"{res[k]:.2f}" for k in CANDIDATE_WINDOWS) + " |")
    w("")
    w(f"Result: appointments stabilise at **{study['appointments'][1]} weeks**, did-not-attend at **{study['no_shows'][1]} weeks**. "
      f"With 8 weeks (the earlier default) errors were {study['appointments'][0][8] / study['appointments'][0][52] * 100 - 100:.0f}% and "
      f"{study['no_shows'][0][8] / study['no_shows'][0][52] * 100 - 100:.0f}% higher. AGENDE therefore uses **{recommended_min} complete weeks** "
      "as the default minimum (`forecast_min_weeks`, adjustable in Settings). Below it the Forecast page shows "
      "\"Insufficient historical data\" and no model is trained (BR-031, TC043).")
    w("")
    for img in images:
        w(f"![{img}](img/{img})")
        w("")
    w("## 6. Deployment")
    w("")
    w("| Item | Implementation in AGENDE 3.1 |")
    w("|---|---|")
    w("| Model store | `forecast_models` (one row per model; the pair shares a version label such as FM-0007) and `forecast_results` (predictions, raw and displayed). |")
    w("| Deploy | Forecast page, **Train & deploy**, or `flask --app app train-forecast`. The new pair becomes the single active model; older versions can be re-activated. |")
    w("| Use | Dashboard and Forecast page read the active model's b0/b1 and compute X for this week from the model's week-1 date, with no retraining on page views. |")
    w("| Negative values | Displayed as max(0, round(prediction)); the raw prediction is stored and exported (BR-035, TC042). |")
    w("| Retraining | Housekeeping retrains and deploys automatically when a new complete week of live records exists and at least the minimum number of weeks is available (`forecast_auto_retrain`). Admins are notified. |")
    w(f"| Out-of-date guard | A model is not used for forecasts more than {fc.STALE_AFTER_WEEKS} weeks past its data; the dashboard asks for retraining instead. |")
    w("| Monitoring | After deployment, each new complete week is compared with the model's prediction (live MAE on the Forecast page and in R007). |")
    w("| Model file | `forecast_model.json` (this experiment) and the **Model file** button (active model). |")
    w("")
    w(f"Model trained on this dataset (all {len(weeks)} weeks):")
    w("")
    w("```text")
    w(f"Appointments:    Y = {am['intercept']:.4f} + {am['slope']:.4f} * X     test MAE {am['mae']:.2f}  RMSE {am['rmse']:.2f}  R2 {fmt(am['r2'])}")
    w(f"Did not attend:  Y = {nm['intercept']:.4f} + {nm['slope']:.4f} * X     test MAE {nm['mae']:.2f}  RMSE {nm['rmse']:.2f}  R2 {fmt(nm['r2'])}")
    w(f"Week 1 = {result['training_start']:%m/%d/%Y}")
    w("```")
    w("")
    w("| Forecast week (after the data) | Appointments | Did not attend |")
    w("|---|---:|---:|")
    for f in result["future"]:
        w(f"| {f['week_start']:%m/%d/%Y} | {f['appointments']} ± {am['mae']:.0f} | {f['no_shows']} ± {nm['mae']:.0f} |")
    w("")
    w("The imported dataset comes from a different organization and ends in December 2024, so in production the model is "
      "**retrained on AGENDE's own records** once enough weeks exist. The dataset model demonstrates and validates the method; it is "
      "not meant to forecast the partner organization's current weeks.")
    w("")
    w("## 7. Limitations")
    w("")
    w("* A straight line cannot capture seasonality, holidays, organizational events, service changes or staff availability (blueprint 15.12). "
      "The forecast is a planning aid, not a guaranteed value (BR-034).")
    w("* A rising no-show trend should not be extended far into the future; that is why forecasts stop being shown "
      f"{fc.STALE_AFTER_WEEKS} weeks after the training data and the model is retrained weekly.")
    w("* Results describe the historical dataset. They must be re-checked on the partner organization's data during Phase 6.")
    w("")
    w("## 8. Reproduce")
    w("")
    w("```bash")
    w("python research/forecast_experiment.py AGENDE_appointment_history.csv        # this report")
    w("flask --app app train-forecast --csv AGENDE_appointment_history.csv          # import + train + deploy in AGENDE")
    w("python -m unittest discover -s tests -v                                      # includes the forecast tests")
    w("```")
    report_path = os.path.join(out_dir, "FORECAST_MODEL_REPORT.md")
    with open(report_path, "w", encoding="utf-8") as handle:
        handle.write("\n".join(L) + "\n")
    print(f"Wrote {report_path}")
    print(f"Weeks: {len(weeks)} | appointments MAE {am['mae']:.2f} (baseline {am['baseline_mae']:.2f}) | "
          f"did-not-attend MAE {nm['mae']:.2f} (baseline {nm['baseline_mae']:.2f}) | recommended minimum {recommended_min} weeks")
    if not images:
        print("(matplotlib not installed: charts skipped. pip install matplotlib to add them.)")


if __name__ == "__main__":
    main()
