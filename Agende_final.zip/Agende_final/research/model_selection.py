"""
Baseline models, hyper-parameter tuning and model selection for AGENDE:
  1. NO-SHOW PREDICTION  (will this appointment be missed?)        -> ml/noshow.py
  2. TIME FORECASTING    (appointments / no-shows per week ahead)  -> ml/timeseries.py

    python research/model_selection.py data/AGENDE_dataset_package.zip
    python research/model_selection.py data/AGENDE_dataset_package.zip --out docs --models research/ml/models

Needs: pandas, numpy, scikit-learn (matplotlib optional, for charts).
Writes:
    docs/MODEL_SELECTION_REPORT.md          full write-up (baselines, tuning, leaderboards, choice)
    docs/img/ms_*.png                       charts
    research/ml/models/noshow_full.json|.joblib      chosen no-show model, all dataset features
    research/ml/models/noshow_agende.json|.joblib    chosen no-show model, features AGENDE records
                                            (the JSON is also copied to agende/models/, which the web app uses;
                                             add --no-deploy to skip that)
    research/ml/models/timeseries_model.json         chosen forecasting model + parameters per target
Every number in the report is reproduced by running the script again (fixed random seed).
"""
import json
import os
import sys
import tempfile
import time
import warnings
import zipfile
from datetime import date, datetime, timedelta

import numpy as np
import pandas as pd
import sklearn
from sklearn.inspection import permutation_importance
from sklearn.metrics import confusion_matrix, precision_recall_curve

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "research"))

from agende import forecasting  # noqa: E402
from ml import noshow, timeseries as ts  # noqa: E402
from agende.noshow_scorer import probability  # noqa: E402

warnings.filterwarnings("ignore")


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def f(v, d=3):
    return "N/A" if v is None else f"{v:.{d}f}"


def pct(v, d=1):
    return f"{v * 100:.{d}f}%"


# ------------------------------------------------------------------ inputs
def locate(paths):
    """Accept the package zip or the two CSV files; return (no_show_csv, history_csv, tmpdir)."""
    tmp = None
    noshow_csv = history_csv = None
    for p in paths:
        if p.lower().endswith(".zip"):
            tmp = tempfile.mkdtemp(prefix="agende_ds_")
            with zipfile.ZipFile(p) as z:
                for name in z.namelist():
                    if name.endswith("AGENDE_no_show_model_dataset.csv") or name.endswith("AGENDE_appointment_history.csv"):
                        z.extract(name, tmp)
                        full = os.path.join(tmp, name)
                        if "no_show" in name:
                            noshow_csv = full
                        else:
                            history_csv = full
        elif "no_show" in os.path.basename(p):
            noshow_csv = p
        elif "history" in os.path.basename(p):
            history_csv = p
    if not noshow_csv or not history_csv:
        print(__doc__)
        sys.exit("Could not find AGENDE_no_show_model_dataset.csv and AGENDE_appointment_history.csv.")
    return noshow_csv, history_csv, tmp


# ------------------------------------------------------------------ exports
def export_logistic(pipeline, num, cat, meta, train=None):
    """Fitted Pipeline(prep, LogisticRegression) -> plain JSON (no scikit-learn needed to score).
    With the training frame, each number also gets its 0.5-99.5 percentile range (lo/hi), and the
    scorer clips inputs to it so unusual clients cannot push the linear score to extremes."""
    prep, model = pipeline.named_steps["prep"], pipeline.named_steps["model"]
    coef = model.coef_[0]
    scaler = prep.named_transformers_["num"]
    enc = prep.named_transformers_["cat"]
    n_num = len(num)
    numeric = [{"name": c, "mean": float(scaler.mean_[i]), "scale": float(scaler.scale_[i]), "coef": float(coef[i])}
               for i, c in enumerate(num)]
    if train is not None:
        for f_ in numeric:
            f_["lo"], f_["hi"] = (float(v) for v in train[f_["name"]].quantile([0.005, 0.995]))
    cat_coef = coef[n_num:]
    names = list(enc.get_feature_names_out(cat))
    categorical = []
    for j, col in enumerate(cat):
        values = {}
        base = {c: enc.categories_[k][0] for k, c in enumerate(cat)}
        frame = pd.DataFrame([{**base, col: v} for v in enc.categories_[j]])
        onehot = enc.transform(frame)
        onehot = onehot.toarray() if hasattr(onehot, "toarray") else np.asarray(onehot)
        cols = [i for i, n in enumerate(names) if n.startswith(col + "_")]
        for r, v in enumerate(enc.categories_[j]):
            values[str(v)] = float(onehot[r, cols] @ cat_coef[cols])
        categorical.append({"name": col, "values": values, "unknown": 0.0})
    return {**meta, "algorithm": "logistic_regression", "intercept": float(model.intercept_[0]),
            "numeric": numeric, "categorical": categorical}


def verify_scorer(model_json, pipeline, frame, num, cat):
    """Largest difference between scikit-learn and the pure-Python scorer (inputs clipped the same way)."""
    frame = frame.copy()
    for f_ in model_json["numeric"]:
        if "lo" in f_:
            frame[f_["name"]] = frame[f_["name"]].clip(f_["lo"], f_["hi"])
    sk = pipeline.predict_proba(frame[num + cat])[:, 1]
    rows = frame[num + cat].to_dict("records")
    py = np.array([probability(model_json, r) for r in rows])
    return float(np.max(np.abs(sk - py)))


# ------------------------------------------------------------------ charts
def make_charts(ns, ts_res, ts_sel, series, weeks, out_dir):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return []
    img = os.path.join(out_dir, "img")
    os.makedirs(img, exist_ok=True)
    made = []
    tr, va, te, _ = ns["frames"]
    colors = {"logistic": "#2676E8", "logistic_binned": "#7A5AF8", "tree": "#E0A800", "forest": "#22A06B", "hgb": "#C0287A"}

    # 1. PR curves (test) for tuned models, both feature sets
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), dpi=130, sharey=True)
    for ax, fs, title in ((axes[0], "full", "All dataset features"), (axes[1], "agende", "Features AGENDE records")):
        for name in noshow.SPACES:
            r = ns["candidates"][(fs, name)]
            prec, rec, _ = precision_recall_curve(te["did_not_attend"], r["p_test"])
            chosen = ns[f"best_{fs}"][1] == name
            ax.plot(rec, prec, color=colors[name], lw=2.4 if chosen else 1.1, alpha=1 if chosen else .75,
                    label=f"{noshow.LABELS[name].split(' (')[0]}  AP {r['test']['pr_auc']:.3f}" + ("  ← chosen" if chosen else ""))
        rule = ns["baselines"]["rule"]["test"]
        ax.scatter([rule["recall"]], [rule["precision"]], color="#333", zorder=5, s=25, label="Rule baseline")
        ax.axhline(te["did_not_attend"].mean(), color="#999", ls=":", lw=1, label="No-skill (base rate)")
        ax.set_title(f"{title} (test set)")
        ax.set_xlabel("recall (share of no-shows caught)")
        ax.grid(alpha=.25)
        ax.legend(fontsize=7, frameon=False, loc="upper right")
    axes[0].set_ylabel("precision (share of flags that were no-shows)")
    fig.tight_layout()
    fig.savefig(os.path.join(img, "ms_noshow_pr_curves.png"))
    plt.close(fig)
    made.append("ms_noshow_pr_curves.png")

    # 2. Calibration of the chosen models (test)
    fig, ax = plt.subplots(figsize=(5.2, 4.2), dpi=130)
    for fs, color in (("full", "#2676E8"), ("agende", "#22A06B")):
        r = ns["candidates"][ns[f"best_{fs}"]]
        df = pd.DataFrame({"p": r["p_test"], "y": te["did_not_attend"].values})
        df["bin"] = pd.qcut(df["p"], 10, duplicates="drop")
        g = df.groupby("bin", observed=True).agg(p=("p", "mean"), y=("y", "mean"))
        ax.plot(g["p"], g["y"], marker="o", color=color, label=f"{fs}: {noshow.LABELS[ns[f'best_{fs}'][1]].split(' (')[0]}")
    lim = max(0.45, ax.get_xlim()[1])
    ax.plot([0, lim], [0, lim], color="#999", ls=":", lw=1, label="perfect calibration")
    ax.set_xlabel("predicted probability (decile mean)")
    ax.set_ylabel("observed no-show rate")
    ax.set_title("Calibration (test set)")
    ax.grid(alpha=.25)
    ax.legend(fontsize=7, frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(img, "ms_noshow_calibration.png"))
    plt.close(fig)
    made.append("ms_noshow_calibration.png")

    # 3. Permutation importance (chosen full model, test)
    imp = ns["importance"]
    fig, ax = plt.subplots(figsize=(7, 4.4), dpi=130)
    top = imp[:12][::-1]
    ax.barh([t[0] for t in top], [t[1] for t in top], xerr=[t[2] for t in top], color="#2676E8", alpha=.85)
    ax.set_xlabel("drop in test PR-AUC when the feature is shuffled")
    ax.set_title("What drives the no-show prediction")
    ax.grid(alpha=.25, axis="x")
    fig.tight_layout()
    fig.savefig(os.path.join(img, "ms_noshow_importance.png"))
    plt.close(fig)
    made.append("ms_noshow_importance.png")

    # 4. Forecast leaderboard (relative MAE, validation vs test)
    names = sorted(ts.MODELS, key=lambda n: ts_sel["tests"][n]["score"])
    fig, ax = plt.subplots(figsize=(9, 4.4), dpi=130)
    y_pos = np.arange(len(names))
    val = [np.mean([ts_res[t][n]["val"]["mae"] / ts_res[t]["naive"]["val"]["mae"] for t in series]) for n in names]
    tst = [np.mean([ts_res[t][n]["test"]["mae"] / ts_res[t]["naive"]["test"]["mae"] for t in series]) for n in names]
    ax.barh(y_pos - .2, val, height=.38, color="#2676E8", label="validation (used to choose)")
    ax.barh(y_pos + .2, tst, height=.38, color="#20D3C2", label="test (final check)")
    ax.set_yticks(y_pos, [ts.MODELS[n][0].replace("Baseline: ", "") + ("  ← chosen" if n == ts_sel["chosen"] else "") for n in names],
                  fontsize=7)
    ax.invert_yaxis()
    ax.axvline(1, color="#999", ls=":", lw=1)
    ax.set_xlabel("MAE relative to the naive baseline (lower is better; average of both targets)")
    ax.set_title("Weekly forecasting models, walk-forward 1-4 weeks ahead")
    ax.grid(alpha=.25, axis="x")
    ax.legend(fontsize=8, frameon=False, loc="lower right")
    fig.tight_layout()
    fig.savefig(os.path.join(img, "ms_forecast_leaderboard.png"))
    plt.close(fig)
    made.append("ms_forecast_leaderboard.png")

    # 5. Test weeks: actual vs one-week-ahead forecasts
    fig, axes = plt.subplots(2, 1, figsize=(10, 6.4), dpi=130, sharex=True)
    dates = [w["week_start"] for w in weeks]
    for ax, t, title in ((axes[0], "appointments", "Appointments per week"), (axes[1], "no_shows", "Did-not-attend per week")):
        y = series[t]
        ax.plot(dates, y, color="#94A3B8", lw=1, label="actual")
        for name, color, style in ((ts_sel["chosen"], "#0B7A70", "-"), ("linear_all", "#2676E8", "--"), ("naive", "#C0287A", ":")):
            pts = ts_res[t][name]["test"]["one_step"]
            ax.plot([dates[o] for o, _ in pts], [v for _, v in pts], color=color, ls=style, lw=1.6,
                    label=ts.MODELS[name][0].replace("Baseline: ", "") + (" (chosen)" if name == ts_sel["chosen"] else ""))
        ax.axvspan(dates[ts.TEST_START], dates[-1], color="#20D3C2", alpha=.07)
        ax.axvspan(dates[ts.VAL_START], dates[ts.TEST_START], color="#2676E8", alpha=.05)
        ax.set_title(title + " · shaded: validation (blue) and test (teal) weeks; lines: 1-week-ahead forecasts")
        ax.grid(alpha=.25)
        ax.legend(fontsize=7, frameon=False, loc="upper left", ncol=4)
    fig.tight_layout()
    fig.savefig(os.path.join(img, "ms_forecast_test.png"))
    plt.close(fig)
    made.append("ms_forecast_test.png")
    return made


# ------------------------------------------------------------------ main
def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    opts = sys.argv[1:]
    out_dir = opts[opts.index("--out") + 1] if "--out" in opts else os.path.join(ROOT, "docs")
    models_dir = opts[opts.index("--models") + 1] if "--models" in opts else os.path.join(ROOT, "research", "ml", "models")
    if "--out" in opts:
        args = [a for a in args if a != out_dir]
    if "--models" in opts:
        args = [a for a in args if a != models_dir]
    if not args:
        print(__doc__)
        sys.exit(1)
    noshow_csv, history_csv, _tmp = locate(args)
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(models_dir, exist_ok=True)
    t_start = time.time()

    # ================= 1. NO-SHOW PREDICTION =================
    log("No-show prediction: baselines, tuning, selection")
    ns = noshow.run(noshow_csv, log=lambda m: log(m))
    tr, va, te, full_df = ns["frames"]

    fs, name = ns["best_full"]
    num, cat = noshow.FEATURE_SETS[fs]
    chosen_full = ns["candidates"][(fs, name)]
    log("  permutation importance (chosen full model, test set)")
    pi = permutation_importance(chosen_full["model"], te[num + cat], te["did_not_attend"], scoring="average_precision",
                                n_repeats=5, random_state=noshow.SEED, n_jobs=1)
    ns["importance"] = sorted(zip(num + cat, pi.importances_mean, pi.importances_std), key=lambda t: -t[1])

    # Top-k capture and confusion matrix on test for both chosen models
    for key in ("best_full", "best_agende"):
        r = ns["candidates"][ns[key]]
        y = te["did_not_attend"].values
        order = np.argsort(-r["p_test"])
        r["capture"] = {k: float(y[order[:int(len(y) * k / 100)]].sum() / y.sum()) for k in (5, 10, 20, 30)}
        pred = (r["p_test"] >= r["val"]["threshold"]).astype(int)
        r["confusion"] = confusion_matrix(y, pred).tolist()

    # Final models: refit on ALL active rows with the chosen settings, then export
    log("  refitting chosen no-show models on all data and exporting")
    active = full_df[full_df["historical_outcome"] != "cancelled"]
    exports = {}
    for key, tag in (("best_full", "full"), ("best_agende", "agende")):
        fs_k, name_k = ns[key]
        num_k, cat_k = noshow.FEATURE_SETS[fs_k]
        r = ns["candidates"][(fs_k, name_k)]
        final = noshow.build(name_k, r["params"], num_k, cat_k).fit(active[num_k + cat_k], active["did_not_attend"])
        shift = 0.0
        if r.get("intercept_shift"):
            n1 = int(active["did_not_attend"].sum())
            shift = float(np.log((len(active) - n1) / n1))
            final.named_steps["model"].intercept_ = final.named_steps["model"].intercept_ - shift   # prior correction
        meta = {"system": "AGENDE", "model": f"noshow_{tag}", "label": noshow.LABELS[name_k], "feature_set": fs_k,
                "trained_on": f"{len(active)} non-cancelled appointments, {active['appointment_date'].min().date()} to "
                              f"{active['appointment_date'].max().date()}",
                "target": "did_not_attend (1 = missed)", "hyperparameters": {k: (v if not isinstance(v, np.generic) else v.item())
                                                                          for k, v in r["params"].items()},
                "test_metrics": {k: float(v) for k, v in r["test"].items()},
                "validation_metrics": {k: float(v) for k, v in r["val"].items()},
                "tiers": {"high": float(r["val"]["threshold"]), "medium": float(tr["did_not_attend"].mean())},
                "scikit_learn_version": sklearn.__version__,
                "prior_correction": (f"class_weight=balanced: intercept lowered by log(n0/n1) = {shift:.4f} so outputs are real probabilities"
                                     if shift else "not needed"),
                "use": "Advisory only: supports staff decisions (extra reminder, confirmation call). Never cancels or rejects a booking."}
        import joblib
        joblib.dump(final, os.path.join(models_dir, f"noshow_{tag}.joblib"))
        exports[tag] = {"name": name_k, "json": None, "max_diff": None}
        if name_k == "logistic":
            mj = export_logistic(final, num_k, cat_k, meta, train=active)
            exports[tag]["max_diff"] = verify_scorer(mj, final, te.head(2000), num_k, cat_k)
            with open(os.path.join(models_dir, f"noshow_{tag}.json"), "w", encoding="utf-8") as handle:
                json.dump(mj, handle, indent=2)
            exports[tag]["json"] = mj
        else:
            with open(os.path.join(models_dir, f"noshow_{tag}.meta.json"), "w", encoding="utf-8") as handle:
                json.dump(meta, handle, indent=2)

    # ================= 2. TIME FORECASTING =================
    log("Time forecasting: baselines, tuning, walk-forward evaluation")
    rows, _ = forecasting.read_history_csv(history_csv)
    daily = {}
    for row in rows:
        day = datetime.strptime(row[1], "%Y-%m-%d").date()
        b = daily.setdefault(day, {"total": 0, "no_show": 0, "completed": 0, "cancelled": 0})
        b["total"] += 1
        b[row[6]] += 1
    weeks = forecasting.weekly_series(daily, min(daily), max(daily))
    series = {"appointments": np.array([w["appointments"] for w in weeks], float),
              "no_shows": np.array([w["no_shows"] for w in weeks], float)}
    ts_res = {}
    for t in series:
        ts_res[t] = ts.evaluate_target(series[t])
        log(f"  {t}: {len(ts.MODELS)} models tuned")
    ts_sel = ts.select(series, ts_res)
    chosen_ts = ts_sel["chosen"]
    log(f"  selected: {chosen_ts} (top score: {ts_sel['best_score']})")
    next_monday = weeks[-1]["week_start"] + timedelta(days=7)
    ts_export = {"system": "AGENDE", "model": "timeseries", "chosen_family": chosen_ts, "label": ts.MODELS[chosen_ts][0],
                 "horizon_weeks": ts.H, "trained_on": f"{len(weeks)} complete weeks, {weeks[0]['week_start']} to "
                                                     f"{weeks[-1]['week_start'] + timedelta(days=6)}",
                 "targets": {}}
    for t in series:
        r = ts_res[t][chosen_ts]
        fc = ts.fit_final(series[t], chosen_ts, r["params"])
        ts_export["targets"][t] = {"parameters": r["params"], "validation_mae": r["val"]["mae"], "test_mae": r["test"]["mae"],
                                   "test_rmse": r["test"]["rmse"], "naive_test_mae": ts_res[t]["naive"]["test"]["mae"],
                                   "next_weeks": [{"week_start": str(next_monday + timedelta(days=7 * i)), "raw": float(v),
                                                   "display": max(0, round(float(v)))} for i, v in enumerate(fc)]}
    with open(os.path.join(models_dir, "timeseries_model.json"), "w", encoding="utf-8") as handle:
        json.dump(ts_export, handle, indent=2, default=str)
    # Deploy: the web app reads agende/models/noshow_agende.json
    if exports["agende"]["json"] and "--no-deploy" not in sys.argv:
        deployed = os.path.join(ROOT, "agende", "models", "noshow_agende.json")
        os.makedirs(os.path.dirname(deployed), exist_ok=True)
        with open(deployed, "w", encoding="utf-8") as handle:
            json.dump(exports["agende"]["json"], handle, indent=2)
        log(f"  deployed the AGENDE no-show model to {deployed}")

    # ================= charts + report =================
    log("Charts and report")
    images = make_charts(ns, ts_res, ts_sel, series, weeks, out_dir)
    write_report(out_dir, ns, exports, ts_res, ts_sel, ts_export, series, weeks, images, time.time() - t_start)
    log(f"Done in {time.time() - t_start:.0f}s -> {os.path.join(out_dir, 'MODEL_SELECTION_REPORT.md')}")


# ------------------------------------------------------------------ report
def write_report(out_dir, ns, exports, ts_res, ts_sel, ts_export, series, weeks, images, seconds):
    a = ns["audit"]
    tr, va, te, _ = ns["frames"]
    L = []
    w = L.append
    bf, ba = ns["best_full"], ns["best_agende"]
    rf, ra = ns["candidates"][bf], ns["candidates"][ba]
    chosen_ts = ts_sel["chosen"]

    w("# AGENDE: Baseline, Tuning and Model Selection Report")
    w("")
    w(f"_Generated {date.today():%B %d, %Y} by `research/model_selection.py` from `AGENDE_dataset_package.zip` "
      f"(scikit-learn {sklearn.__version__}, fixed seed {noshow.SEED}, {seconds / 60:.0f} min). Re-running the script reproduces every number._")
    w("")
    w("## Summary: the two selected models")
    w("")
    w("| Task | Selected model | Key test result | Beats baseline by |")
    w("|---|---|---|---|")
    maj, rule = ns["baselines"]["majority"]["test"], ns["baselines"]["rule"]["test"]
    w(f"| **No-show prediction** (per appointment) | **{noshow.LABELS[bf[1]]}**, all dataset features "
      f"({', '.join(f'{k}={v}' for k, v in rf['params'].items())}) | PR-AUC {rf['test']['pr_auc']:.3f}, ROC-AUC {rf['test']['roc_auc']:.3f}; "
      f"at the chosen threshold catches {pct(rf['test']['recall'], 0)} of no-shows with {pct(rf['test']['precision'], 0)} precision | "
      f"PR-AUC {rf['test']['pr_auc'] / rule['pr_auc']:.1f}× the history rule, {rf['test']['pr_auc'] / maj['pr_auc']:.1f}× chance |")
    tt = ts_export["targets"]
    w(f"| **Time forecasting** (weekly totals, 1–4 weeks ahead) | **{ts.MODELS[chosen_ts][0]}** "
      f"(appointments: {tt['appointments']['parameters']}, no-shows: {tt['no_shows']['parameters']}) | test MAE "
      f"{tt['appointments']['test_mae']:.1f} appointments/week ({tt['appointments']['test_mae'] / series['appointments'][ts.TEST_START:].mean() * 100:.1f}% of a week), "
      f"{tt['no_shows']['test_mae']:.1f} no-shows/week | "
      f"{(1 - tt['appointments']['test_mae'] / tt['appointments']['naive_test_mae']) * 100:.0f}% and "
      f"{(1 - tt['no_shows']['test_mae'] / tt['no_shows']['naive_test_mae']) * 100:.0f}% lower MAE than the naive forecast |")
    w("")
    w(f"For use **inside AGENDE**, which does not record age, sex, weather, booking channel, deposits or reminder status, the same "
      f"procedure on AGENDE-available features selects **{noshow.LABELS[ba[1]]}** (test PR-AUC {ra['test']['pr_auc']:.3f}, ROC-AUC "
      f"{ra['test']['roc_auc']:.3f}).")
    w("")
    w("> **Blueprint note.** The blueprint (A-011, A-012, 15.1) limits AGENDE to aggregate forecasting and rules out individual no-show "
      "prediction. Using the no-show model in the system therefore needs a documented scope change: present it as an advisory risk "
      "indicator for staff (who to remind or call), never as automatic cancellation, rejection or overbooking, and say so in the manuscript.")
    w("")

    # ---------------- Part 1
    w("## Part 1: No-show prediction")
    w("")
    w("### 1.1 Data understanding")
    w("")
    w("| Item | Value |")
    w("|---|---|")
    w(f"| Rows · columns | {a['rows']:,} · 23 |")
    w(f"| Appointment dates | {a['start']:%m/%d/%Y} to {a['end']:%m/%d/%Y} |")
    w(f"| Missing values · duplicate IDs | {a['missing']} · {a['duplicate_ids']} |")
    w("| Outcomes | " + ", ".join(f"{k} {v:,}" for k, v in a["outcomes"].items()) + " |")
    w(f"| Booking date before appointment date | {'yes, all rows' if a['booking_before_appointment'] else 'NO'} |")
    w(f"| `scheduling_interval` equals the date difference | {'yes, all rows' if a['interval_matches_dates'] else 'NO'} |")
    w(f"| Rows marked first visit but with earlier appointments | {a['first_visit_with_prior']:,} (inconsistent; kept, but `prior_appointments` carries the history) |")
    w("")
    w("No-show rate by quarter (drift):")
    w("")
    w("| " + " | ".join(str(k) for k in a["rate_by_quarter"]) + " |")
    w("|" + "---:|" * len(a["rate_by_quarter"]))
    w("| " + " | ".join(pct(v) for v in a["rate_by_quarter"].values()) + " |")
    w("")
    w("No-show rate by number of earlier no-shows: " + ", ".join(f"{k}{'+' if k == 4 else ''}: {pct(v)}" for k, v in a["rate_by_prior_no_shows"].items())
      + ". Past behaviour is the strongest single signal.")
    w("")
    w("### 1.2 Preparation and design decisions")
    w("")
    w("* **Target:** `did_not_attend` (1 = missed). **Population:** non-cancelled appointments. A cancelled booking can neither be attended "
      "nor missed, and cancellations are known before the visit, when staff would act on a risk score. "
      "(The README's all-rows definition is reported in 1.6.)")
    w("* **Split by time, never at random** (the rate drifts upward):")
    w("")
    w("| Set | Dates | Rows | No-show rate | Used for |")
    w("|---|---|---:|---:|---|")
    for k, use in (("train", "fitting"), ("validation", "tuning, model choice, threshold"), ("test", "final report only")):
        s = ns["split"][k]
        w(f"| {k.title()} | {s['start']:%m/%d/%Y} – {s['end']:%m/%d/%Y} | {s['rows']:,} | {pct(s['rate'])} | {use} |")
    w("")
    w("* **Derived features:** appointment hour, `has_history`, earlier no-show rate and earlier cancellation rate (from the client's earlier appointments). "
      "History counts enter as log(1 + count): the median client has 3 earlier visits, and a raw count would make a regular client with "
      "hundreds of visits look extreme. This scored better on validation than raw counts (AGENDE set: PR-AUC 0.247 vs 0.242 for raw counts). Deployed models also clip every number "
      "to the 0.5–99.5 percentile range seen in training.")
    w("* **Excluded:** " + "; ".join(f"`{k}` ({v})" for k, v in noshow.EXCLUDED.items()) + ".")
    w(f"* **Feature sets:** *full* = {len(noshow.FULL_NUM) + len(noshow.FULL_CAT)} features from the dataset; *agende* = "
      f"{len(noshow.AGENDE_NUM) + len(noshow.AGENDE_CAT)} features AGENDE records or can compute "
      f"({', '.join(noshow.AGENDE_NUM + noshow.AGENDE_CAT)}).")
    w("* **Metrics:** PR-AUC (average precision) is the primary metric, because only about 9% of appointments are missed and accuracy would "
      "reward predicting \"attends\" for everyone. ROC-AUC, Brier score (probability accuracy), and precision / recall / F1 at a threshold are also reported.")
    w("")
    w("### 1.3 Baselines")
    w("")
    w("| Baseline | Val PR-AUC | Test PR-AUC | Test ROC-AUC | Test precision | Test recall | Test F1 | Test accuracy |")
    w("|---|---:|---:|---:|---:|---:|---:|---:|")
    for k, b in ns["baselines"].items():
        t, v = b["test"], b["val"]
        w(f"| {b['label']} | {v['pr_auc']:.3f} | {t['pr_auc']:.3f} | {t['roc_auc']:.3f} | {t['precision']:.3f} | {t['recall']:.3f} | "
          f"{t['f1']:.3f} | {t['accuracy']:.3f} |")
    w("")
    w("The majority baseline shows why accuracy is misleading: about 90% accuracy while catching no no-shows at all.")
    w("")
    w("### 1.4 Hyper-parameter tuning")
    w("")
    w("Random search: every configuration is trained on the training months and scored on the validation months (PR-AUC). "
      "Class weighting (`balanced`) is part of the search, as a way to handle the class imbalance.")
    w("")
    w("| Model | Search space | Configurations tried |")
    w("|---|---|---:|")
    for n, space in noshow.SPACES.items():
        w(f"| {noshow.LABELS[n]} | " + "; ".join(f"{k} ∈ {v}" for k, v in space.items()) + f" | {noshow.N_ITER[n]} per feature set |")
    w("")
    w("### 1.5 Leaderboard (tuned models)")
    w("")
    for fs, title in (("full", "All dataset features"), ("agende", "Features AGENDE records")):
        sel = ns["selection"][fs]
        w(f"**{title}**")
        w("")
        w("| Model | Best settings | Val PR-AUC | Val ROC-AUC | Test PR-AUC | Test ROC-AUC | Test Brier | Test precision | Test recall | Test F1 |")
        w("|---|---|---:|---:|---:|---:|---:|---:|---:|---:|")
        order = sorted(noshow.SPACES, key=lambda n: -ns["candidates"][(fs, n)]["val"]["pr_auc"])
        for n in order:
            r = ns["candidates"][(fs, n)]
            mark = "**" if n == sel["chosen"] else ""
            params = ", ".join(f"{k}={v}" for k, v in r["params"].items())
            w(f"| {mark}{noshow.LABELS[n]}{mark}{' ← chosen' if n == sel['chosen'] else ''} | {params} | {r['val']['pr_auc']:.3f} | "
              f"{r['val']['roc_auc']:.3f} | {r['test']['pr_auc']:.3f} | {r['test']['roc_auc']:.3f} | {r['test']['brier']:.4f} | "
              f"{r['test']['precision']:.3f} | {r['test']['recall']:.3f} | {r['test']['f1']:.3f} |")
        w("")
        w("Selection test (paired bootstrap, 2,000 resamples of the validation set; difference in PR-AUC vs the top model):")
        w("")
        w("| Model | Δ PR-AUC vs top | 95% interval | Statistically tied with the top model? |")
        w("|---|---:|---|---|")
        for n in order:
            tst = sel["tests"][n]
            w(f"| {noshow.LABELS[n]} | {tst['diff']:+.4f} | ({tst['ci'][0]:+.4f}, {tst['ci'][1]:+.4f}) | {'yes' if tst['tied'] else 'no'} |")
        w("")
    w("**Selection rule:** highest validation PR-AUC. If a simpler model is statistically tied with it, the simpler model wins "
      "(simplicity order: logistic regression < binned logistic < decision tree < random forest < gradient boosting), because it is easier to "
      "explain, to audit and to deploy. The test set was used only after the choice was made.")
    w("")
    w("### 1.6 The chosen models in detail")
    w("")
    for key, title in (("best_full", "All dataset features"), ("best_agende", "AGENDE features")):
        r = ns["candidates"][ns[key]]
        cm = r["confusion"]
        w(f"**{title}: {noshow.LABELS[ns[key][1]]}.** Threshold {r['val']['threshold']:.3f} (maximizes F1 on validation). On the test months it flags "
          f"{r['test']['flagged_pct']:.1f}% of appointments:")
        w("")
        w("| | Predicted attends | Predicted no-show |")
        w("|---|---:|---:|")
        w(f"| **Attended** | {cm[0][0]:,} | {cm[0][1]:,} |")
        w(f"| **Did not attend** | {cm[1][0]:,} | {cm[1][1]:,} |")
        w("")
        w("Ranking value: reminding only the riskiest " + ", ".join(f"{k}% catches {pct(v, 0)}" for k, v in r["capture"].items())
          + " of all no-shows (random selection would catch the same percentage as it contacts).")
        w("")
    s2 = ns["sensitivity_all_rows"]
    w(f"**Sensitivity check:** using the README's definition (all {s2['rows']:,} rows, cancelled = 0), the chosen AGENDE configuration reaches test PR-AUC "
      f"{s2['test']['pr_auc']:.3f} / ROC-AUC {s2['test']['roc_auc']:.3f}. PR-AUC is lower mainly because the base rate is lower; the ranking quality (ROC-AUC) is similar.")
    w("")
    w("**What drives the prediction** (permutation importance on test; drop in PR-AUC when a feature is shuffled):")
    w("")
    w("| Feature | Importance | ± |")
    w("|---|---:|---:|")
    for name, m, sd in ns["importance"][:10]:
        w(f"| `{name}` | {m:.4f} | {sd:.4f} |")
    w("")
    if exports["full"]["json"]:
        mj = exports["full"]["json"]
        w("Largest logistic-regression effects (per one standard deviation for numbers; odds ratio = e^coefficient):")
        w("")
        w("| Feature | Coefficient | Odds ratio |")
        w("|---|---:|---:|")
        for fn in sorted(mj["numeric"], key=lambda q: -abs(q["coef"]))[:8]:
            w(f"| `{fn['name']}` (+1 SD = {fn['scale']:.2f}) | {fn['coef']:+.3f} | {np.exp(fn['coef']):.2f} |")
        w("")
    w("### 1.7 Exported models")
    w("")
    for tag in ("full", "agende"):
        e = exports[tag]
        if e["json"]:
            w(f"* `research/ml/models/noshow_{tag}.json`: coefficients as plain JSON, scored by `agende/noshow_scorer.py` with **no scikit-learn needed**. "
              f"It matches scikit-learn's own probabilities to {e['max_diff']:.1e}. Also `noshow_{tag}.joblib` (needs scikit-learn {sklearn.__version__}).")
        else:
            w(f"* `research/ml/models/noshow_{tag}.joblib` + `.meta.json` (needs scikit-learn {sklearn.__version__} to load).")
    w("* Final models were refit on all non-cancelled appointments with the chosen settings. A model trained with `class_weight=balanced` has its intercept lowered by log(n0/n1) (prior correction, King & Zeng 2001), so its output is a real no-show probability (see the Brier scores and the calibration chart). Risk tiers: **high** ≥ the validation F1 threshold, "
      "**medium** ≥ the training no-show rate, otherwise **low**.")
    w("")

    # ---------------- Part 2
    w("## Part 2: Time forecasting (weekly totals)")
    w("")
    w(f"**Data:** `AGENDE_appointment_history.csv` → {len(weeks)} complete Monday–Sunday weeks ({weeks[0]['week_start']:%m/%d/%Y} – "
      f"{weeks[-1]['week_start'] + timedelta(days=6):%m/%d/%Y}), built with the same code the system uses. Targets: appointments per week "
      f"(mean {series['appointments'].mean():.0f}) and did-not-attend per week (mean {series['no_shows'].mean():.1f}).")
    w("")
    w(f"**Evaluation: walk-forward (rolling origin).** At every origin a model sees only earlier weeks and forecasts the next {ts.H} weeks "
      f"(AGENDE's horizon); errors over all origins and horizons are averaged. Weeks 1–{ts.VAL_START} are history only; origins in weeks "
      f"{ts.VAL_START + 1}–{ts.TEST_START} are the **validation** set (tuning and choice); weeks {ts.TEST_START + 1}–{len(weeks)} are the **test** set.")
    w("")
    w("### 2.1 Baselines and tuned candidates")
    w("")
    w("| Model | Type | Grid size | Appointments: best settings | No-shows: best settings |")
    w("|---|---|---:|---|---|")
    for n, (label, _fn, space, fam) in ts.MODELS.items():
        w(f"| {label} | {fam} | {len(space)} | {ts_res['appointments'][n]['params'] or '-'} | {ts_res['no_shows'][n]['params'] or '-'} |")
    w("")
    w("### 2.2 Leaderboard")
    w("")
    for t, unit in (("appointments", "appointments"), ("no_shows", "no-shows")):
        w(f"**{'Appointments' if t == 'appointments' else 'Did not attend'} per week** (errors in {unit} per week)")
        w("")
        w("| Model | Val MAE | Val RMSE | Test MAE | Test RMSE | Test MAPE | Test MAE 1 week ahead | 4 weeks ahead |")
        w("|---|---:|---:|---:|---:|---:|---:|---:|")
        for n in sorted(ts.MODELS, key=lambda n: ts_res[t][n]["val"]["mae"]):
            r = ts_res[t][n]
            mark = "**" if n == chosen_ts else ""
            w(f"| {mark}{ts.MODELS[n][0]}{mark} | {r['val']['mae']:.2f} | {r['val']['rmse']:.2f} | {r['test']['mae']:.2f} | "
              f"{r['test']['rmse']:.2f} | {r['test']['mape']:.1f}% | {r['test']['mae_h'][1]:.2f} | {r['test']['mae_h'][4]:.2f} |")
        w("")
    w("### 2.3 Selection")
    w("")
    w("One model family is chosen for both targets. Score = average over the two targets of (validation MAE ÷ naive validation MAE). "
      "The best-scoring family is compared with every other one by a block bootstrap over validation origins (4,000 resamples). "
      "Among the families that are not significantly worse, the **simplest** wins.")
    w("")
    w("| Model | Relative score (val) | Δ vs best | 95% interval | Tied with best? |")
    w("|---|---:|---:|---|---|")
    for n in sorted(ts.MODELS, key=lambda n: ts_sel["tests"][n]["score"]):
        tst = ts_sel["tests"][n]
        w(f"| {ts.MODELS[n][0]}{' ← chosen' if n == chosen_ts else ''} | {tst['score']:.3f} | {tst['diff']:+.3f} | "
          f"({tst['ci'][0]:+.3f}, {tst['ci'][1]:+.3f}) | {'yes' if tst['tied'] else 'no'} |")
    w("")
    best = ts_sel["best_score"]
    test_rel = {n: np.mean([ts_res[t][n]["test"]["mae"] / ts_res[t]["naive"]["test"]["mae"] for t in series]) for n in ts.MODELS}
    test_best = min(test_rel, key=test_rel.get)
    w(f"**Result:** {ts.MODELS[best][0]} scored best on validation, but **{ts.MODELS[chosen_ts][0]}** is statistically tied with it and simpler, "
      f"so it is selected. On the test weeks its relative error is {test_rel[chosen_ts]:.3f} versus {test_rel[best]:.3f} for "
      f"{ts.MODELS[best][0]} (the validation winner overfitted). The best test score was {ts.MODELS[test_best][0]} ({test_rel[test_best]:.3f}); "
      "choosing it would mean using the test set to choose, which the protocol does not allow.")
    w("")
    w("**Interpretation:**")
    w("")
    w("* **Appointments per week** are close to random noise around a stable level (no seasonality: the same week last year is the *worst* forecast). "
      "The best forecast is essentially a long-run average, and all sensible methods are within about 1 appointment per week of each other.")
    w("* **No-shows per week** drift upward. A 12-week average follows the level; trend models (Holt, linear) follow it slightly better on the "
      "test weeks, but the difference is not significant on validation.")
    w("* **All selected forecasts beat the naive baselines clearly.** The current system model (blueprint linear trend) is competitive. "
      "Replacing it changes accuracy by well under one appointment per week, so keeping it for blueprint consistency is defensible.")
    w("")
    w(f"**Exported:** `research/ml/models/timeseries_model.json` holds the chosen family, the per-target settings, the metrics and the next {ts.H} weeks after the data:")
    w("")
    w("| Week starting | Appointments | Did not attend |")
    w("|---|---:|---:|")
    for i in range(ts.H):
        ap, nsw = tt["appointments"]["next_weeks"][i], tt["no_shows"]["next_weeks"][i]
        w(f"| {ap['week_start']} | {ap['display']} ± {tt['appointments']['test_mae']:.0f} | {nsw['display']} ± {tt['no_shows']['test_mae']:.0f} |")
    w("")
    for img in images:
        w(f"![{img}](img/{img})")
        w("")
    w("## Limitations and responsible use")
    w("")
    w("* **Moderate predictive power.** A ROC-AUC around 0.75 is useful for ranking (whom to remind first), not for certainty. Most flagged clients will still attend.")
    w("* **Advisory use only.** Never auto-cancel, reject, deprioritize or overbook because of a score. Show it to staff with its meaning.")
    w("* **Fairness.** The full-feature model uses age and sex. The AGENDE feature set excludes both, which is preferable for deployment.")
    w("* **Transfer.** The dataset is synthetic historical data from other organizations. Models must be re-trained and re-validated on the partner "
      "organization's own records before their numbers are cited as AGENDE results.")
    w("* **Drift.** The no-show rate rises over time, so retrain regularly and monitor precision and recall.")
    w("* **Small forecasting test.** 21 test weeks: differences of a few percent between forecasting methods are within noise.")
    w("* LightGBM / XGBoost could not be installed in the build environment; scikit-learn's HistGradientBoosting (the same algorithm family) was used.")
    w("")
    w("## Reproduce")
    w("")
    w("```bash")
    w("pip install -r research/requirements.txt")
    w("python research/model_selection.py data/AGENDE_dataset_package.zip")
    w("```")
    with open(os.path.join(out_dir, "MODEL_SELECTION_REPORT.md"), "w", encoding="utf-8") as handle:
        handle.write("\n".join(L) + "\n")


if __name__ == "__main__":
    main()
