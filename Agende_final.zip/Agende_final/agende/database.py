# =========================================================
# DATABASE.PY
# Opens MySQL connections with PyMySQL.
#
# Two ways to use it:
#
# 1) The 2.1 way (still works):
#       connection = get_connection()
#       cursor = connection.cursor()
#       ...
#       connection.commit(); connection.close()
#
# 2) The 3.0 way (used by app.py) - a "with" block that always
#    closes the connection and rolls back automatically on errors:
#
#       with db_cursor() as cursor:                # read only
#           cursor.execute("SELECT ...", (value,))
#           rows = cursor.fetchall()
#
#       with db_cursor(commit=True) as cursor:     # writes
#           cursor.execute("UPDATE ...", (value,))
#       # <- committed here. If any line inside raised an error,
#       #    NOTHING inside the block was saved (no partial transaction).
# =========================================================

from contextlib import contextmanager

import pymysql
import pymysql.cursors

from agende import config


class DictCursor(pymysql.cursors.DictCursor):
    """Rows come back as dictionaries, e.g. row["name"] instead of row[0].

    PyMySQL's own fetchall() returns a LIST when there are rows but an empty
    TUPLE () when there are none, so `rows_a + rows_b` crashed with
    "can only concatenate tuple (not list) to tuple" on days with no
    appointments. This version always returns a list."""

    def fetchall(self):
        return list(super().fetchall())

    def fetchmany(self, size=None):
        return list(super().fetchmany(size))


def get_connection():
    """Open and return a new MySQL connection (rows as dictionaries)."""
    return pymysql.connect(
        host=config.DB_HOST,
        port=config.DB_PORT,
        user=config.DB_USER,
        password=config.DB_PASSWORD,
        database=config.DB_NAME,
        cursorclass=DictCursor,
        autocommit=False,
        charset="utf8mb4",
    )


@contextmanager
def db_cursor(commit=False):
    """Yield a cursor inside one database transaction.

    commit=False -> read-only use; nothing is committed.
    commit=True  -> commit when the block finishes without an error.
    Any exception rolls the whole transaction back and is re-raised.
    """
    connection = get_connection()
    # Start the transaction explicitly (START TRANSACTION) so a rollback always
    # undoes everything, whatever the server's autocommit default is.
    connection.begin()
    cursor = connection.cursor()
    try:
        yield cursor
        if commit:
            connection.commit()
        else:
            connection.rollback()
    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
        connection.close()
