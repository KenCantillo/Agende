# =========================================================
# NOSHOW_RISK.PY
# Staff-only, ADVISORY no-show risk for upcoming appointments.
#
# Model: logistic regression chosen in docs/MODEL_SELECTION_REPORT.md
# (agende/models/noshow_agende.json, features AGENDE records). Scored in pure
# Python by agende/noshow_scorer.py, so scikit-learn is NOT needed here.
#
# One model serves every service. The service's "no-show category"
# (Services page) is one of its inputs, so a Dental Cleaning and a Legal
# Consultation get different risks for the same client.
#
# Who sees it: staff (their own appointments) and admins. Never clients.
# What it is for: deciding whom to remind or call first. It must never
# cancel, reject, deprioritize or overbook a booking.
# Turn it off in Settings -> "Show no-show risk to staff".
# =========================================================

import os
from datetime import datetime

from agende.noshow_scorer import clipped, derive, load_model, risk
from agende.scheduling import combine, to_date

MODEL_PATH = os.environ.get("AGENDE_NOSHOW_MODEL",
                            os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "noshow_agende.json"))
ACTIVE = ("pending", "confirmed")
_cache = {"mtime": None, "model": None}


def model():
    """The exported model (reloaded when the file changes), or None if it is missing/broken."""
    try:
        mtime = os.path.getmtime(MODEL_PATH)
        if _cache["mtime"] != mtime:
            _cache["model"], _cache["mtime"] = load_model(MODEL_PATH), mtime
        return _cache["model"]
    except (OSError, ValueError):
        return None


def categories():
    """Service categories the model knows (for the Services page)."""
    m = model()
    if not m:
        return []
    for f in m["categorical"]:
        if f["name"] == "appointment_category":
            return sorted(f["values"])
    return []


def eligible(appointment, now):
    """Only upcoming pending/confirmed appointments get a risk."""
    if appointment.get("status") not in ACTIVE:
        return False
    return combine(to_date(appointment["appointment_date"]), appointment["start_time"]) > now


def features(cursor, appointments):
    """Build the model inputs for each appointment from AGENDE's own tables.
    Returns {appointment_id: record}."""
    if not appointments:
        return {}
    clients = sorted({a["user_id"] for a in appointments})
    marks = ",".join(["%s"] * len(clients))
    cursor.execute(f"""SELECT user_id, provider_id, appointment_date, status FROM appointments
                       WHERE user_id IN ({marks}) AND status IN ('completed', 'no_show', 'cancelled')""", clients)
    history = {}
    for row in cursor.fetchall():
        history.setdefault(row["user_id"], []).append(row)
    cursor.execute("SELECT id, risk_category FROM services")
    category = {row["id"]: row["risk_category"] for row in cursor.fetchall()}
    days = sorted({to_date(a["appointment_date"]) for a in appointments})
    marks = ",".join(["%s"] * len(days))
    cursor.execute(f"""SELECT a.appointment_date, s.risk_category, COUNT(*) AS n FROM appointments a
                       JOIN services s ON s.id = a.service_id
                       WHERE a.appointment_date IN ({marks}) AND a.status IN ('pending', 'confirmed', 'completed', 'no_show')
                       GROUP BY a.appointment_date, s.risk_category""", days)
    daily = {(to_date(r["appointment_date"]), r["risk_category"]): int(r["n"]) for r in cursor.fetchall()}

    out = {}
    for a in appointments:
        day = to_date(a["appointment_date"])
        earlier = [h for h in history.get(a["user_id"], []) if to_date(h["appointment_date"]) < day]
        created = a.get("created_at")
        booked = created.date() if isinstance(created, datetime) else day
        cat = category.get(a["service_id"])
        start = a["start_time"]
        hour = combine(day, start)
        out[a["id"]] = {
            "scheduling_interval": max(0, (day - booked).days),
            "prior_appointments": len(earlier),
            "prior_no_shows": sum(1 for h in earlier if h["status"] == "no_show"),
            "prior_cancellations": sum(1 for h in earlier if h["status"] == "cancelled"),
            "is_first_visit": 0 if any(h["provider_id"] == a["provider_id"] for h in earlier) else 1,
            "daily_bookings_in_category": daily.get((day, cat), 0),
            "hour": hour.hour + hour.minute / 60,
            "appointment_category": cat or "",
            "day_of_week": day.strftime("%A"),
        }
    return out


def explain(m, record):
    """Plain-language reasons: what raises and what lowers this appointment's risk."""
    r = derive(record)
    parts = []
    for f in m["numeric"]:
        parts.append((f["name"], f["coef"] * (clipped(f, r) - f["mean"]) / f["scale"]))
    for f in m["categorical"]:
        parts.append((f["name"], f["values"].get(str(r.get(f["name"])), 0.0)))
    effect = dict(parts)
    ns, prior, canc = r["prior_no_shows"], r["prior_appointments"], r["prior_cancellations"]
    # Combine related inputs so each reason is one human statement.
    e = lambda *names: sum(effect.get(n, 0.0) for n in names)  # noqa: E731
    reasons = {
        "history": e("prior_no_shows", "log_prior_no_shows", "prior_no_show_rate", "prior_appointments",
                     "log_prior_appointments", "has_history"),
        "cancellations": e("prior_cancellations", "log_prior_cancellations", "prior_cancel_rate"),
        "lead": e("scheduling_interval"),
        "first": e("is_first_visit"),
        "service": e("appointment_category"),
        "day": e("day_of_week"),
    }
    if ns:
        history_text = f"Missed {ns} of {prior} earlier appointment(s)"
    elif prior:
        history_text = f"Attended all {prior - canc} earlier visit(s)" if prior > canc else f"{prior} earlier booking(s), all cancelled"
    else:
        history_text = "New client: no earlier appointments"
    text = {
        "history": history_text,
        "cancellations": f"Cancelled {canc} earlier appointment(s)" if canc else "No earlier cancellations",
        "lead": f"Booked {r['scheduling_interval']} day(s) ahead",
        "first": "First visit with this staff member" if r["is_first_visit"] else "Has seen this staff member before",
        "service": (f"{r['appointment_category']} services" if r["appointment_category"] else "Service has no category set"),
        "day": f"{r['day_of_week']} appointment",
    }
    ups = [(text[k], v) for k, v in sorted(reasons.items(), key=lambda kv: -kv[1]) if v > 0.05][:3]
    downs = [(text[k], v) for k, v in sorted(reasons.items(), key=lambda kv: kv[1]) if v < -0.05][:2]
    return {"raises": [t for t, _ in ups], "lowers": [t for t, _ in downs]}


def annotate(cursor, appointments, settings, now, with_reasons=False):
    """Add a["risk"] = {"p", "pct", "tier", ...} to eligible appointments (in place).
    Does nothing when the feature is off or the model file is missing."""
    if not appointments or not settings.get("noshow_risk_enabled"):
        return appointments
    m = model()
    if not m:
        return appointments
    targets = [a for a in appointments if eligible(a, now)]
    if not targets:
        return appointments
    inputs = features(cursor, targets)
    for a in targets:
        record = inputs[a["id"]]
        p, tier = risk(m, record)
        a["risk"] = {"p": p, "pct": round(p * 100), "tier": tier, "inputs": record}
        if with_reasons:
            a["risk"].update(explain(m, record))
    return appointments


def summary(appointments):
    """Counts per tier for dashboard cards."""
    counts = {"high": 0, "medium": 0, "low": 0}
    for a in appointments:
        if a.get("risk"):
            counts[a["risk"]["tier"]] += 1
    return counts


__all__ = ["annotate", "categories", "eligible", "explain", "features", "model", "summary", "MODEL_PATH"]
