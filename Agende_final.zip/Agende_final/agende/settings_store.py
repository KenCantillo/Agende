# =========================================================
# SETTINGS_STORE.PY
# Reads and saves the system_settings table (screen S39).
# Every rule has a safe default, so the system still works if
# a row is missing from the table.
# =========================================================

# key: (default, minimum, maximum, label, help text, group)
SETTING_RULES = {
    "booking_min_lead_minutes": (60, 0, 10080, "Minimum booking notice (minutes)",
                                 "A new booking must start at least this long from now.", "Booking"),
    "booking_max_days_ahead": (60, 1, 365, "Booking window (days ahead)",
                               "Clients cannot book further ahead than this.", "Booking"),
    "slot_interval_minutes": (30, 5, 240, "Slot spacing (minutes)",
                              "Offered start times are spaced this far apart.", "Booking"),
    "buffer_minutes": (0, 0, 240, "Buffer after each appointment (minutes)",
                       "0 = back-to-back appointments are allowed (blueprint 10.2).", "Booking"),
    "cancellation_cutoff_hours": (2, 0, 168, "Client cancel / reschedule cutoff (hours)",
                                  "Clients cannot cancel or reschedule this close to the start. Staff and admins can, with a reason.", "Cancellation"),
    "require_cancellation_reason": (1, 0, 1, "Require a cancellation reason",
                                    "1 = yes, 0 = optional.", "Cancellation"),
    "reminder_hours_before": (24, 1, 168, "Advance reminder (hours before)",
                              "When the N007 reminder is created for client and staff.", "Notifications"),
    "auto_expire_pending": (1, 0, 1, "Expire unanswered requests",
                            "1 = a pending request whose start time passes becomes Expired and frees the slot.", "Notifications"),
    "forecast_min_weeks": (26, 4, 104, "Minimum weeks of history for forecasting",
                           "No model is trained below this. 26 comes from the minimum-weeks experiment "
                           "(docs/FORECAST_MODEL_REPORT.md): shorter windows had clearly larger errors.", "Forecasting"),
    "forecast_auto_retrain": (1, 0, 1, "Retrain the model automatically",
                              "1 = when a new complete week of live records exists, housekeeping retrains and deploys the model.", "Forecasting"),
    "noshow_risk_enabled": (1, 0, 1, "Show no-show risk to staff",
                            "1 = staff and admins see an advisory low / medium / high no-show risk on upcoming appointments "
                            "(never shown to clients). Use it to prioritize reminders, never to cancel or reject.", "Forecasting"),
    "forecast_horizon_weeks": (4, 1, 26, "Forecast horizon (weeks)",
                               "How many future weeks the forecast covers.", "Forecasting"),
}


def get_settings(cursor):
    """Return {key: int} with defaults filled in for anything missing or invalid."""
    values = {key: rule[0] for key, rule in SETTING_RULES.items()}
    cursor.execute("SELECT setting_key, setting_value FROM system_settings")
    for row in cursor.fetchall():
        key = row["setting_key"]
        if key in SETTING_RULES:
            default, low, high = SETTING_RULES[key][:3]
            try:
                number = int(str(row["setting_value"]).strip())
                values[key] = number if low <= number <= high else default
            except (TypeError, ValueError):
                values[key] = default
    return values


def parse_settings_form(form):
    """Validate the settings form. Returns (clean_values, errors)."""
    clean, errors = {}, []
    for key, (default, low, high, label, _help, _group) in SETTING_RULES.items():
        raw = (form.get(key) or "").strip()
        try:
            number = int(raw)
        except ValueError:
            errors.append(f"{label}: enter a whole number.")
            continue
        if not (low <= number <= high):
            errors.append(f"{label}: must be between {low} and {high}.")
            continue
        clean[key] = number
    return clean, errors


def save_settings(cursor, clean_values, user_id):
    """Upsert the validated values. Returns {key: (old, new)} for the audit log."""
    current = get_settings(cursor)
    changes = {}
    for key, value in clean_values.items():
        if current.get(key) != value:
            changes[key] = (current.get(key), value)
        cursor.execute(
            """INSERT INTO system_settings (setting_key, setting_value, description, updated_by)
               VALUES (%s, %s, %s, %s)
               ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_by = VALUES(updated_by)""",
            (key, str(value), SETTING_RULES[key][4][:255], user_id),
        )
    return changes


def grouped_rules():
    """[(group, [(key, rule...), ...]), ...] for rendering the settings page."""
    groups = {}
    for key, rule in SETTING_RULES.items():
        groups.setdefault(rule[5], []).append((key, rule))
    return list(groups.items())
