# =========================================================
# ADMIN_INSIGHTS.PY - analytics, forecast model, reports R001-R007, audit logs (S35-S38)
# =========================================================


import json
from datetime import timedelta

from flask import Response, abort, flash, redirect, render_template, request, session, url_for

from agende import analytics
from agende import forecasting
from agende.audit import write_audit
from agende.database import db_cursor
from agende.notifications import notify_admins
from agende.scheduling import (status_label, to_date, to_time)
from agende.security import role_required
from agende.settings_store import get_settings
from agende.web import (app, csv_response, current_time, paginate)

from agende.routes.admin import admin_appointment_query
# ---------------------------------------------------------
# Analytics (S35)
# ---------------------------------------------------------
def _analytics_data():
    with db_cursor() as cursor:
        filters, errors = analytics.parse_filters(request.args, current_time().date(), cursor)
        data = analytics.compute(cursor, filters)
        cursor.execute("SELECT id, name FROM services ORDER BY name")
        services = cursor.fetchall()
        cursor.execute("SELECT p.id, pu.name AS provider_name FROM providers p JOIN users pu ON p.user_id = pu.id ORDER BY pu.name")
        providers = cursor.fetchall()
    return data, errors, services, providers


@app.route("/admin/analytics")
@role_required("admin")
def admin_analytics():
    data, errors, services, providers = _analytics_data()
    for message in errors:
        flash(message, "warning")
    return render_template("analytics.html", data=data, services=services, providers=providers, scope="admin",
                           active_page="analytics")


# ---------------------------------------------------------
# Forecast (S36)
# ---------------------------------------------------------
def _forecast_request(cursor):
    """Training workbench: train both models on the chosen data (preview, not yet deployed)."""
    settings = get_settings(cursor)
    today = current_time().date()
    source = request.values.get("source", "")
    imported = forecasting.imported_history_summary(cursor)
    if source not in forecasting.SOURCES:
        daily, start, end = forecasting.load_daily_counts(cursor, "live", today)
        live_weeks = len(forecasting.weekly_series(daily, start, end))
        source = "live" if live_weeks >= settings["forecast_min_weeks"] or not imported["n"] else "imported"
    train_start, train_end = to_date(request.values.get("train_start")), to_date(request.values.get("train_end"))
    try:
        horizon = int(request.values.get("horizon", settings["forecast_horizon_weeks"]))
    except ValueError:
        horizon = settings["forecast_horizon_weeks"]
    horizon = max(1, min(26, horizon))
    result = forecasting.train_from_source(cursor, source, today, settings["forecast_min_weeks"], horizon,
                                           train_start, train_end)
    result.update({"train_start_input": train_start, "train_end_input": train_end, "imported": imported})
    return result


def _forecast_redirect():
    return redirect(url_for("admin_forecast", source=request.form.get("source") or None,
                            train_start=request.form.get("train_start") or None,
                            train_end=request.form.get("train_end") or None, horizon=request.form.get("horizon") or None))


@app.route("/admin/forecast", methods=["GET", "POST"])
@role_required("admin")
def admin_forecast():
    if request.method == "POST":
        # Train & deploy: the trained pair becomes the active model (F081-F084, F088).
        with db_cursor(commit=True) as cursor:
            result = _forecast_request(cursor)
            if not result["available"]:
                flash("Model not trained. " + result["message"], "danger")
                return _forecast_redirect()
            settings = get_settings(cursor)
            version, ids = forecasting.deploy_models(cursor, result, session["user_id"], "manual", settings["forecast_min_weeks"])
            am, nm = result["appointment_model"], result["no_show_model"]
            write_audit(cursor, session["user_id"], "Trained and deployed forecast model", "forecast_model", ids[0],
                        new_value={"version": version, "models": ids, "source": result["source"],
                                   "training": [result["training_start"], result["training_end"]],
                                   "mae": [round(am["mae"], 3), round(nm["mae"], 3)]})
            notify_admins(cursor, "Forecast model updated",
                          f"{session.get('name', 'An administrator')} deployed {version} ({result['source_label']}, "
                          f"{len(result['weeks'])} weeks to {result['training_end'].strftime('%m/%d/%Y')}).",
                          "info", exclude_user_id=session["user_id"])
        flash(f"{version} trained and deployed. Test MAE: {am['mae']:.1f} appointments and {nm['mae']:.1f} "
              "did-not-attend per week. The dashboard now uses this model.", "success")
        return redirect(url_for("admin_forecast", source=result["source"]))
    with db_cursor() as cursor:
        settings = get_settings(cursor)
        result = _forecast_request(cursor)
        deployed = forecasting.deployed_forecast(cursor, current_time().date(), settings["forecast_horizon_weeks"])
        versions = forecasting.model_versions(cursor)
        breakdown = forecasting.breakdown(cursor, settings, current_time().date())
    return render_template("admin/forecast.html", forecast=result, deployed=deployed, versions=versions, breakdown=breakdown,
                           sources=forecasting.SOURCES, settings=settings, active_page="forecast")


@app.route("/admin/forecast/activate", methods=["POST"])
@role_required("admin")
def admin_forecast_activate():
    version = (request.form.get("version") or "").strip()
    with db_cursor(commit=True) as cursor:
        before = forecasting.active_models(cursor)
        if not forecasting.activate_version(cursor, version):
            flash("That model version was not found, so nothing changed.", "danger")
            return redirect(url_for("admin_forecast"))
        write_audit(cursor, session["user_id"], "Activated forecast model", "forecast_model", None,
                    old_value={"version": before["version"] if before else None}, new_value={"version": version})
        settings = get_settings(cursor)
    note = (" Automatic retraining is on, so a newer live model replaces it when the next complete week of records exists."
            if settings["forecast_auto_retrain"] else "")
    flash(f"{version} is now the active forecast model.{note}", "success")
    return redirect(url_for("admin_forecast"))


@app.route("/admin/forecast/model.json")
@role_required("admin")
def admin_forecast_model_file():
    with db_cursor(commit=True) as cursor:
        models = forecasting.active_models(cursor)
        if not models:
            flash("No forecast model is deployed yet, so there is no model file to download.", "warning")
            return redirect(url_for("admin_forecast"))
        write_audit(cursor, session["user_id"], "Downloaded forecast model", "forecast_model", models["appointments"]["id"],
                    details=models["version"])
    body = json.dumps(forecasting.export_model(models), indent=2, default=str)
    return Response(body, mimetype="application/json",
                    headers={"Content-Disposition": f"attachment; filename=agende_forecast_model_{models['version']}.json"})


# ---------------------------------------------------------
# Reports / export (S37, R001-R007)
# ---------------------------------------------------------
@app.route("/admin/reports")
@role_required("admin")
def admin_reports():
    with db_cursor() as cursor:
        cursor.execute("SELECT id, name FROM services ORDER BY name")
        services = cursor.fetchall()
        cursor.execute("SELECT p.id, pu.name AS provider_name FROM providers p JOIN users pu ON p.user_id = pu.id ORDER BY pu.name")
        providers = cursor.fetchall()
    defaults = {"start": (current_time().date() - timedelta(days=89)).isoformat(), "end": current_time().date().isoformat()}
    return render_template("admin/reports.html", services=services, providers=providers, defaults=defaults,
                           active_page="reports")


def _report_args():
    """Map the report form's start/end onto the appointment filters."""
    args = request.args.to_dict()
    args.setdefault("date_from", args.get("start", ""))
    args.setdefault("date_to", args.get("end", ""))
    return args


@app.route("/admin/reports/appointments.csv")
@role_required("admin")
def export_appointments_csv():
    query, params = admin_appointment_query(_report_args())
    with db_cursor(commit=True) as cursor:
        cursor.execute(query + " ORDER BY a.appointment_date DESC, a.start_time DESC", params)
        rows = cursor.fetchall()
        write_audit(cursor, session["user_id"], "Exported report", "report", None, details=f"R001 appointments ({len(rows)} rows)")
    return csv_response("agende_R001_appointments.csv",
                        ["Appointment ID", "Client", "Service", "Staff", "Date", "Start", "End", "Status", "Created"],
                        [[r["id"], r["client_name"], r["service_name"], r["provider_name"], r["appointment_date"],
                          to_time(r["start_time"]), to_time(r["end_time"]), status_label(r["status"]), r["created_at"]]
                         for r in rows])


@app.route("/admin/reports/<report>.csv")
@role_required("admin")
def export_report(report):
    args = _report_args()
    today = current_time().date()
    with db_cursor(commit=True) as cursor:
        if report == "cancellations":
            query, params = admin_appointment_query({**args, "status": "cancelled"})
            cursor.execute(
                f"""SELECT x.*, cb.name AS cancelled_by_name,
                           (SELECT MAX(h.created_at) FROM appointment_history h
                             WHERE h.appointment_id = x.id AND h.new_status = 'cancelled') AS cancelled_at
                    FROM ({query}) AS x LEFT JOIN users cb ON cb.id = x.cancelled_by
                    ORDER BY x.appointment_date DESC""", params)
            rows = cursor.fetchall()
            header = ["Appointment ID", "Client", "Service", "Staff", "Appointment date", "Cancelled on", "Reason", "Cancelled by"]
            data = [[r["id"], r["client_name"], r["service_name"], r["provider_name"], r["appointment_date"],
                     r["cancelled_at"], r["cancellation_reason"], r["cancelled_by_name"]] for r in rows]
            code = "R002"
        elif report == "no_shows":
            query, params = admin_appointment_query({**args, "status": "no_show"})
            cursor.execute(query + " ORDER BY a.appointment_date DESC", params)
            rows = cursor.fetchall()
            header = ["Appointment ID", "Date", "Time", "Service", "Staff", "Client", "Status"]
            data = [[r["id"], r["appointment_date"], to_time(r["start_time"]), r["service_name"], r["provider_name"],
                     r["client_name"], "Did not attend"] for r in rows]
            code = "R003"
        elif report in ("service_utilization", "staff_workload", "analytics"):
            filters, _ = analytics.parse_filters(request.args, today, cursor)
            result = analytics.compute(cursor, filters)
            period = f"{filters['start']} to {filters['end']}"
            if report == "service_utilization":
                header = ["Service", "Appointments", "Held a slot", "Potential slots", "Utilization %", "Cancelled", "Did not attend", "Period"]
                data = [[s["name"], s["total"], s["held"], s["potential_slots"], s["utilization"], s["cancelled"], s["no_show"], period]
                        for s in result["services"]]
                code = "R004"
            elif report == "staff_workload":
                header = ["Staff", "Appointments", "Completed", "Cancelled", "Did not attend", "Booked minutes",
                          "Available minutes", "Utilization %", "Did-not-attend rate %", "Period"]
                data = [[s["name"], s["total"], s["counts"]["completed"], s["counts"]["cancelled"], s["counts"]["no_show"],
                         s["booked_minutes"], s["available_minutes"], s["utilization"], s["no_show_rate"], period]
                        for s in result["staff"]]
                code = "R005"
            else:
                k = result["kpis"]
                header = ["Metric", "Value", "Definition"]
                data = [["Period", period, ""], ["Total appointments (A001)", k["total"], "All records in the period"],
                        ["Pending", k["pending"], ""], ["Confirmed (A002)", k["confirmed"], ""],
                        ["Completed (A003)", k["completed"], ""], ["Cancelled (A004)", k["cancelled"], ""],
                        ["Rejected", k["rejected"], ""], ["Did not attend (A005)", k["no_show"], ""], ["Expired", k["expired"], ""],
                        ["Did-not-attend rate % (A006)", k["no_show_rate"], "no_show / (completed + no_show)"],
                        ["Cancellation rate % (A007)", k["cancellation_rate"], "cancelled / total"],
                        ["Completion rate % (A008)", k["completion_rate"], "completed / (completed + no_show)"],
                        ["Staff utilization % ", k["utilization"], "booked minutes / available minutes"]]
                code = "R006"
        elif report == "forecast" and request.args.get("deployed") == "1":
            code = "R007"
            settings = get_settings(cursor)
            dep = forecasting.deployed_forecast(cursor, today, settings["forecast_horizon_weeks"])
            if not dep["available"]:
                header, data = ["Message"], [["No forecast model is deployed yet."]]
            else:
                m = dep["models"]
                header = ["Row type", "Week starting", "Appointments", "Did not attend", "Raw appointment prediction",
                          "Raw did-not-attend prediction"]
                data = [["Deployed model", m["version"], f"Source: {dep['source_label']}",
                         f"Training {m['training_start']} to {m['training_end']}",
                         f"Status: {'out of date' if dep['stale'] else 'current'}", f"Trigger: {m['trigger']}"]]
                for key, label in (("appointments", "Appointment model"), ("no_shows", "Did-not-attend model")):
                    row = m[key]
                    data.append([label, f"b0={float(row['intercept']):.4f}", f"b1={float(row['slope']):.4f}",
                                 f"MAE={row['mae']} RMSE={row['rmse']} R2={row['r2']}", f"Baseline MAE={row['baseline_mae']}", ""])
                data += [["Monitor (actual vs predicted)", w["week_start"], f"{w['appointments']} vs {w['appointments_pred']}",
                          f"{w['no_shows']} vs {w['no_shows_pred']}", round(w["appointments_raw"], 3), round(w["no_shows_raw"], 3)]
                         for w in dep["monitor"]]
                data += [["Forecast", f["week_start"], f["appointments"], f["no_shows"], round(f["appointments_raw"], 3),
                          round(f["no_shows_raw"], 3)] for f in dep["future"]]
        elif report == "forecast":
            result = _forecast_request(cursor)
            code = "R007"
            if not result["available"]:
                header, data = ["Message"], [[result["message"]]]
            else:
                am, nm = result["appointment_model"], result["no_show_model"]
                header = ["Row type", "Week starting", "Appointments", "Did not attend", "Raw appointment prediction",
                          "Raw did-not-attend prediction"]
                data = [["Model", f"Source: {result['source_label']}", f"Training {result['training_start']} to {result['training_end']}",
                         f"Horizon {result['horizon']} weeks", "", ""],
                        ["Appointment model", f"b0={am['intercept']:.4f}", f"b1={am['slope']:.4f}",
                         f"MAE={am['mae']:.3f} RMSE={am['rmse']:.3f} R2={'' if am['r2'] is None else round(am['r2'], 4)}",
                         f"Baseline MAE={am['baseline_mae']:.3f}", ""],
                        ["Did-not-attend model", f"b0={nm['intercept']:.4f}", f"b1={nm['slope']:.4f}",
                         f"MAE={nm['mae']:.3f} RMSE={nm['rmse']:.3f} R2={'' if nm['r2'] is None else round(nm['r2'], 4)}",
                         f"Baseline MAE={nm['baseline_mae']:.3f}", ""]]
                data += [["Actual", w["week_start"], w["appointments"], w["no_shows"], "", ""] for w in result["weeks"]]
                data += [["Forecast", f["week_start"], f["appointments"], f["no_shows"], round(f["appointments_raw"], 3),
                          round(f["no_shows_raw"], 3)] for f in result["future"]]
        else:
            abort(404)
        write_audit(cursor, session["user_id"], "Exported report", "report", None, details=f"{code} {report} ({len(data)} rows)")
    return csv_response(f"agende_{code}_{report}.csv", header, data)


# ---------------------------------------------------------
# Audit logs (S38)
# ---------------------------------------------------------
def _audit_query(args):
    query = """SELECT a.*, u.name AS user_name, u.email AS user_email FROM audit_logs a
               LEFT JOIN users u ON a.user_id = u.id WHERE 1=1"""
    params = []
    if args.get("user"):
        query += " AND (u.name LIKE %s OR u.email LIKE %s)"
        params += [f"%{args['user']}%"] * 2
    if args.get("action"):
        query += " AND a.action LIKE %s"
        params.append(f"%{args['action']}%")
    if args.get("entity"):
        query += " AND a.entity_name = %s"
        params.append(args["entity"])
    if to_date(args.get("date_from")):
        query += " AND a.created_at >= %s"
        params.append(to_date(args.get("date_from")))
    if to_date(args.get("date_to")):
        query += " AND a.created_at < %s"
        params.append(to_date(args.get("date_to")) + timedelta(days=1))
    return query, params


@app.route("/admin/audit-logs")
@role_required("admin")
def admin_audit_logs():
    query, params = _audit_query(request.args)
    with db_cursor() as cursor:
        cursor.execute("SELECT COUNT(*) AS n FROM (" + query + ") AS x", params)
        pager = paginate(cursor.fetchone()["n"], 40)
        cursor.execute(query + " ORDER BY a.created_at DESC, a.id DESC LIMIT %s OFFSET %s",
                       params + [pager["per_page"], pager["offset"]])
        logs = cursor.fetchall()
        cursor.execute("SELECT DISTINCT entity_name FROM audit_logs ORDER BY entity_name")
        entities = [r["entity_name"] for r in cursor.fetchall()]
    return render_template("admin/audit_logs.html", logs=logs, pager=pager, entities=entities, active_page="audit")


@app.route("/admin/audit-logs.csv")
@role_required("admin")
def export_audit_csv():
    query, params = _audit_query(request.args)
    with db_cursor() as cursor:
        cursor.execute(query + " ORDER BY a.created_at DESC, a.id DESC LIMIT 20000", params)
        logs = cursor.fetchall()
    return csv_response("agende_audit_logs.csv", ["Time", "User", "Action", "Entity", "Record ID", "Old value", "New value", "Details", "IP"],
                        [[r["created_at"], r["user_name"] or "System", r["action"], r["entity_name"], r["entity_id"],
                          r["old_value"], r["new_value"], r["details"], r["ip_address"]] for r in logs])
