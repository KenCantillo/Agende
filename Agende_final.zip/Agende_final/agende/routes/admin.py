# =========================================================
# ADMIN.PY - administrator dashboard, appointments, calendar, clients (S28, S33, S34)
# =========================================================


from collections import Counter
from datetime import timedelta

from flask import abort, flash, redirect, render_template, request, session, url_for

from agende import analytics
from agende import forecasting
from agende import noshow_risk
from agende.appointments import AppointmentError, available_actions, create_appointment
from agende.audit import write_audit
from agende.database import db_cursor
from agende.routes.client import booking_catalog
from agende.scheduling import (ALL_STATUSES, STATUS_LABELS, appointments_outside_availability, find_overlapping_pairs,
                        to_date, to_time)
from agende.security import role_required
from agende.settings_store import get_settings
from agende.web import (app, current_time, smart_order, month_bounds, month_grid, paginate, selected_month, shift_month)



ADMIN_LIST_SELECT = """SELECT a.*, s.name AS service_name, s.duration, u.name AS client_name, pu.name AS provider_name
                       FROM appointments a
                       JOIN services s ON a.service_id = s.id
                       JOIN users u ON a.user_id = u.id
                       JOIN providers p ON a.provider_id = p.id
                       JOIN users pu ON p.user_id = pu.id"""


def _pct_change(current, previous):
    if not previous:
        return None
    return round(100.0 * (current - previous) / previous)


def _all_needs_attention(cursor, today):
    cursor.execute("SELECT p.id FROM providers p WHERE p.is_active = 1")
    rows = []
    for provider in cursor.fetchall():
        rows += appointments_outside_availability(cursor, provider["id"], today)
    return rows


def _dashboard_forecast(cursor, settings, today):
    """Forecast card on the dashboard: read from the DEPLOYED model (no retraining here)."""
    daily, start, end = forecasting.load_daily_counts(cursor, "live", today)
    live_weeks = forecasting.weekly_series(daily, start, end)
    deployed = forecasting.deployed_forecast(cursor, today, settings["forecast_horizon_weeks"])
    card = {"recent": live_weeks[-8:], "live_weeks": len(live_weeks), "min_weeks": settings["forecast_min_weeks"],
            "deployed": deployed, "auto_retrain": settings["forecast_auto_retrain"]}
    if not deployed["available"]:
        card["state"] = "none"
        card["message"] = (f"No forecast model is deployed yet. {len(live_weeks)} of {settings['forecast_min_weeks']} "
                           "complete weeks of live records exist"
                           + ("; the model trains automatically once enough are recorded." if settings["forecast_auto_retrain"] else "."))
    elif deployed["stale"]:
        card["state"] = "stale"
        card["message"] = (f"The active model {deployed['version']} ({deployed['source_label']}) was trained on data up to "
                           f"{deployed['models']['training_end'].strftime('%m/%d/%Y')}, {deployed['weeks_ahead']} weeks ago, which is too far "
                           "to extend a straight line. Retrain it on recent records.")
    else:
        card["state"] = "ok"
        week = today - timedelta(days=today.weekday())
        cursor.execute("""SELECT COUNT(*) AS n FROM appointments WHERE appointment_date BETWEEN %s AND %s
                          AND status NOT IN ('rejected', 'expired')""", (week, week + timedelta(days=6)))
        card["booked_this_week"] = cursor.fetchone()["n"]
    return card


# ---------------------------------------------------------
# Dashboard (S28)
# ---------------------------------------------------------
@app.route("/admin/dashboard")
@role_required("admin")
def admin_dashboard():
    now = current_time()
    today = now.date()
    month_start = today.replace(day=1)
    prev_start = shift_month(month_start, -1)
    prev_end = min(prev_start + (today - month_start), month_start - timedelta(days=1))
    week_start = today - timedelta(days=today.weekday())
    cal_month = selected_month()
    cal_first, cal_last = month_bounds(cal_month)
    with db_cursor() as cursor:
        settings = get_settings(cursor)
        mtd = analytics.daily_counts(cursor, month_start, today)
        prev = analytics.daily_counts(cursor, prev_start, prev_end)
        mtd_counts, prev_counts = Counter(), Counter()
        for day_counts in mtd.values():
            mtd_counts.update(day_counts)
        for day_counts in prev.values():
            prev_counts.update(day_counts)
        cursor.execute("SELECT COUNT(*) AS n FROM appointments WHERE status = 'pending' AND appointment_date >= %s", (today,))
        pending_now = cursor.fetchone()["n"]

        trend_days = [today - timedelta(days=89 - i) for i in range(90)]
        trend_raw = analytics.daily_counts(cursor, trend_days[0], today)
        trend = {"labels": [d.strftime("%b %d") for d in trend_days],
                 "total": [sum(trend_raw[d].values()) for d in trend_days],
                 "completed": [trend_raw[d]["completed"] for d in trend_days],
                 "cancelled": [trend_raw[d]["cancelled"] + trend_raw[d]["no_show"] for d in trend_days]}

        cursor.execute(
            """SELECT s.name, COUNT(*) AS n FROM appointments a JOIN services s ON s.id = a.service_id
               WHERE a.appointment_date BETWEEN %s AND %s GROUP BY s.name ORDER BY n DESC""",
            (today - timedelta(days=29), today))
        by_service = cursor.fetchall()
        if len(by_service) > 5:
            by_service = by_service[:4] + [{"name": "Other", "n": sum(r["n"] for r in by_service[4:])}]

        cursor.execute(ADMIN_LIST_SELECT + " ORDER BY a.created_at DESC, a.id DESC LIMIT 6")
        recent = cursor.fetchall()
        cursor.execute(ADMIN_LIST_SELECT + """ WHERE a.status IN ('pending','confirmed') AND
                       (a.appointment_date > %s OR (a.appointment_date = %s AND a.start_time >= %s))
                       ORDER BY a.appointment_date, a.start_time LIMIT 5""", (today, today, now.time()))
        upcoming = cursor.fetchall()

        cal_counts = analytics.daily_counts(cursor, cal_first, cal_last)
        marked = cal_counts                                   # {date: {status: count}} -> coloured dots

        week = analytics.daily_counts(cursor, week_start, week_start + timedelta(days=6))
        week_days = [week_start + timedelta(days=i) for i in range(7)]
        week_chart = {"labels": [d.strftime("%a") for d in week_days],
                      "scheduled": [week[d]["pending"] + week[d]["confirmed"] for d in week_days],
                      "completed": [week[d]["completed"] for d in week_days]}

        cursor.execute(
            """SELECT p.id, pu.name, SUM(a.status IN ('pending','confirmed')) AS upcoming_7,
                      COUNT(a.id) AS total_30
               FROM providers p JOIN users pu ON pu.id = p.user_id
               LEFT JOIN appointments a ON a.provider_id = p.id AND a.appointment_date BETWEEN %s AND %s
               WHERE p.is_active = 1 GROUP BY p.id, pu.name ORDER BY total_30 DESC""",
            (today, today + timedelta(days=6)))
        workload = cursor.fetchall()

        conflicts = find_overlapping_pairs(cursor, today, today + timedelta(days=90))
        needs_attention = _all_needs_attention(cursor, today)
        unusual = analytics.unusual_activity(cursor, today)
        forecast = _dashboard_forecast(cursor, settings, today)
        noshow_risk.annotate(cursor, upcoming, settings, now)
        cursor.execute(ADMIN_LIST_SELECT + """ WHERE a.status IN ('pending','confirmed')
                       AND a.appointment_date BETWEEN %s AND %s""", (today, today + timedelta(days=6)))
        risk_counts = noshow_risk.summary(noshow_risk.annotate(cursor, cursor.fetchall(), settings, now))

    conflict_staff = Counter(c["provider_id"] for c in conflicts)
    for row in workload:
        row["conflicts"] = conflict_staff.get(row["id"], 0)
    kpi = {
        "total": sum(mtd_counts.values()), "total_prev": sum(prev_counts.values()),
        "pending": pending_now,
        "completed": mtd_counts["completed"], "completed_prev": prev_counts["completed"],
        "no_show": mtd_counts["no_show"], "no_show_prev": prev_counts["no_show"],
    }
    for key in ("total", "completed", "no_show"):
        kpi[key + "_change"] = _pct_change(kpi[key], kpi[key + "_prev"])
    forecast_summary = None
    if forecast["state"] == "ok":
        future = forecast["deployed"]["future"]
        last_week = forecast["recent"][-1] if forecast["recent"] else None
        forecast_summary = {"this": future[0], "next": future[1] if len(future) > 1 else None, "last": last_week,
                            "change": _pct_change(future[0]["appointments"], last_week["appointments"]) if last_week else None}
    return render_template(
        "admin/dashboard.html", active_page="dashboard", stats=kpi,
        status_strip=[(s, STATUS_LABELS[s], mtd_counts[s]) for s in ALL_STATUSES],
        trend=trend, by_service=by_service, recent=recent, upcoming=upcoming, week_chart=week_chart,
        workload=workload, conflicts=conflicts, needs_attention=needs_attention, unusual=unusual,
        forecast=forecast, forecast_summary=forecast_summary, risk_counts=risk_counts,
        calendar_weeks=month_grid(cal_month, marked), calendar_month=cal_month,
        prev_month=shift_month(cal_month, -1), next_month=shift_month(cal_month, 1),
        week_number=today.isocalendar()[1])


# ---------------------------------------------------------
# Appointments (S33, S34) and booking on a client's behalf
# ---------------------------------------------------------
ADMIN_SORTS = {"smart": None,     # upcoming soonest -> farthest, then past (web.smart_order)
               "id": "a.id ASC",
               "date_desc": "a.appointment_date DESC, a.start_time DESC, a.id DESC",
               "date": "a.appointment_date ASC, a.start_time ASC, a.id ASC",
               "status": "a.status ASC, a.appointment_date ASC, a.id ASC", "created": "a.created_at DESC, a.id DESC"}


def admin_appointment_query(args):
    query = ADMIN_LIST_SELECT + " WHERE 1=1"
    params = []
    if args.get("status") in ALL_STATUSES:
        query += " AND a.status = %s"
        params.append(args["status"])
    for name, column, op in (("date_from", "a.appointment_date", ">="), ("date_to", "a.appointment_date", "<=")):
        if to_date(args.get(name)):
            query += f" AND {column} {op} %s"
            params.append(to_date(args.get(name)))
    for name, column in (("provider_id", "a.provider_id"), ("service_id", "a.service_id"), ("client_id", "a.user_id")):
        if str(args.get(name, "")).isdigit():
            query += f" AND {column} = %s"
            params.append(int(args[name]))
    q = (args.get("q") or "").strip()
    if q:
        query += " AND (a.id = %s OR u.name LIKE %s OR pu.name LIKE %s OR s.name LIKE %s)"
        params.extend([int(q.lstrip("#")) if q.lstrip("#").isdigit() else -1, f"%{q}%", f"%{q}%", f"%{q}%"])
    return query, params


@app.route("/admin/appointments")
@role_required("admin")
def admin_appointments():
    query, params = admin_appointment_query(request.args)
    sort = request.args.get("sort", "smart")
    sort = sort if sort in ADMIN_SORTS else "smart"
    order_sql, order_params = smart_order() if sort == "smart" else (ADMIN_SORTS[sort], [])
    with db_cursor() as cursor:
        cursor.execute("SELECT COUNT(*) AS n FROM (" + query + ") AS x", params)
        pager = paginate(cursor.fetchone()["n"], 30)
        cursor.execute(query + f" ORDER BY {order_sql} LIMIT %s OFFSET %s",
                       params + order_params + [pager["per_page"], pager["offset"]])
        rows = cursor.fetchall()
        cursor.execute("SELECT p.id, pu.name AS provider_name FROM providers p JOIN users pu ON p.user_id = pu.id ORDER BY pu.name")
        providers = cursor.fetchall()
        cursor.execute("SELECT id, name FROM services ORDER BY name")
        services = cursor.fetchall()
        settings = get_settings(cursor)
        now = current_time()
        noshow_risk.annotate(cursor, rows, settings, now)
    for row in rows:
        row["actions"] = available_actions(row, "admin", settings, now)
    return render_template("admin/appointments.html", appointments=rows, pager=pager, providers=providers,
                           services=services, sort=sort, active_page="appointments")


@app.route("/admin/appointments/new", methods=["GET", "POST"])
@role_required("admin")
def admin_new_appointment():
    with db_cursor() as cursor:
        services = booking_catalog(cursor)
        settings = get_settings(cursor)
        cursor.execute("""SELECT u.id, u.name, u.email FROM users u JOIN roles r ON r.id = u.role_id
                          WHERE r.name = 'user' AND u.is_active = 1 ORDER BY u.name""")
        clients = cursor.fetchall()
    if request.method == "POST":
        client_id = request.form.get("client_id", type=int)
        service_id = request.form.get("service_id", type=int)
        provider_id = request.form.get("provider_id", type=int)
        day, start = to_date(request.form.get("appointment_date")), to_time(request.form.get("start_time"))
        if not (client_id and service_id and provider_id and day and start):
            flash("Choose a client, service, staff member, date and time.", "danger")
        else:
            try:
                with db_cursor(commit=True) as cursor:
                    new_id = create_appointment(cursor, client_id, provider_id, service_id, day, start,
                                                request.form.get("notes", ""), session["user_id"], "admin",
                                                get_settings(cursor), current_time())
                flash("Appointment booked and confirmed. The client and staff member were notified.", "success")
                return redirect(url_for("appointment_detail", appointment_id=new_id))
            except AppointmentError as error:
                flash(str(error), "danger")
    return render_template("book.html", services=services, settings=settings, clients=clients, active_page="appointments",
                           preselect_service=request.values.get("service_id", type=int),
                           preselect_provider=request.values.get("provider_id", type=int),
                           preselect_client=request.values.get("client_id", type=int),
                           form_action=url_for("admin_new_appointment"))


@app.route("/admin/calendar")
@role_required("admin")
def admin_calendar():
    month = selected_month()
    first, last = month_bounds(month)
    provider_id = request.args.get("provider_id", type=int)
    query = """SELECT a.*, s.name AS service_name, s.description AS service_description, u.name AS client_name,
                      pu.name AS provider_name
               FROM appointments a JOIN services s ON a.service_id = s.id JOIN users u ON a.user_id = u.id
               JOIN providers p ON p.id = a.provider_id JOIN users pu ON pu.id = p.user_id
               WHERE a.status NOT IN ('cancelled','rejected','expired') AND a.appointment_date BETWEEN %s AND %s"""
    params = [first, last]
    if provider_id:
        query += " AND a.provider_id = %s"
        params.append(provider_id)
    with db_cursor() as cursor:
        cursor.execute(query + " ORDER BY a.appointment_date, a.start_time", params)
        appointments = cursor.fetchall()
        cursor.execute("SELECT p.id, pu.name AS provider_name FROM providers p JOIN users pu ON p.user_id = pu.id ORDER BY pu.name")
        providers = cursor.fetchall()
    return render_template("calendar.html", appointments=appointments, timeline_month=month.strftime("%Y-%m"),
                           person_field="client_name", active_page="calendar", providers=providers,
                           provider_filter=provider_id, title="Appointment Calendar",
                           subtitle="All staff appointments on a scrollable month timeline.")


# ---------------------------------------------------------
# Clients
# ---------------------------------------------------------
@app.route("/admin/clients")
@role_required("admin")
def admin_clients():
    q = request.args.get("q", "").strip()
    query = """SELECT u.*, COUNT(a.id) AS total_appointments, SUM(a.status = 'no_show') AS no_shows,
                      MAX(a.appointment_date) AS last_appointment
               FROM users u JOIN roles r ON r.id = u.role_id
               LEFT JOIN appointments a ON a.user_id = u.id
               WHERE r.name = 'user'"""
    params = []
    if q:
        query += " AND (u.name LIKE %s OR u.email LIKE %s OR u.phone LIKE %s)"
        params += [f"%{q}%"] * 3
    if request.args.get("status") in ("active", "inactive"):
        query += " AND u.is_active = %s"
        params.append(1 if request.args["status"] == "active" else 0)
    query += " GROUP BY u.id"
    with db_cursor() as cursor:
        cursor.execute("SELECT COUNT(*) AS n FROM (" + query + ") AS x", params)
        pager = paginate(cursor.fetchone()["n"])
        cursor.execute(query + " ORDER BY u.name LIMIT %s OFFSET %s", params + [pager["per_page"], pager["offset"]])
        clients = cursor.fetchall()
    return render_template("admin/clients.html", clients=clients, pager=pager, search_query=q, active_page="clients")


@app.route("/admin/clients/<int:client_id>")
@role_required("admin")
def admin_view_client(client_id):
    with db_cursor() as cursor:
        cursor.execute("""SELECT u.* FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = %s AND r.name = 'user'""",
                       (client_id,))
        client = cursor.fetchone()
        if client is None:
            abort(404)
        cursor.execute(ADMIN_LIST_SELECT + " WHERE a.user_id = %s ORDER BY a.appointment_date DESC, a.start_time DESC",
                       (client_id,))
        appointments = cursor.fetchall()
    stats = analytics.summarize_status_counts(Counter(a["status"] for a in appointments))
    return render_template("admin/client_view.html", client=client, appointments=appointments, stats=stats,
                           active_page="clients")


def _toggle_user(cursor, target_id):
    cursor.execute("SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = %s FOR UPDATE",
                   (target_id,))
    target = cursor.fetchone()
    if target is None:
        abort(404)
    if target["id"] == session["user_id"]:
        return None, "You cannot deactivate your own account."
    if target["is_active"] and target["role_name"] == "admin":
        cursor.execute("""SELECT COUNT(*) AS n FROM users u JOIN roles r ON r.id = u.role_id
                          WHERE r.name = 'admin' AND u.is_active = 1""")
        if cursor.fetchone()["n"] <= 1:
            return None, "At least one active administrator is required."
    new_value = 0 if target["is_active"] else 1
    cursor.execute("UPDATE users SET is_active = %s WHERE id = %s", (new_value, target_id))
    write_audit(cursor, session["user_id"], "Activated user" if new_value else "Deactivated user", "user", target_id,
                old_value={"is_active": target["is_active"]}, new_value={"is_active": new_value},
                details=target["email"])
    message = f"{target['name']} was {'activated' if new_value else 'deactivated'}."
    if not new_value:
        cursor.execute("""SELECT COUNT(*) AS n FROM appointments WHERE status IN ('pending','confirmed') AND appointment_date >= %s
                          AND (user_id = %s OR provider_id IN (SELECT id FROM providers WHERE user_id = %s))""",
                       (current_time().date(), target_id, target_id))
        open_count = cursor.fetchone()["n"]
        if open_count:
            message += f" They still have {open_count} upcoming appointment(s); history is kept and those need follow-up."
    return target, message


@app.route("/admin/clients/<int:client_id>/toggle", methods=["POST"])
@role_required("admin")
def admin_toggle_client(client_id):
    with db_cursor(commit=True) as cursor:
        _, message = _toggle_user(cursor, client_id)
    flash(message, "success")
    return redirect(url_for("admin_clients"))
