# =========================================================
# ROUTES_AUTH.PY  - Module 1: Authentication (F001-F012, S01-S05)
# =========================================================

import hashlib
import secrets
from datetime import timedelta

from flask import flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from agende import config
from agende.audit import write_audit
from agende.database import db_cursor
from agende.notifications import email_enabled, notify_role, send_email
from agende.security import (safe_next_url, validate_email, validate_name, validate_password, validate_phone)
from agende.web import app, current_time, dashboard_url

RESET_TOKEN_HOURS = 1


def hash_token(token):
    return hashlib.sha256(token.encode("utf-8")).hexdigest()


def create_reset_token(cursor, user_id, created_by=None):
    """One-time password reset token, valid for RESET_TOKEN_HOURS. Only its hash is stored."""
    token = secrets.token_urlsafe(32)
    cursor.execute("UPDATE password_resets SET used_at = %s WHERE user_id = %s AND used_at IS NULL",
                   (current_time(), user_id))
    cursor.execute(
        "INSERT INTO password_resets (user_id, token_hash, expires_at, created_by) VALUES (%s, %s, %s, %s)",
        (user_id, hash_token(token), current_time() + timedelta(hours=RESET_TOKEN_HOURS), created_by))
    return token


@app.route("/")
def index():
    if "user_id" not in session:
        return render_template("landing.html")
    return redirect(dashboard_url())


@app.route("/login", methods=["GET", "POST"])
def login():
    # Already signed in? Show the form anyway (with a notice) so another account
    # can log in; logging in replaces the current session.
    email = ""
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not email or not password:
            flash("Email and password are required.", "danger")
            return render_template("login.html", email=email, show_test_accounts=config.SHOW_TEST_ACCOUNTS)

        with db_cursor(commit=True) as cursor:
            cursor.execute(
                """SELECT u.*, r.name AS role_name, p.id AS provider_id FROM users u
                   JOIN roles r ON u.role_id = r.id
                   LEFT JOIN providers p ON p.user_id = u.id
                   WHERE u.email = %s""", (email,))
            user = cursor.fetchone()
            if user is None or not check_password_hash(user["password"], password):
                write_audit(cursor, user["id"] if user else None, "Failed login", "user",
                            user["id"] if user else None, details=f"Email entered: {email[:120]}")
                flash("Invalid email or password.", "danger")
                return render_template("login.html", email=email, show_test_accounts=config.SHOW_TEST_ACCOUNTS)
            if not user["is_active"]:
                flash("This account has been deactivated. Please contact the administrator.", "danger")
                return render_template("login.html", email=email, show_test_accounts=config.SHOW_TEST_ACCOUNTS)
            if user["role_name"] not in ("user", "provider", "admin"):
                flash("Account role is invalid. Please contact the administrator.", "danger")
                return render_template("login.html", email=email, show_test_accounts=config.SHOW_TEST_ACCOUNTS)
            cursor.execute("UPDATE users SET last_login = %s WHERE id = %s", (current_time(), user["id"]))
            write_audit(cursor, user["id"], "Logged in", "user", user["id"])

        next_url = safe_next_url(request.args.get("next"))
        session.clear()                                   # new session id on login (fixation protection)
        session["user_id"] = user["id"]
        session["name"] = user["name"]
        session["role"] = user["role_name"]
        if user["role_name"] == "provider":
            session["provider_id"] = user["provider_id"]
        flash(f"Welcome back, {user['name']}!", "success")
        return redirect(next_url or dashboard_url())
    return render_template("login.html", email=email, show_test_accounts=config.SHOW_TEST_ACCOUNTS)


@app.context_processor
def signed_in_notice():
    """Lets login.html say who is currently signed in."""
    if "user_id" in session and request.endpoint == "login":
        return {"signed_in_as": {"name": session.get("name"), "role": session.get("role")}}
    return {}


@app.route("/register", methods=["GET", "POST"])
def register():
    form = {"name": "", "email": "", "phone": ""}
    if request.method == "POST":
        form = {key: request.form.get(key, "").strip() for key in form}
        form["email"] = form["email"].lower()
        password = request.form.get("password", "")
        errors = [e for e in (validate_name(form["name"]), validate_email(form["email"]),
                              validate_phone(form["phone"]),
                              validate_password(password, request.form.get("confirm_password", ""))) if e]
        if not request.form.get("agree"):
            errors.append("Please agree to the use of your information for appointment scheduling.")
        if not errors:
            try:
                with db_cursor(commit=True) as cursor:
                    cursor.execute("SELECT id FROM users WHERE email = %s", (form["email"],))
                    if cursor.fetchone():
                        errors.append("An account with this email already exists.")
                    else:
                        cursor.execute(
                            """INSERT INTO users (role_id, name, email, password, phone)
                               VALUES ((SELECT id FROM roles WHERE name = 'user'), %s, %s, %s, %s)""",
                            (form["name"], form["email"], generate_password_hash(password), form["phone"] or None))
                        write_audit(cursor, cursor.lastrowid, "Registered", "user", cursor.lastrowid,
                                    new_value={"email": form["email"]})
            except Exception:
                errors.append("Unable to create account. Please try again.")
        if errors:
            for message in errors:
                flash(message, "danger")
            return render_template("register.html", form=form)
        flash("Account created successfully. Please log in.", "success")
        return redirect(url_for("login"))
    return render_template("register.html", form=form)


@app.route("/logout", methods=["POST"])
def logout():
    if "user_id" in session:
        with db_cursor(commit=True) as cursor:
            write_audit(cursor, session["user_id"], "Logged out", "user", session["user_id"])
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("login"))


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        if validate_email(email):
            flash("Enter a valid email address.", "danger")
            return render_template("forgot_password.html", email=email)
        with db_cursor(commit=True) as cursor:
            cursor.execute("SELECT id, name, email FROM users WHERE email = %s AND is_active = 1", (email,))
            user = cursor.fetchone()
            if user:
                write_audit(cursor, user["id"], "Requested password reset", "user", user["id"])
                if email_enabled():
                    token = create_reset_token(cursor, user["id"])
                    link = config.BASE_URL.rstrip("/") + url_for("reset_password", token=token)
                    send_email(user["email"], "AGENDE password reset",
                               f"Hello {user['name']},\n\nUse this link within {RESET_TOKEN_HOURS} hour to set a new "
                               f"password:\n{link}\n\nIf you did not ask for this, ignore this email.")
                else:
                    notify_role(cursor, "admin", "Password reset requested",
                                f"{user['name']} ({user['email']}) asked for a password reset. "
                                "Open Users & Roles to generate a reset link.", "warning", "N012")
        # Same message whether or not the email exists (no account enumeration).
        flash("If that email belongs to an active account, reset instructions have been sent"
              + ("" if email_enabled() else " to the administrator, who will give you a reset link") + ".", "success")
        return redirect(url_for("login"))
    return render_template("forgot_password.html", email="")


@app.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    with db_cursor() as cursor:
        cursor.execute(
            """SELECT pr.id, pr.user_id, pr.expires_at, pr.used_at, u.email FROM password_resets pr
               JOIN users u ON u.id = pr.user_id WHERE pr.token_hash = %s""", (hash_token(token),))
        reset = cursor.fetchone()
    if reset is None or reset["used_at"] is not None or reset["expires_at"] < current_time():
        flash("This reset link is invalid or has expired. Please request a new one.", "danger")
        return redirect(url_for("forgot_password"))
    if request.method == "POST":
        password = request.form.get("password", "")
        error = validate_password(password, request.form.get("confirm_password", ""))
        if error:
            flash(error, "danger")
            return render_template("reset_password.html", token=token, email=reset["email"])
        with db_cursor(commit=True) as cursor:
            cursor.execute("UPDATE users SET password = %s WHERE id = %s", (generate_password_hash(password), reset["user_id"]))
            cursor.execute("UPDATE password_resets SET used_at = %s WHERE id = %s", (current_time(), reset["id"]))
            write_audit(cursor, reset["user_id"], "Reset password", "user", reset["user_id"])
        session.clear()
        flash("Password updated. You can now log in.", "success")
        return redirect(url_for("login"))
    return render_template("reset_password.html", token=token, email=reset["email"])
