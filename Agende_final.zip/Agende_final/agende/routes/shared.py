# =========================================================
# ROUTES_SHARED.PY
# Pages used by more than one role. Every route checks the role AND
# whether this user may see the specific record (blueprint 32).
#   - Appointment details / reschedule / status actions (S14-S16, S23, S34)
#   - Slot and date availability API used by the booking pickers (S11)
#   - Notifications for all roles (S18, S40), global search, profile (S19)
#   - Service catalog (S07, S08)
# =========================================================

from datetime import timedelta

from flask import abort, flash, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from agende.appointments import (AppointmentError, available_actions, can_view, change_status, fetch_appointment,
                          get_service, reschedule)
from agende import noshow_risk
from agende.audit import write_audit
from agende.database import db_cursor
from agende.notifications import notify_role
from agende.scheduling import (SLOT_AVAILABLE, load_calendar, provider_offers_service, slots_for_day, to_date, to_time)
from agende.security import login_required, role_required, safe_next_url, validate_name, validate_password, validate_phone
from agende.settings_store import get_settings
from agende.web import (app, back_to_list, current_time, format_time12, month_bounds, paginate, today)


def _actor():
    return session["user_id"], session["role"], session.get("provider_id")


# ---------------------------------------------------------
# Appointment details
# ---------------------------------------------------------
@app.route("/appointments/<int:appointment_id>")
@login_required
def appointment_detail(appointment_id):
    user_id, role, provider_id = _actor()
    with db_cursor() as cursor:
        appointment = fetch_appointment(cursor, appointment_id)
        if appointment is None:
            abort(404)
        if not can_view(appointment, role, user_id, provider_id):
            abort(403)
        cursor.execute(
            """SELECT h.*, u.name AS performed_by_name FROM appointment_history h
               LEFT JOIN users u ON u.id = h.performed_by
               WHERE h.appointment_id = %s ORDER BY h.created_at DESC, h.id DESC""", (appointment_id,))
        history = cursor.fetchall()
        client_stats = None
        if role in ("provider", "admin"):
            cursor.execute(
                """SELECT COUNT(*) AS total, SUM(status = 'completed') AS completed, SUM(status = 'no_show') AS no_show,
                          SUM(status = 'cancelled') AS cancelled
                   FROM appointments WHERE user_id = %s AND id <> %s""", (appointment["user_id"], appointment_id))
            client_stats = cursor.fetchone()
        settings = get_settings(cursor)
        if role in ("provider", "admin"):          # never computed or shown for clients
            noshow_risk.annotate(cursor, [appointment], settings, current_time(), with_reasons=True)
    actions = available_actions(appointment, role, settings, current_time())
    return render_template("appointment_detail.html", appointment=appointment, history=history, actions=actions,
                           client_stats=client_stats, settings=settings, active_page="appointments")


# Old 2.1 address kept so bookmarks still work.
@app.route("/user/appointment/<int:appointment_id>")
@login_required
def user_view_appointment(appointment_id):
    return redirect(url_for("appointment_detail", appointment_id=appointment_id))


@app.route("/appointments/<int:appointment_id>/status", methods=["POST"])
@login_required
def update_appointment_status(appointment_id):
    return _apply_status(appointment_id, request.form.get("status", ""))


def _apply_status(appointment_id, new_status):
    user_id, role, provider_id = _actor()
    reason = request.form.get("reason", "")
    next_url = safe_next_url(request.form.get("next")) or url_for("appointment_detail", appointment_id=appointment_id)
    try:
        with db_cursor(commit=True) as cursor:
            settings = get_settings(cursor)
            updated = change_status(cursor, appointment_id, new_status, user_id, role, provider_id,
                                    settings, current_time(), reason)
        flash(f"Appointment #{appointment_id} is now {updated['status'].replace('_', ' ') if updated['status'] != 'no_show' else 'marked as did not attend'}.", "success")
    except AppointmentError as error:
        flash(str(error), "danger")
    except PermissionError:
        abort(403)
    return redirect(next_url)


@app.route("/user/appointment/<int:appointment_id>/cancel", methods=["POST"])
@role_required("user")
def cancel_appointment(appointment_id):
    """2.1 cancel address, now with a reason and the cancellation cutoff."""
    return _apply_status(appointment_id, "cancelled")


@app.route("/appointments/<int:appointment_id>/reschedule", methods=["GET", "POST"])
@login_required
def reschedule_appointment(appointment_id):
    user_id, role, provider_id = _actor()
    with db_cursor() as cursor:
        appointment = fetch_appointment(cursor, appointment_id)
        if appointment is None:
            abort(404)
        if not can_view(appointment, role, user_id, provider_id):
            abort(403)
        settings = get_settings(cursor)
    if "reschedule" not in available_actions(appointment, role, settings, current_time()):
        flash("This appointment can no longer be rescheduled online.", "danger")
        return redirect(url_for("appointment_detail", appointment_id=appointment_id))

    if request.method == "POST":
        new_day = to_date(request.form.get("appointment_date"))
        new_start = to_time(request.form.get("start_time"))
        try:
            with db_cursor(commit=True) as cursor:
                reschedule(cursor, appointment_id, new_day, new_start, user_id, role, provider_id,
                           get_settings(cursor), current_time(), request.form.get("reason", ""))
            flash("Appointment rescheduled successfully." + (" It is waiting for staff confirmation." if role == "user" else ""), "success")
            return redirect(url_for("appointment_detail", appointment_id=appointment_id))
        except AppointmentError as error:
            flash(str(error), "danger")
        except PermissionError:
            abort(403)
    return render_template("reschedule.html", appointment=appointment, settings=settings, active_page="appointments")


# ---------------------------------------------------------
# Availability API for the date and time pickers (JSON)
# ---------------------------------------------------------
def _picker_context(cursor):
    """Work out provider/service/client and which rules apply, with access checks."""
    user_id, role, provider_id = _actor()
    try:
        chosen_provider = int(request.args.get("provider_id", 0))
        service_id = int(request.args.get("service_id", 0))
    except ValueError:
        abort(400)
    appointment_id = request.args.get("appointment_id", type=int)
    client_id = user_id if role == "user" else request.args.get("client_id", type=int)
    if appointment_id:
        appointment = fetch_appointment(cursor, appointment_id)
        if not can_view(appointment, role, user_id, provider_id):
            abort(403)
        chosen_provider, service_id, client_id = appointment["provider_id"], appointment["service_id"], appointment["user_id"]
    elif role == "provider":
        abort(403)                      # staff do not create bookings (role matrix)
    service = get_service(cursor, service_id)
    if service is None or not provider_offers_service(cursor, chosen_provider, service_id):
        return None
    return {"provider_id": chosen_provider, "service": service, "client_id": client_id,
            "appointment_id": appointment_id, "client_rules": role == "user"}


@app.route("/api/slots")
@login_required
def api_slots():
    day = to_date(request.args.get("date"))
    with db_cursor() as cursor:
        context = _picker_context(cursor)
        if context is None:
            return jsonify({"slots": [], "message": "This staff member does not offer the selected service."})
        if day is None:
            return jsonify({"slots": [], "message": "Choose a date."})
        settings = get_settings(cursor)
        calendar = load_calendar(cursor, context["provider_id"], day, day,
                                 context["appointment_id"], context["client_id"])
    now = current_time()
    slots = slots_for_day(calendar, day, context["service"]["duration"], settings, now, context["client_rules"])
    visible = [s for s in slots if s["state"] != "too_far"]
    return jsonify({
        "date": day.isoformat(),
        "duration": context["service"]["duration"],
        "slots": [{"time": s["start"].strftime("%H:%M"), "label": format_time12(s["start"]),
                   "end_label": format_time12(s["end"]), "state": s["state"]} for s in visible],
        "message": None if any(s["state"] == SLOT_AVAILABLE for s in visible)
        else ("No working hours on this day." if not slots else "No available times on this day."),
    })


@app.route("/api/available-dates")
@login_required
def api_available_dates():
    month = to_date(f"{request.args.get('month', '')}-01") or today().replace(day=1)
    first, last = month_bounds(month)
    now = current_time()
    with db_cursor() as cursor:
        context = _picker_context(cursor)
        if context is None:
            return jsonify({"days": {}, "message": "This staff member does not offer the selected service."})
        settings = get_settings(cursor)
        if context["client_rules"]:
            last = min(last, now.date() + timedelta(days=settings["booking_max_days_ahead"]))
        first = max(first, now.date())
        if first > last:
            return jsonify({"days": {}, "max_date": (now.date() + timedelta(days=settings["booking_max_days_ahead"])).isoformat()})
        calendar = load_calendar(cursor, context["provider_id"], first, last,
                                 context["appointment_id"], context["client_id"])
    days, day = {}, first
    while day <= last:
        slots = slots_for_day(calendar, day, context["service"]["duration"], settings, now, context["client_rules"])
        free = sum(1 for s in slots if s["state"] == SLOT_AVAILABLE)
        if free:
            days[day.isoformat()] = free
        day += timedelta(days=1)
    return jsonify({"days": days,
                    "max_date": (now.date() + timedelta(days=settings["booking_max_days_ahead"])).isoformat()
                    if context["client_rules"] else None})


# ---------------------------------------------------------
# Notifications (all roles)
# ---------------------------------------------------------
@app.route("/notifications")
@login_required
def notifications_page():
    show = request.args.get("show", "all")
    where = "user_id = %s" + (" AND is_read = 0" if show == "unread" else "")
    with db_cursor() as cursor:
        cursor.execute(f"SELECT COUNT(*) AS n FROM notifications WHERE {where}", (session["user_id"],))
        pager = paginate(cursor.fetchone()["n"], 20)
        cursor.execute(
            f"""SELECT * FROM notifications WHERE {where}
                ORDER BY created_at DESC, id DESC LIMIT %s OFFSET %s""",
            (session["user_id"], pager["per_page"], pager["offset"]))
        items = cursor.fetchall()
    return render_template("notifications.html", notifications=items, pager=pager, show=show,
                           active_page="notifications")


# 2.1 addresses kept for old links.
@app.route("/user/notifications")
@app.route("/provider/notifications")
@login_required
def user_notifications():
    return redirect(url_for("notifications_page"))


@app.route("/notifications/<int:notification_id>/open")
@login_required
def open_notification(notification_id):
    with db_cursor(commit=True) as cursor:
        cursor.execute("SELECT * FROM notifications WHERE id = %s AND user_id = %s", (notification_id, session["user_id"]))
        item = cursor.fetchone()
        if item is None:
            abort(404)
        cursor.execute("UPDATE notifications SET is_read = 1 WHERE id = %s", (notification_id,))
    if item["appointment_id"]:
        return redirect(url_for("appointment_detail", appointment_id=item["appointment_id"]))
    return redirect(url_for("notifications_page"))


@app.route("/notifications/<int:notification_id>/read", methods=["POST"])
@login_required
def mark_notification_read(notification_id):
    with db_cursor(commit=True) as cursor:
        cursor.execute("UPDATE notifications SET is_read = 1 WHERE id = %s AND user_id = %s",
                       (notification_id, session["user_id"]))
        if cursor.rowcount == 0:
            cursor.execute("SELECT id FROM notifications WHERE id = %s AND user_id = %s", (notification_id, session["user_id"]))
            if cursor.fetchone() is None:
                abort(403)
    flash("Notification marked as read.", "success")
    return redirect(safe_next_url(request.form.get("next")) or url_for("notifications_page"))


@app.route("/notifications/read-all", methods=["POST"])
@login_required
def mark_all_notifications_read():
    with db_cursor(commit=True) as cursor:
        cursor.execute("UPDATE notifications SET is_read = 1 WHERE user_id = %s AND is_read = 0", (session["user_id"],))
        count = cursor.rowcount
    flash(f"Marked {count} notification(s) as read.", "success")
    return redirect(safe_next_url(request.form.get("next")) or url_for("notifications_page"))


@app.route("/admin/announcements", methods=["POST"])
@role_required("admin")
def admin_announcement():
    """N012 system announcement to a group of users."""
    audience = request.form.get("audience", "all")
    title = request.form.get("title", "").strip()
    message = request.form.get("message", "").strip()
    if audience not in ("all", "user", "provider", "admin") or not title or not message:
        flash("Choose an audience and enter a title and message.", "danger")
        return redirect(url_for("notifications_page"))
    with db_cursor(commit=True) as cursor:
        sent = notify_role(cursor, audience, title, message, "info", "N012")
        write_audit(cursor, session["user_id"], "Sent announcement", "notification", None,
                    new_value={"audience": audience, "title": title}, details=message)
    flash(f"Announcement sent to {sent} account(s).", "success")
    return redirect(url_for("notifications_page"))


# ---------------------------------------------------------
# Global search (header search box)
# ---------------------------------------------------------
@app.route("/search")
@login_required
def search():
    user_id, role, provider_id = _actor()
    q = request.args.get("q", "").strip()[:80]
    appointments, users = [], []
    if q:
        like = f"%{q}%"
        query = """SELECT a.id, a.appointment_date, a.start_time, a.status, s.name AS service_name,
                          cu.name AS client_name, pu.name AS provider_name
                   FROM appointments a JOIN services s ON s.id = a.service_id
                   JOIN users cu ON cu.id = a.user_id
                   JOIN providers p ON p.id = a.provider_id JOIN users pu ON pu.id = p.user_id
                   WHERE (s.name LIKE %s OR pu.name LIKE %s OR cu.name LIKE %s OR a.id = %s)"""
        params = [like, like, like, int(q.lstrip("#")) if q.lstrip("#").isdigit() else -1]
        if role == "user":
            query += " AND a.user_id = %s"
            params.append(user_id)
        elif role == "provider":
            query += " AND a.provider_id = %s"
            params.append(provider_id)
        query += " ORDER BY a.appointment_date DESC, a.start_time DESC LIMIT 30"
        with db_cursor() as cursor:
            cursor.execute(query, params)
            appointments = cursor.fetchall()
            if role == "admin":
                cursor.execute(
                    """SELECT u.id, u.name, u.email, u.is_active, r.name AS role_name FROM users u
                       JOIN roles r ON r.id = u.role_id WHERE u.name LIKE %s OR u.email LIKE %s
                       ORDER BY u.name LIMIT 15""", (like, like))
                users = cursor.fetchall()
    return render_template("search.html", q=q, appointments=appointments, users=users)


# ---------------------------------------------------------
# Profile (all roles)
# ---------------------------------------------------------
@app.route("/user/profile", methods=["GET", "POST"])
@login_required
def user_profile():
    user_id = session["user_id"]
    with db_cursor() as cursor:
        cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
        user = cursor.fetchone()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        new_password = request.form.get("new_password", "")
        errors = [e for e in (validate_name(name), validate_phone(phone)) if e]
        if new_password:
            if not check_password_hash(user["password"], request.form.get("current_password", "")):
                errors.append("Your current password is incorrect.")
            error = validate_password(new_password, request.form.get("confirm_password", ""))
            if error:
                errors.append(error)
        if errors:
            for message in errors:
                flash(message, "danger")
        else:
            with db_cursor(commit=True) as cursor:
                if new_password:
                    cursor.execute("UPDATE users SET name = %s, phone = %s, password = %s WHERE id = %s",
                                   (name, phone or None, generate_password_hash(new_password), user_id))
                else:
                    cursor.execute("UPDATE users SET name = %s, phone = %s WHERE id = %s", (name, phone or None, user_id))
                write_audit(cursor, user_id, "Updated profile" + (" and password" if new_password else ""), "user", user_id,
                            old_value={"name": user["name"], "phone": user["phone"]}, new_value={"name": name, "phone": phone})
            session["name"] = name
            flash("Profile updated successfully.", "success")
            return redirect(url_for("user_profile"))
    return render_template("profile.html", user=user, active_page="profile")


# ---------------------------------------------------------
# Service catalog (S07, S08)
# ---------------------------------------------------------
@app.route("/services")
@login_required
def service_catalog():
    with db_cursor() as cursor:
        cursor.execute("SELECT * FROM services WHERE is_active = 1 ORDER BY name")
        services = cursor.fetchall()
        cursor.execute(
            """SELECT ps.service_id, p.id AS provider_id, pu.name AS provider_name, p.position
               FROM provider_services ps JOIN providers p ON p.id = ps.provider_id
               JOIN users pu ON pu.id = p.user_id
               WHERE p.is_active = 1 AND pu.is_active = 1 ORDER BY pu.name""")
        staff = cursor.fetchall()
    by_service = {}
    for row in staff:
        by_service.setdefault(row["service_id"], []).append(row)
    return render_template("services_catalog.html", services=services, staff_by_service=by_service,
                           active_page="services")


__all__ = ["back_to_list"]
