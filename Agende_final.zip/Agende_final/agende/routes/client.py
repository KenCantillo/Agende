# =========================================================
# ROUTES_CLIENT.PY  - Client screens (S06, S09-S13, S17)
# =========================================================

from datetime import timedelta

from flask import flash, redirect, render_template, request, session, url_for

from agende.appointments import AppointmentError, available_actions, create_appointment
from agende.database import db_cursor
from agende.scheduling import ALL_STATUSES, to_date, to_time
from agende.security import role_required
from agende.settings_store import get_settings
from agende.web import (app, current_time, smart_order, month_bounds, month_grid, paginate, selected_month, shift_month)

LIST_SELECT = """SELECT a.*, s.name AS service_name, s.duration, pu.name AS provider_name
                 FROM appointments a
                 JOIN services s ON a.service_id = s.id
                 JOIN providers p ON a.provider_id = p.id
                 JOIN users pu ON p.user_id = pu.id"""

SORTS = {
    "smart": None,     # upcoming soonest -> farthest, then past (web.smart_order)
    "id": "a.id ASC",
    "nearest": "a.appointment_date ASC, a.start_time ASC, a.id ASC",
    "newest": "a.created_at DESC, a.id DESC",
    "oldest": "a.created_at ASC, a.id ASC",
    "date_desc": "a.appointment_date DESC, a.start_time DESC, a.id DESC",
}


@app.route("/user/dashboard")
@role_required("user")
def user_dashboard():
    user_id = session["user_id"]
    now = current_time()
    month = selected_month()
    first, last = month_bounds(month)
    with db_cursor() as cursor:
        settings = get_settings(cursor)
        cursor.execute(
            LIST_SELECT + """ WHERE a.user_id = %s AND a.status IN ('pending','confirmed') AND a.appointment_date >= %s
                              ORDER BY a.appointment_date, a.start_time LIMIT 6""", (user_id, now.date()))
        upcoming = [a for a in cursor.fetchall()
                    if not (to_date(a["appointment_date"]) == now.date() and to_time(a["end_time"]) <= now.time())]
        cursor.execute(
            """SELECT
                 SUM(status = 'pending' AND appointment_date >= %s) AS pending,
                 SUM(status = 'confirmed' AND appointment_date >= %s) AS confirmed,
                 SUM(status = 'completed') AS completed
               FROM appointments WHERE user_id = %s""", (now.date(), now.date(), user_id))
        counts = cursor.fetchone()
        cursor.execute(
            LIST_SELECT + """ WHERE a.user_id = %s AND a.status IN ('completed','cancelled','rejected','no_show','expired')
                              ORDER BY a.appointment_date DESC, a.start_time DESC LIMIT 5""", (user_id,))
        recent = cursor.fetchall()
        cursor.execute(
            """SELECT appointment_date, status, COUNT(*) AS n FROM appointments
               WHERE user_id = %s AND appointment_date BETWEEN %s AND %s
               GROUP BY appointment_date, status""", (user_id, first, last))
        marked = {}
        for r in cursor.fetchall():
            marked.setdefault(to_date(r["appointment_date"]), {})[r["status"]] = int(r["n"])
    for item in upcoming:
        item["actions"] = available_actions(item, "user", settings, now)
    return render_template(
        "user/dashboard.html", active_page="dashboard",
        next_appointment=upcoming[0] if upcoming else None, upcoming=upcoming[1:], recent=recent,
        stats={"upcoming": int(counts["pending"] or 0) + int(counts["confirmed"] or 0), "pending": int(counts["pending"] or 0),
             "confirmed": int(counts["confirmed"] or 0), "completed": int(counts["completed"] or 0)},
        calendar_weeks=month_grid(month, marked), calendar_month=month,
        prev_month=shift_month(month, -1), next_month=shift_month(month, 1))


def _client_list(statuses, default_sort):
    user_id = session["user_id"]
    args = request.args
    query = LIST_SELECT + " WHERE a.user_id = %s"
    params = [user_id]
    status = args.get("status", "")
    if status in ALL_STATUSES and status in statuses:
        query += " AND a.status = %s"
        params.append(status)
    else:
        status = ""
        query += " AND a.status IN (" + ",".join(["%s"] * len(statuses)) + ")"
        params.extend(statuses)
    if to_date(args.get("date_from")):
        query += " AND a.appointment_date >= %s"
        params.append(to_date(args.get("date_from")))
    if to_date(args.get("date_to")):
        query += " AND a.appointment_date <= %s"
        params.append(to_date(args.get("date_to")))
    if args.get("service_id", "").isdigit():
        query += " AND a.service_id = %s"
        params.append(int(args["service_id"]))
    q = args.get("q", "").strip()
    if q:
        query += " AND (a.id = %s OR s.name LIKE %s OR pu.name LIKE %s)"
        params.extend([int(q.lstrip("#")) if q.lstrip("#").isdigit() else -1, f"%{q}%", f"%{q}%"])
    sort = args.get("sort", default_sort)
    sort = sort if sort in SORTS else default_sort
    with db_cursor() as cursor:
        cursor.execute("SELECT COUNT(*) AS n FROM (" + query + ") AS x", params)
        pager = paginate(cursor.fetchone()["n"])
        order_sql, order_params = smart_order() if sort == "smart" else (SORTS[sort], [])
        cursor.execute(query + f" ORDER BY {order_sql} LIMIT %s OFFSET %s",
                       params + order_params + [pager["per_page"], pager["offset"]])
        rows = cursor.fetchall()
        cursor.execute("SELECT id, name FROM services ORDER BY name")
        services = cursor.fetchall()
        settings = get_settings(cursor)
    now = current_time()
    for row in rows:
        row["actions"] = available_actions(row, "user", settings, now)
    return rows, pager, services, status, sort


@app.route("/user/appointments")
@role_required("user")
def user_appointments():
    rows, pager, services, status, sort = _client_list(("pending", "confirmed"), "smart")
    return render_template("user/appointments.html", appointments=rows, pager=pager, services=services,
                           status_filter=status, sort=sort, active_page="appointments")


@app.route("/user/history")
@role_required("user")
def user_history():
    rows, pager, services, status, sort = _client_list(
        ("completed", "cancelled", "rejected", "no_show", "expired"), "date_desc")
    return render_template("user/history.html", appointments=rows, pager=pager, services=services,
                           status_filter=status, sort=sort, active_page="history")


def booking_catalog(cursor):
    """Active services with the active staff who offer them (wizard data)."""
    cursor.execute("SELECT id, name, description, duration FROM services WHERE is_active = 1 ORDER BY name")
    services = cursor.fetchall()
    cursor.execute(
        """SELECT ps.service_id, p.id, pu.name, p.position FROM provider_services ps
           JOIN providers p ON p.id = ps.provider_id JOIN users pu ON pu.id = p.user_id
           JOIN services s ON s.id = ps.service_id
           WHERE p.is_active = 1 AND pu.is_active = 1 AND s.is_active = 1 ORDER BY pu.name""")
    staff = {}
    for row in cursor.fetchall():
        staff.setdefault(row["service_id"], []).append({"id": row["id"], "name": row["name"], "position": row["position"] or ""})
    for service in services:
        service["staff"] = staff.get(service["id"], [])
    return services


@app.route("/user/book", methods=["GET", "POST"])
@role_required("user")
def book_appointment():
    with db_cursor() as cursor:
        services = booking_catalog(cursor)
        settings = get_settings(cursor)
    if request.method == "POST":
        try:
            service_id = int(request.form.get("service_id", 0))
            provider_id = int(request.form.get("provider_id", 0))
        except ValueError:
            service_id = provider_id = 0
        day = to_date(request.form.get("appointment_date"))
        start = to_time(request.form.get("start_time"))
        if not (service_id and provider_id and day and start):
            flash("Please choose a service, staff member, date and an available time.", "danger")
        else:
            try:
                with db_cursor(commit=True) as cursor:
                    appointment_id = create_appointment(
                        cursor, session["user_id"], provider_id, service_id, day, start,
                        request.form.get("notes", ""), session["user_id"], "user", get_settings(cursor), current_time())
                flash("Appointment request submitted. You will be notified once it is confirmed.", "success")
                return redirect(url_for("appointment_detail", appointment_id=appointment_id))
            except AppointmentError as error:
                flash(str(error), "danger")
    return render_template("book.html", services=services, settings=settings, active_page="book",
                           preselect_service=request.values.get("service_id", type=int),
                           preselect_provider=request.values.get("provider_id", type=int),
                           form_action=url_for("book_appointment"), clients=None)


@app.route("/user/calendar")
@role_required("user")
def user_calendar():
    month = selected_month()
    first, last = month_bounds(month)
    with db_cursor() as cursor:
        cursor.execute(
            """SELECT a.*, s.name AS service_name, s.description AS service_description, pu.name AS provider_name
               FROM appointments a JOIN services s ON a.service_id = s.id
               JOIN providers p ON a.provider_id = p.id JOIN users pu ON p.user_id = pu.id
               WHERE a.user_id = %s AND a.status NOT IN ('cancelled','rejected','expired')
                 AND a.appointment_date BETWEEN %s AND %s
               ORDER BY a.appointment_date, a.start_time""", (session["user_id"], first, last))
        appointments = cursor.fetchall()
    return render_template("calendar.html", appointments=appointments, timeline_month=month.strftime("%Y-%m"),
                           person_field="provider_name", active_page="calendar",
                           title="My Calendar", subtitle="Your appointments on a scrollable month timeline.")


__all__ = ["booking_catalog", "timedelta"]
