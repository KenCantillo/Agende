"""Page routes, one module per area. Each module does `from agende.web import app` and registers its pages.

    auth.py            login, register, logout, password reset              (Module 1)
    shared.py          appointment details/actions, notifications, search,
                       profile, service catalog, slot API (all roles)        (Modules 5, 8)
    client.py          client dashboard, booking, lists, calendar            (Modules 5, 7)
    staff.py           staff dashboard, requests, availability, block time   (Modules 4, 7, 9)
    admin.py           admin dashboard, appointments, calendar, clients      (Modules 2, 5, 7)
    admin_manage.py    staff, users & roles, schedules, services, settings   (Modules 2, 3, 4, 13)
    admin_insights.py  analytics, forecast model, reports, audit logs        (Modules 9-12)
"""
