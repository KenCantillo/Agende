# =========================================================
# ADMIN_MANAGE.PY - staff, users & roles, schedules, services, system settings (S29-S32, S39)
# =========================================================


from datetime import timedelta

from flask import abort, flash, redirect, render_template, request, session, url_for
from werkzeug.security import generate_password_hash

from agende import noshow_risk
from agende.audit import write_audit
from agende.database import db_cursor
from agende.routes.auth import create_reset_token
from agende.routes.staff import (affected_ids, block_text, day_windows, delete_block, delete_window, parse_block_form,
                          report_schedule_effects, save_block, window_text,
                          save_window, toggle_window)
from agende.scheduling import (appointments_outside_availability)
from agende.security import role_required, validate_email, validate_name, validate_password, validate_phone
from agende.settings_store import get_settings, grouped_rules, parse_settings_form, save_settings
from agende.web import (app, current_time, paginate)

from agende.routes.admin import _toggle_user
# ---------------------------------------------------------
# Staff (S30)
# ---------------------------------------------------------
def _provider_services(cursor):
    cursor.execute("""SELECT ps.provider_id, s.id, s.name, s.is_active FROM provider_services ps
                      JOIN services s ON s.id = ps.service_id ORDER BY s.name""")
    result = {}
    for row in cursor.fetchall():
        result.setdefault(row["provider_id"], []).append(row)
    return result


@app.route("/admin/providers")
@role_required("admin")
def admin_providers():
    with db_cursor() as cursor:
        cursor.execute(
            """SELECT p.*, pu.name AS provider_name, pu.email, pu.phone, pu.is_active AS account_active,
                      (SELECT COUNT(*) FROM appointments WHERE provider_id = p.id) AS total_appointments,
                      (SELECT COUNT(*) FROM appointments WHERE provider_id = p.id AND status IN ('pending','confirmed')
                         AND appointment_date >= %s) AS upcoming,
                      (SELECT COUNT(*) FROM provider_schedules WHERE provider_id = p.id AND is_available = 1) AS windows
               FROM providers p JOIN users pu ON p.user_id = pu.id ORDER BY pu.name""", (current_time().date(),))
        providers = cursor.fetchall()
        services = _provider_services(cursor)
    return render_template("admin/providers.html", providers=providers, services_by_provider=services,
                           active_page="providers")


def _provider_form_values():
    return {"name": request.form.get("name", "").strip(), "email": request.form.get("email", "").strip().lower(),
            "phone": request.form.get("phone", "").strip(), "position": request.form.get("position", "").strip()[:100],
            "service_ids": sorted({int(v) for v in request.form.getlist("service_ids") if v.isdigit()})}


@app.route("/admin/providers/add", methods=["GET", "POST"])
@role_required("admin")
def admin_add_provider():
    with db_cursor() as cursor:
        cursor.execute("SELECT * FROM services WHERE is_active = 1 ORDER BY name")
        services = cursor.fetchall()
    values = {"name": "", "email": "", "phone": "", "position": "", "service_ids": []}
    if request.method == "POST":
        values = _provider_form_values()
        password = request.form.get("password", "")
        errors = [e for e in (validate_name(values["name"]), validate_email(values["email"]),
                              validate_phone(values["phone"]), validate_password(password)) if e]
        if not values["service_ids"]:
            errors.append("Assign at least one service.")
        if not errors:
            with db_cursor(commit=True) as cursor:
                cursor.execute("SELECT id FROM users WHERE email = %s", (values["email"],))
                if cursor.fetchone():
                    errors.append("An account with this email already exists.")
                else:
                    cursor.execute(
                        """INSERT INTO users (role_id, name, email, password, phone)
                           VALUES ((SELECT id FROM roles WHERE name = 'provider'), %s, %s, %s, %s)""",
                        (values["name"], values["email"], generate_password_hash(password), values["phone"] or None))
                    user_id = cursor.lastrowid
                    cursor.execute("INSERT INTO providers (user_id, position, is_active) VALUES (%s, %s, 1)",
                                   (user_id, values["position"] or None))
                    provider_id = cursor.lastrowid
                    for service_id in values["service_ids"]:
                        cursor.execute("INSERT INTO provider_services (provider_id, service_id) VALUES (%s, %s)",
                                       (provider_id, service_id))
                    write_audit(cursor, session["user_id"], "Created staff member", "provider", provider_id,
                                new_value={"email": values["email"], "services": values["service_ids"]})
            if not errors:
                flash("Staff member added. Next, set their weekly availability.", "success")
                return redirect(url_for("admin_schedules", provider_id=provider_id))
        for message in errors:
            flash(message, "danger")
    return render_template("admin/provider_form.html", services=services, provider=None, values=values,
                           active_page="providers")


@app.route("/admin/providers/<int:provider_id>/edit", methods=["GET", "POST"])
@role_required("admin")
def admin_edit_provider(provider_id):
    with db_cursor() as cursor:
        cursor.execute("""SELECT p.*, pu.name, pu.email, pu.phone FROM providers p JOIN users pu ON p.user_id = pu.id
                          WHERE p.id = %s""", (provider_id,))
        provider = cursor.fetchone()
        if provider is None:
            abort(404)
        cursor.execute("SELECT * FROM services ORDER BY is_active DESC, name")
        services = cursor.fetchall()
        current_ids = sorted(s["id"] for s in _provider_services(cursor).get(provider_id, []))
    values = {"name": provider["name"], "email": provider["email"], "phone": provider["phone"] or "",
              "position": provider["position"] or "", "service_ids": current_ids}
    if request.method == "POST":
        values = _provider_form_values()
        values["email"] = provider["email"]
        errors = [e for e in (validate_name(values["name"]), validate_phone(values["phone"])) if e]
        if not values["service_ids"]:
            errors.append("Assign at least one service.")
        if not errors:
            with db_cursor(commit=True) as cursor:
                cursor.execute("UPDATE users SET name = %s, phone = %s WHERE id = %s",
                               (values["name"], values["phone"] or None, provider["user_id"]))
                cursor.execute("UPDATE providers SET position = %s WHERE id = %s", (values["position"] or None, provider_id))
                removed = [sid for sid in current_ids if sid not in values["service_ids"]]
                added = [sid for sid in values["service_ids"] if sid not in current_ids]
                for sid in removed:
                    cursor.execute("DELETE FROM provider_services WHERE provider_id = %s AND service_id = %s", (provider_id, sid))
                for sid in added:
                    cursor.execute("INSERT INTO provider_services (provider_id, service_id) VALUES (%s, %s)", (provider_id, sid))
                if removed:
                    cursor.execute(
                        "SELECT COUNT(*) AS n FROM appointments WHERE provider_id = %s AND status IN ('pending','confirmed') "
                        "AND appointment_date >= %s AND service_id IN (" + ",".join(["%s"] * len(removed)) + ")",
                        [provider_id, current_time().date()] + removed)
                    still_booked = cursor.fetchone()["n"]
                    if still_booked:
                        flash(f"{still_booked} upcoming appointment(s) use a service you removed from this staff member. "
                              "They were kept; reassign or reschedule them if needed.", "warning")
                write_audit(cursor, session["user_id"], "Updated staff member", "provider", provider_id,
                            old_value={"name": provider["name"], "phone": provider["phone"], "services": current_ids},
                            new_value={"name": values["name"], "phone": values["phone"], "services": values["service_ids"]})
            flash("Staff member updated.", "success")
            return redirect(url_for("admin_providers"))
        for message in errors:
            flash(message, "danger")
    return render_template("admin/provider_form.html", services=services, provider=provider, values=values,
                           active_page="providers")


@app.route("/admin/providers/<int:provider_id>/toggle", methods=["POST"])
@role_required("admin")
def admin_toggle_provider(provider_id):
    with db_cursor(commit=True) as cursor:
        cursor.execute("SELECT * FROM providers WHERE id = %s FOR UPDATE", (provider_id,))
        provider = cursor.fetchone()
        if provider is None:
            abort(404)
        new_value = 0 if provider["is_active"] else 1
        cursor.execute("UPDATE providers SET is_active = %s WHERE id = %s", (new_value, provider_id))
        write_audit(cursor, session["user_id"], "Activated staff" if new_value else "Deactivated staff", "provider",
                    provider_id, old_value={"is_active": provider["is_active"]}, new_value={"is_active": new_value})
        cursor.execute("""SELECT COUNT(*) AS n FROM appointments WHERE provider_id = %s AND status IN ('pending','confirmed')
                          AND appointment_date >= %s""", (provider_id, current_time().date()))
        open_count = cursor.fetchone()["n"]
    message = "Staff member " + ("activated." if new_value else "deactivated; they no longer appear for new bookings.")
    if not new_value and open_count:
        message += f" {open_count} upcoming appointment(s) were kept and need to be reassigned or cancelled."
    flash(message, "warning" if (not new_value and open_count) else "success")
    return redirect(url_for("admin_providers"))


@app.route("/admin/providers/<int:provider_id>/schedule")
@role_required("admin")
def admin_view_provider_schedule(provider_id):
    return redirect(url_for("admin_schedules", provider_id=provider_id))


# ---------------------------------------------------------
# Users & roles (S29)
# ---------------------------------------------------------
@app.route("/admin/users", methods=["GET", "POST"])
@role_required("admin")
def admin_users():
    if request.method == "POST":            # create a client or administrator account
        name, email = request.form.get("name", "").strip(), request.form.get("email", "").strip().lower()
        phone, role = request.form.get("phone", "").strip(), request.form.get("role", "user")
        password = request.form.get("password", "")
        errors = [e for e in (validate_name(name), validate_email(email), validate_phone(phone),
                              validate_password(password)) if e]
        if role not in ("user", "admin"):
            errors.append("Create staff accounts from the Staff page so services can be assigned.")
        if not errors:
            with db_cursor(commit=True) as cursor:
                cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
                if cursor.fetchone():
                    errors.append("An account with this email already exists.")
                else:
                    cursor.execute("""INSERT INTO users (role_id, name, email, password, phone)
                                      VALUES ((SELECT id FROM roles WHERE name = %s), %s, %s, %s, %s)""",
                                   (role, name, email, generate_password_hash(password), phone or None))
                    write_audit(cursor, session["user_id"], "Created user", "user", cursor.lastrowid,
                                new_value={"email": email, "role": role})
        for message in errors:
            flash(message, "danger")
        if not errors:
            flash(f"Account created for {name}.", "success")
        return redirect(url_for("admin_users"))

    q, role_filter, status = request.args.get("q", "").strip(), request.args.get("role", ""), request.args.get("status", "")
    query = """SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON u.role_id = r.id WHERE 1=1"""
    params = []
    if role_filter in ("user", "provider", "admin"):
        query += " AND r.name = %s"
        params.append(role_filter)
    if status in ("active", "inactive"):
        query += " AND u.is_active = %s"
        params.append(1 if status == "active" else 0)
    if q:
        query += " AND (u.name LIKE %s OR u.email LIKE %s)"
        params += [f"%{q}%", f"%{q}%"]
    with db_cursor() as cursor:
        cursor.execute("SELECT COUNT(*) AS n FROM (" + query + ") AS x", params)
        pager = paginate(cursor.fetchone()["n"])
        cursor.execute(query + " ORDER BY u.created_at DESC, u.id DESC LIMIT %s OFFSET %s",
                       params + [pager["per_page"], pager["offset"]])
        users = cursor.fetchall()
    reset_link = session.pop("reset_link", None)
    return render_template("admin/users.html", users=users, pager=pager, search_query=q, role_filter=role_filter,
                           status_filter=status, reset_link=reset_link, active_page="users")


@app.route("/admin/users/<int:target_user_id>/toggle", methods=["POST"])
@role_required("admin")
def admin_toggle_user(target_user_id):
    with db_cursor(commit=True) as cursor:
        target, message = _toggle_user(cursor, target_user_id)
    flash(message, "success" if target else "danger")
    return redirect(request.referrer if (request.referrer or "").startswith(request.host_url) else url_for("admin_users"))


@app.route("/admin/users/<int:target_user_id>/role", methods=["POST"])
@role_required("admin")
def admin_change_role(target_user_id):
    new_role = request.form.get("role")
    with db_cursor(commit=True) as cursor:
        cursor.execute("SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON r.id = u.role_id WHERE u.id = %s FOR UPDATE",
                       (target_user_id,))
        target = cursor.fetchone()
        if target is None:
            abort(404)
        error = None
        if target_user_id == session["user_id"]:
            error = "You cannot change your own role."
        elif new_role not in ("user", "admin") or target["role_name"] == "provider":
            error = "Only Client and Administrator roles can be switched here. Staff accounts are managed on the Staff page."
        elif target["role_name"] == new_role:
            error = "The account already has that role."
        if error:
            flash(error, "danger")
            return redirect(url_for("admin_users"))
        cursor.execute("UPDATE users SET role_id = (SELECT id FROM roles WHERE name = %s) WHERE id = %s", (new_role, target_user_id))
        write_audit(cursor, session["user_id"], "Changed role", "user", target_user_id,
                    old_value={"role": target["role_name"]}, new_value={"role": new_role}, details=target["email"])
    flash(f"{target['name']} is now {'an Administrator' if new_role == 'admin' else 'a Client'}.", "success")
    return redirect(url_for("admin_users"))


@app.route("/admin/users/<int:target_user_id>/reset-link", methods=["POST"])
@role_required("admin")
def admin_reset_link(target_user_id):
    with db_cursor(commit=True) as cursor:
        cursor.execute("SELECT id, name, email FROM users WHERE id = %s AND is_active = 1", (target_user_id,))
        target = cursor.fetchone()
        if target is None:
            abort(404)
        token = create_reset_token(cursor, target_user_id, session["user_id"])
        write_audit(cursor, session["user_id"], "Generated password reset link", "user", target_user_id, details=target["email"])
    session["reset_link"] = {"name": target["name"], "email": target["email"],
                             "url": url_for("reset_password", token=token, _external=True)}
    flash(f"Password reset link created for {target['name']}. Copy it from the green box below.", "success")
    return redirect(url_for("admin_users"))


# ---------------------------------------------------------
# Schedules and blocked time (S32)
# ---------------------------------------------------------
@app.route("/admin/schedules", methods=["GET", "POST"])
@role_required("admin")
def admin_schedules():
    with db_cursor() as cursor:
        cursor.execute("""SELECT p.id, pu.name AS provider_name, p.is_active FROM providers p
                          JOIN users pu ON p.user_id = pu.id ORDER BY pu.name""")
        providers = cursor.fetchall()
    provider_id = request.values.get("provider_id", type=int) or (providers[0]["id"] if providers else None)
    if provider_id and provider_id not in {p["id"] for p in providers}:
        abort(404)
    if request.method == "POST" and provider_id:
        kind = request.form.get("kind")
        with db_cursor(commit=True) as cursor:
            before = affected_ids(cursor, provider_id)
            error = save_block(cursor, provider_id, request.form, session["user_id"]) if kind == "block" \
                else save_window(cursor, provider_id, request.form, session["user_id"], "admin")
            if not error:
                f = request.form
                report_schedule_effects(cursor, provider_id, before, session["user_id"], "admin",
                                        ("blocked " + block_text(*parse_block_form(f))) if kind == "block"
                                        else "added working hours " + window_text(f["day_of_week"], f["start_time"], f["end_time"]))
        flash(error or ("Blocked period added." if kind == "block" else "Availability window added."),
              "danger" if error else "success")
        return redirect(url_for("admin_schedules", provider_id=provider_id))
    windows, blocks, needs_attention = [], [], []
    with db_cursor() as cursor:
        if provider_id:
            windows = day_windows(cursor, provider_id)
            cursor.execute("""SELECT b.*, u.name AS created_by_name FROM blocked_periods b LEFT JOIN users u ON u.id = b.created_by
                              WHERE b.provider_id = %s AND b.end_datetime >= %s ORDER BY b.start_datetime""",
                           (provider_id, current_time() - timedelta(days=30)))
            blocks = cursor.fetchall()
            needs_attention = appointments_outside_availability(cursor, provider_id, current_time().date())
        cursor.execute("""SELECT provider_id, day_of_week, COUNT(*) AS n FROM provider_schedules WHERE is_available = 1
                          GROUP BY provider_id, day_of_week""")
        coverage = {}
        for row in cursor.fetchall():
            coverage.setdefault(row["provider_id"], set()).add(int(row["day_of_week"]))
    return render_template("admin/schedules.html", providers=providers, provider_id=provider_id, schedules=windows,
                           blocks=blocks, needs_attention=needs_attention, coverage=coverage, active_page="schedules")


@app.route("/admin/schedules/add", methods=["POST"])
@role_required("admin")
def admin_add_schedule():
    return admin_schedules()


@app.route("/admin/schedules/<int:schedule_id>/toggle", methods=["POST"])
@role_required("admin")
def admin_toggle_schedule(schedule_id):
    provider_id = toggle_window(schedule_id, None, "admin")
    return redirect(url_for("admin_schedules", provider_id=provider_id))


@app.route("/admin/schedules/<int:schedule_id>/delete", methods=["POST"])
@role_required("admin")
def admin_delete_schedule(schedule_id):
    provider_id = delete_window(schedule_id, None, "admin")
    return redirect(url_for("admin_schedules", provider_id=provider_id))


@app.route("/admin/blocked-periods/<int:period_id>/delete", methods=["POST"])
@role_required("admin")
def admin_delete_blocked_period(period_id):
    provider_id = delete_block(period_id, None)
    return redirect(url_for("admin_schedules", provider_id=provider_id))


# ---------------------------------------------------------
# Services (S31)
# ---------------------------------------------------------
@app.route("/admin/services", methods=["GET", "POST"])
@role_required("admin")
def admin_services():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        description = request.form.get("description", "").strip()[:255]
        service_id = request.form.get("service_id", type=int)
        risk_category = (request.form.get("risk_category") or "").strip() or None
        try:
            duration = int(request.form.get("duration", ""))
        except ValueError:
            duration = 0
        error = None
        if not name or len(name) > 100:
            error = "Enter a service name (up to 100 characters)."
        elif not 5 <= duration <= 480:
            error = "Duration must be between 5 and 480 minutes."
        elif risk_category and risk_category not in noshow_risk.categories():
            error = "Choose a no-show category from the list (or 'Not set')."
        with db_cursor(commit=True) as cursor:
            if not error:
                cursor.execute("SELECT id FROM services WHERE LOWER(name) = LOWER(%s) AND is_active = 1 AND id <> %s",
                               (name, service_id or 0))
                if cursor.fetchone():
                    error = "An active service with this name already exists."
            if not error:
                if service_id:
                    cursor.execute("SELECT * FROM services WHERE id = %s", (service_id,))
                    old = cursor.fetchone()
                    if old is None:
                        abort(404)
                    cursor.execute("UPDATE services SET name = %s, description = %s, duration = %s, risk_category = %s WHERE id = %s",
                                   (name, description or None, duration, risk_category, service_id))
                    write_audit(cursor, session["user_id"], "Updated service", "service", service_id,
                                old_value={"name": old["name"], "duration": old["duration"], "description": old["description"],
                                           "risk_category": old["risk_category"]},
                                new_value={"name": name, "duration": duration, "description": description,
                                           "risk_category": risk_category})
                    if old["duration"] != duration:
                        flash("Duration changes apply to new bookings; existing appointments keep their times.", "info")
                else:
                    cursor.execute("INSERT INTO services (name, description, duration, risk_category) VALUES (%s, %s, %s, %s)",
                                   (name, description or None, duration, risk_category))
                    write_audit(cursor, session["user_id"], "Created service", "service", cursor.lastrowid,
                                new_value={"name": name, "duration": duration, "risk_category": risk_category})
        flash(error or "Service saved. Assign staff to it from the Staff page.", "danger" if error else "success")
        return redirect(url_for("admin_services"))
    with db_cursor() as cursor:
        cursor.execute(
            """SELECT s.*, (SELECT COUNT(*) FROM appointments WHERE service_id = s.id) AS total_appointments,
                      (SELECT COUNT(*) FROM appointments WHERE service_id = s.id AND status IN ('pending','confirmed')
                         AND appointment_date >= %s) AS upcoming
               FROM services s ORDER BY s.is_active DESC, s.name""", (current_time().date(),))
        services = cursor.fetchall()
        cursor.execute("""SELECT ps.service_id, pu.name FROM provider_services ps JOIN providers p ON p.id = ps.provider_id
                          JOIN users pu ON pu.id = p.user_id WHERE p.is_active = 1 ORDER BY pu.name""")
        staff = {}
        for row in cursor.fetchall():
            staff.setdefault(row["service_id"], []).append(row["name"])
    edit_id = request.args.get("edit", type=int)
    return render_template("admin/services.html", services=services, staff_by_service=staff, edit_id=edit_id,
                           risk_categories=noshow_risk.categories(), active_page="services")


@app.route("/admin/services/<int:service_id>/toggle", methods=["POST"])
@role_required("admin")
def admin_toggle_service(service_id):
    with db_cursor(commit=True) as cursor:
        cursor.execute("SELECT * FROM services WHERE id = %s FOR UPDATE", (service_id,))
        service = cursor.fetchone()
        if service is None:
            abort(404)
        new_value = 0 if service["is_active"] else 1
        if new_value:
            cursor.execute("SELECT id FROM services WHERE LOWER(name) = LOWER(%s) AND is_active = 1 AND id <> %s",
                           (service["name"], service_id))
            if cursor.fetchone():
                flash("Another active service already uses this name. Rename one of them first.", "danger")
                return redirect(url_for("admin_services"))
        cursor.execute("UPDATE services SET is_active = %s WHERE id = %s", (new_value, service_id))
        write_audit(cursor, session["user_id"], "Activated service" if new_value else "Deactivated service", "service",
                    service_id, old_value={"is_active": service["is_active"]}, new_value={"is_active": new_value})
        cursor.execute("""SELECT COUNT(*) AS n FROM appointments WHERE service_id = %s AND status IN ('pending','confirmed')
                          AND appointment_date >= %s""", (service_id, current_time().date()))
        open_count = cursor.fetchone()["n"]
    message = f"{service['name']} {'activated' if new_value else 'deactivated - it can no longer be booked'}."
    if not new_value and open_count:
        message += f" {open_count} existing upcoming appointment(s) were kept."
    flash(message, "success")
    return redirect(url_for("admin_services"))


# ---------------------------------------------------------
# System settings (S39)
# ---------------------------------------------------------
@app.route("/admin/settings", methods=["GET", "POST"])
@role_required("admin")
def admin_settings():
    if request.method == "POST":
        clean, errors = parse_settings_form(request.form)
        if errors:
            for message in errors:
                flash(message, "danger")
        else:
            with db_cursor(commit=True) as cursor:
                changes = save_settings(cursor, clean, session["user_id"])
                if changes:
                    write_audit(cursor, session["user_id"], "Changed settings", "system_settings", None,
                                old_value={k: v[0] for k, v in changes.items()}, new_value={k: v[1] for k, v in changes.items()})
            flash("Settings saved." if changes else "No changes to save.", "success")
            return redirect(url_for("admin_settings"))
    with db_cursor() as cursor:
        settings = get_settings(cursor)
    return render_template("admin/settings.html", settings=settings, groups=grouped_rules(), active_page="settings")
