# =========================================================
# ROUTES_STAFF.PY  - Staff / provider screens (S20-S27)
# =========================================================

from datetime import datetime, timedelta

from flask import abort, flash, redirect, render_template, request, session, url_for

from agende import analytics
from agende import forecasting
from agende import noshow_risk
from agende.appointments import available_actions
from agende.audit import write_audit
from agende.database import db_cursor
from agende.notifications import describe, notify, notify_admins
from agende.scheduling import (ALL_STATUSES, appointments_outside_availability, find_overlapping_pairs, to_date, to_time,
                        windows_overlap_existing)
from agende.security import role_required
from agende.settings_store import get_settings
from agende.web import (DAY_NAMES, app, current_time, format_time12, smart_order, month_bounds, paginate, provider_id_or_403, selected_month)

STAFF_LIST_SELECT = """SELECT a.*, s.name AS service_name, s.duration, u.name AS client_name
                       FROM appointments a
                       JOIN services s ON a.service_id = s.id
                       JOIN users u ON a.user_id = u.id"""


# ---------------------------------------------------------
# Schedule-change helper shared with the admin screens
# ---------------------------------------------------------
def affected_ids(cursor, provider_id):
    return {row["id"] for row in appointments_outside_availability(cursor, provider_id, current_time().date())}


def report_schedule_effects(cursor, provider_id, before, actor_id, actor_role, change="Schedule updated"):
    """After ANY hours/blocked-time change (nothing is ever cancelled automatically):
      - clients whose upcoming appointments newly fall outside availability get N011;
      - the staff member is told when someone else (an admin) changed their schedule;
      - every other administrator is told what changed and how many bookings it affects;
      - whoever made the change sees a warning listing the effect."""
    affected = appointments_outside_availability(cursor, provider_id, current_time().date())
    newly = [row for row in affected if row["id"] not in before]
    cursor.execute("SELECT p.user_id, u.name FROM providers p JOIN users u ON u.id = p.user_id WHERE p.id = %s",
                   (provider_id,))
    staff = cursor.fetchone()
    cursor.execute("SELECT name FROM users WHERE id = %s", (actor_id,))
    actor_row = cursor.fetchone()
    actor_name = actor_row["name"] if actor_row else "Someone"
    effect = (f" {len(newly)} upcoming appointment(s) now fall outside the available hours and need follow-up."
              if newly else " No booked appointments are affected.")

    for row in newly:
        notify(cursor, row["user_id"], "Schedule change",
               f"{staff['name']}'s availability changed and may affect your {describe(row)}. "
               "The staff will contact you, or you may reschedule.", "warning", "N011", row["id"])
    if actor_id != staff["user_id"]:
        notify(cursor, staff["user_id"], "Your schedule was changed",
               f"{actor_name} changed your schedule: {change}.{effect}", "warning" if newly else "info", "N011")
    notify_admins(cursor, f"Schedule {'change affects bookings' if newly else 'updated'}",
                  f"{staff['name']}'s schedule was changed by {actor_name}: {change}.{effect}",
                  "warning" if newly else "info", "N011", exclude_user_id=actor_id)
    if newly:
        flash(f"This change affects {len(newly)} upcoming appointment(s). They were kept, the clients and "
              "administrators were notified, and they are listed under 'Needs attention'.", "warning")
    return affected


def window_text(day_of_week, start, end):
    return f"{DAY_NAMES[int(day_of_week)]} {format_time12(start)}–{format_time12(end)}"


def block_text(start, end):
    return f"{start.strftime('%m/%d/%Y %I:%M %p')} to {end.strftime('%m/%d/%Y %I:%M %p')}"


def day_windows(cursor, provider_id):
    cursor.execute("SELECT * FROM provider_schedules WHERE provider_id = %s ORDER BY day_of_week, start_time", (provider_id,))
    return cursor.fetchall()


# ---------------------------------------------------------
# Dashboard (S20)
# ---------------------------------------------------------
@app.route("/provider/dashboard")
@role_required("provider")
def provider_dashboard():
    provider_id = provider_id_or_403()
    now = current_time()
    today = now.date()
    week_start = today - timedelta(days=today.weekday())
    with db_cursor() as cursor:
        settings = get_settings(cursor)
        cursor.execute(
            """SELECT
                 SUM(appointment_date = %s AND status IN ('pending','confirmed','completed','no_show')) AS today_count,
                 SUM(status = 'pending' AND appointment_date >= %s) AS pending,
                 SUM(status = 'confirmed' AND appointment_date >= %s) AS confirmed,
                 SUM(status = 'no_show' AND appointment_date >= %s) AS no_show_30,
                 SUM(status = 'cancelled' AND appointment_date >= %s) AS cancelled_30
               FROM appointments WHERE provider_id = %s""",
            (today, today, today, today - timedelta(days=30), today - timedelta(days=30), provider_id))
        counts = cursor.fetchone()
        cursor.execute(STAFF_LIST_SELECT + """ WHERE a.provider_id = %s AND a.appointment_date = %s
                       AND a.status IN ('pending','confirmed','completed','no_show') ORDER BY a.start_time""",
                       (provider_id, today))
        agenda = cursor.fetchall()
        cursor.execute(STAFF_LIST_SELECT + """ WHERE a.provider_id = %s AND a.status = 'pending' AND a.appointment_date >= %s
                       ORDER BY a.appointment_date, a.start_time LIMIT 6""", (provider_id, today))
        requests_ = cursor.fetchall()
        cursor.execute(STAFF_LIST_SELECT + """ WHERE a.provider_id = %s AND a.status = 'confirmed' AND a.appointment_date > %s
                       ORDER BY a.appointment_date, a.start_time LIMIT 5""", (provider_id, today))
        upcoming = cursor.fetchall()
        cursor.execute(STAFF_LIST_SELECT + """ WHERE a.provider_id = %s AND a.status = 'cancelled'
                       ORDER BY a.updated_at DESC LIMIT 5""", (provider_id,))
        cancellations = cursor.fetchall()
        windows = day_windows(cursor, provider_id)
        cursor.execute("""SELECT * FROM blocked_periods WHERE provider_id = %s AND end_datetime >= %s
                          ORDER BY start_datetime LIMIT 5""", (provider_id, now))
        blocks = cursor.fetchall()
        conflicts = find_overlapping_pairs(cursor, today, today + timedelta(days=90), provider_id)
        needs_attention = appointments_outside_availability(cursor, provider_id, today)
        week = analytics.daily_counts(cursor, week_start, week_start + timedelta(days=6), provider_id=provider_id)
        alerts = analytics.unusual_activity(cursor, today, provider_id)
        # Advisory no-show risk on the provider's own upcoming appointments (next 7 days)
        noshow_risk.annotate(cursor, agenda + requests_ + upcoming, settings, now)
        cursor.execute(STAFF_LIST_SELECT + """ WHERE a.provider_id = %s AND a.status IN ('pending','confirmed')
                       AND a.appointment_date BETWEEN %s AND %s ORDER BY a.appointment_date, a.start_time""",
                       (provider_id, today, today + timedelta(days=6)))
        next7 = noshow_risk.annotate(cursor, cursor.fetchall(), settings, now)
        my_forecast = forecasting.scoped_forecast(cursor, settings, today, provider_id=provider_id)
    risk_week = {"counts": noshow_risk.summary(next7), "enabled": bool(settings["noshow_risk_enabled"] and noshow_risk.model()),
                 "top": sorted([a for a in next7 if a.get("risk") and a["risk"]["tier"] != "low"],
                               key=lambda a: -a["risk"]["p"])[:5]}
    for item in agenda + requests_:
        item["actions"] = available_actions(item, "provider", settings, now)
    week_days = [week_start + timedelta(days=i) for i in range(7)]
    week_chart = {
        "labels": [d.strftime("%a %d") for d in week_days],
        "confirmed": [week[d]["confirmed"] + week[d]["pending"] for d in week_days],
        "completed": [week[d]["completed"] for d in week_days],
        "no_show": [week[d]["no_show"] for d in week_days],
    }
    return render_template(
        "provider/dashboard.html", active_page="dashboard", counts={k: int(v or 0) for k, v in counts.items()},
        agenda=agenda, requests=requests_, upcoming=upcoming, cancellations=cancellations, windows=windows,
        blocks=blocks, conflicts=conflicts, needs_attention=needs_attention, week_chart=week_chart, alerts=alerts,
        risk_week=risk_week, my_forecast=my_forecast)


# ---------------------------------------------------------
# Appointment lists: requests (S21), assigned appointments, history (S26)
# ---------------------------------------------------------
VIEWS = {
    "requests": (("pending",), "Appointment Requests", "Pending requests waiting for your decision."),
    "upcoming": (("pending", "confirmed"), "My Appointments", "Active appointments assigned to you."),
    "history": (("completed", "cancelled", "rejected", "no_show", "expired"), "Appointment History",
                "Past appointments assigned to you."),
    "all": (ALL_STATUSES, "All My Appointments", "Every appointment assigned to you."),
}
STAFF_SORTS = {"smart": None,     # upcoming soonest -> farthest, then past (web.smart_order)
               "id": "a.id ASC",
               "time": "a.appointment_date ASC, a.start_time ASC, a.id ASC",
               "time_desc": "a.appointment_date DESC, a.start_time DESC, a.id DESC",
               "requested": "a.created_at ASC, a.id ASC"}


@app.route("/provider/appointments")
@role_required("provider")
def provider_appointments():
    provider_id = provider_id_or_403()
    view = request.args.get("view", "upcoming")
    view = view if view in VIEWS else "upcoming"
    statuses, title, subtitle = VIEWS[view]
    args = request.args
    query = STAFF_LIST_SELECT + " WHERE a.provider_id = %s"
    params = [provider_id]
    status = args.get("status", "")
    if status in statuses:
        query += " AND a.status = %s"
        params.append(status)
    else:
        status = ""
        query += " AND a.status IN (" + ",".join(["%s"] * len(statuses)) + ")"
        params.extend(statuses)
    if view in ("requests", "upcoming") and not args.get("date_from"):
        query += " AND a.appointment_date >= %s"
        params.append(current_time().date())
    if to_date(args.get("date_from")):
        query += " AND a.appointment_date >= %s"
        params.append(to_date(args.get("date_from")))
    if to_date(args.get("date_to")):
        query += " AND a.appointment_date <= %s"
        params.append(to_date(args.get("date_to")))
    if args.get("service_id", "").isdigit():
        query += " AND a.service_id = %s"
        params.append(int(args["service_id"]))
    q = args.get("q", "").strip()
    if q:
        query += " AND (a.id = %s OR u.name LIKE %s)"
        params.extend([int(q.lstrip("#")) if q.lstrip("#").isdigit() else -1, f"%{q}%"])
    default_sort = "time_desc" if view == "history" else "smart"
    sort = args.get("sort", default_sort)
    sort = sort if sort in STAFF_SORTS else default_sort
    order_sql, order_params = smart_order() if sort == "smart" else (STAFF_SORTS[sort], [])
    with db_cursor() as cursor:
        cursor.execute("SELECT COUNT(*) AS n FROM (" + query + ") AS x", params)
        pager = paginate(cursor.fetchone()["n"])
        cursor.execute(query + f" ORDER BY {order_sql} LIMIT %s OFFSET %s",
                       params + order_params + [pager["per_page"], pager["offset"]])
        rows = cursor.fetchall()
        cursor.execute("""SELECT s.id, s.name FROM services s JOIN provider_services ps ON ps.service_id = s.id
                          WHERE ps.provider_id = %s ORDER BY s.name""", (provider_id,))
        services = cursor.fetchall()
        settings = get_settings(cursor)
        now = current_time()
        noshow_risk.annotate(cursor, rows, settings, now)
    for row in rows:
        row["actions"] = available_actions(row, "provider", settings, now)
    return render_template("provider/appointments.html", appointments=rows, pager=pager, services=services, view=view,
                           statuses=statuses, status_filter=status, sort=sort, title=title, subtitle=subtitle,
                           active_page="requests" if view == "requests" else ("history" if view == "history" else "appointments"))


@app.route("/provider/calendar")
@role_required("provider")
def provider_calendar():
    provider_id = provider_id_or_403()
    month = selected_month()
    first, last = month_bounds(month)
    with db_cursor() as cursor:
        cursor.execute(
            """SELECT a.*, s.name AS service_name, s.description AS service_description, u.name AS client_name
               FROM appointments a JOIN services s ON a.service_id = s.id JOIN users u ON a.user_id = u.id
               WHERE a.provider_id = %s AND a.status NOT IN ('cancelled','rejected','expired')
                 AND a.appointment_date BETWEEN %s AND %s ORDER BY a.appointment_date, a.start_time""",
            (provider_id, first, last))
        appointments = cursor.fetchall()
    return render_template("calendar.html", appointments=appointments, timeline_month=month.strftime("%Y-%m"),
                           person_field="client_name", active_page="calendar",
                           title="My Calendar", subtitle="Your client appointments on a scrollable month timeline.")


# ---------------------------------------------------------
# Availability (S24) and blocked time (S25)
# ---------------------------------------------------------
def save_window(cursor, provider_id, form, actor_id, actor_role):
    """Validate and insert one weekly window. Returns an error message or None."""
    try:
        day_of_week = int(form.get("day_of_week", -1))
    except ValueError:
        day_of_week = -1
    start, end = to_time(form.get("start_time")), to_time(form.get("end_time"))
    if not 0 <= day_of_week <= 6:
        return "Choose a valid day."
    if start is None or end is None or start >= end:
        return "Start time must be earlier than end time."
    if windows_overlap_existing(cursor, provider_id, day_of_week, start, end):
        return f"That window overlaps an existing {DAY_NAMES[day_of_week]} window. Edit or remove the existing one first."
    cursor.execute("INSERT INTO provider_schedules (provider_id, day_of_week, start_time, end_time, is_available) VALUES (%s,%s,%s,%s,1)",
                   (provider_id, day_of_week, start, end))
    write_audit(cursor, actor_id, "Added availability", "provider_schedule", cursor.lastrowid,
                new_value={"provider_id": provider_id, "day": DAY_NAMES[day_of_week], "start": start, "end": end})
    return None


def parse_block_form(form):
    """(start, end) datetimes from the block-time form; raises ValueError if invalid."""
    return (datetime.strptime(form.get("start_datetime", ""), "%Y-%m-%dT%H:%M"),
            datetime.strptime(form.get("end_datetime", ""), "%Y-%m-%dT%H:%M"))


def save_block(cursor, provider_id, form, actor_id):
    try:
        start, end = parse_block_form(form)
    except ValueError:
        return "Enter a valid start and end date/time."
    if end <= start:
        return "The end must be after the start."
    if end <= current_time():
        return "The blocked period must end in the future."
    reason = form.get("reason", "").strip()[:255]
    cursor.execute("INSERT INTO blocked_periods (provider_id, start_datetime, end_datetime, reason, created_by) VALUES (%s,%s,%s,%s,%s)",
                   (provider_id, start, end, reason or None, actor_id))
    write_audit(cursor, actor_id, "Blocked time", "blocked_period", cursor.lastrowid,
                new_value={"provider_id": provider_id, "start": start, "end": end}, details=reason or None)
    return None


@app.route("/provider/schedule", methods=["GET", "POST"])
@role_required("provider")
def provider_schedule():
    provider_id = provider_id_or_403()
    if request.method == "POST":
        with db_cursor(commit=True) as cursor:
            before = affected_ids(cursor, provider_id)
            error = save_window(cursor, provider_id, request.form, session["user_id"], "provider")
            if not error:
                f = request.form
                report_schedule_effects(cursor, provider_id, before, session["user_id"], "provider",
                                        "added working hours " + window_text(f["day_of_week"], f["start_time"], f["end_time"]))
        flash(error or "Availability window added.", "danger" if error else "success")
        return redirect(url_for("provider_schedule"))
    with db_cursor() as cursor:
        windows = day_windows(cursor, provider_id)
        needs_attention = appointments_outside_availability(cursor, provider_id, current_time().date())
    return render_template("provider/schedule.html", schedules=windows, needs_attention=needs_attention,
                           active_page="schedule")


def _own_window(cursor, schedule_id, provider_id):
    cursor.execute("SELECT * FROM provider_schedules WHERE id = %s FOR UPDATE", (schedule_id,))
    row = cursor.fetchone()
    if row is None or (provider_id is not None and row["provider_id"] != provider_id):
        abort(403 if row else 404)
    return row


def toggle_window(schedule_id, provider_id, actor_role):
    with db_cursor(commit=True) as cursor:
        row = _own_window(cursor, schedule_id, provider_id)
        before = affected_ids(cursor, row["provider_id"])
        new_value = 0 if row["is_available"] else 1
        if new_value and windows_overlap_existing(cursor, row["provider_id"], row["day_of_week"],
                                                  to_time(row["start_time"]), to_time(row["end_time"]), schedule_id):
            flash("Cannot re-enable: it overlaps another window on the same day.", "danger")
            return row["provider_id"]
        cursor.execute("UPDATE provider_schedules SET is_available = %s WHERE id = %s", (new_value, schedule_id))
        write_audit(cursor, session["user_id"], "Enabled availability" if new_value else "Disabled availability",
                    "provider_schedule", schedule_id, old_value={"is_available": row["is_available"]},
                    new_value={"is_available": new_value})
        report_schedule_effects(cursor, row["provider_id"], before, session["user_id"], actor_role,
                                ("enabled " if new_value else "disabled ") + window_text(row["day_of_week"], row["start_time"], row["end_time"]))
    flash("Availability updated.", "success")
    return row["provider_id"]


def delete_window(schedule_id, provider_id, actor_role):
    with db_cursor(commit=True) as cursor:
        row = _own_window(cursor, schedule_id, provider_id)
        before = affected_ids(cursor, row["provider_id"])
        cursor.execute("DELETE FROM provider_schedules WHERE id = %s", (schedule_id,))
        write_audit(cursor, session["user_id"], "Removed availability", "provider_schedule", schedule_id,
                    old_value={"day": DAY_NAMES[row["day_of_week"]], "start": row["start_time"], "end": row["end_time"]})
        report_schedule_effects(cursor, row["provider_id"], before, session["user_id"], actor_role,
                                "removed working hours " + window_text(row["day_of_week"], row["start_time"], row["end_time"]))
    flash("Availability window removed.", "success")
    return row["provider_id"]


@app.route("/provider/schedule/<int:schedule_id>/toggle", methods=["POST"])
@role_required("provider")
def provider_toggle_schedule(schedule_id):
    toggle_window(schedule_id, provider_id_or_403(), "provider")
    return redirect(url_for("provider_schedule"))


@app.route("/provider/schedule/<int:schedule_id>/delete", methods=["POST"])
@role_required("provider")
def provider_delete_schedule(schedule_id):
    delete_window(schedule_id, provider_id_or_403(), "provider")
    return redirect(url_for("provider_schedule"))


@app.route("/provider/blocked-periods", methods=["GET", "POST"])
@role_required("provider")
def provider_blocked_periods():
    provider_id = provider_id_or_403()
    if request.method == "POST":
        with db_cursor(commit=True) as cursor:
            before = affected_ids(cursor, provider_id)
            error = save_block(cursor, provider_id, request.form, session["user_id"])
            if not error:
                report_schedule_effects(cursor, provider_id, before, session["user_id"], "provider",
                                        "blocked " + block_text(*parse_block_form(request.form)))
        flash(error or "Unavailable period added.", "danger" if error else "success")
        return redirect(url_for("provider_blocked_periods"))
    with db_cursor() as cursor:
        cursor.execute("SELECT * FROM blocked_periods WHERE provider_id = %s ORDER BY start_datetime DESC", (provider_id,))
        periods = cursor.fetchall()
        needs_attention = appointments_outside_availability(cursor, provider_id, current_time().date())
    return render_template("provider/blocked_periods.html", periods=periods, needs_attention=needs_attention,
                           active_page="blocks")


def delete_block(period_id, provider_id):
    with db_cursor(commit=True) as cursor:
        cursor.execute("SELECT * FROM blocked_periods WHERE id = %s", (period_id,))
        row = cursor.fetchone()
        if row is None or (provider_id is not None and row["provider_id"] != provider_id):
            abort(403 if row else 404)
        before = affected_ids(cursor, row["provider_id"])
        cursor.execute("DELETE FROM blocked_periods WHERE id = %s", (period_id,))
        write_audit(cursor, session["user_id"], "Removed blocked time", "blocked_period", period_id,
                    old_value={"start": row["start_datetime"], "end": row["end_datetime"], "reason": row["reason"]})
        report_schedule_effects(cursor, row["provider_id"], before, session["user_id"], session.get("role"),
                                "removed blocked time " + block_text(row["start_datetime"], row["end_datetime"]))
    flash("Unavailable period removed.", "success")
    return row["provider_id"]


@app.route("/provider/blocked-periods/<int:period_id>/delete", methods=["POST"])
@role_required("provider")
def provider_delete_blocked_period(period_id):
    delete_block(period_id, provider_id_or_403())
    return redirect(url_for("provider_blocked_periods"))


# ---------------------------------------------------------
# Staff analytics (S27) - only this staff member's own records
# ---------------------------------------------------------
@app.route("/provider/analytics")
@role_required("provider")
def provider_analytics():
    provider_id = provider_id_or_403()
    with db_cursor() as cursor:
        filters, errors = analytics.parse_filters(request.args, current_time().date(), cursor, provider_scope=provider_id)
        data = analytics.compute(cursor, filters)
        cursor.execute("""SELECT s.id, s.name FROM services s JOIN provider_services ps ON ps.service_id = s.id
                          WHERE ps.provider_id = %s ORDER BY s.name""", (provider_id,))
        services = cursor.fetchall()
    for message in errors:
        flash(message, "warning")
    return render_template("analytics.html", data=data, services=services, providers=None, scope="staff",
                           active_page="analytics")


__all__ = ["save_window", "save_block", "toggle_window", "delete_window", "delete_block",
           "report_schedule_effects", "affected_ids", "paginate"]
