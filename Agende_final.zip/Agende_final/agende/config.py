# =========================================================
# CONFIG.PY - AGENDÉ settings
#
# EDIT THE MYSQL SETTINGS BELOW to match your XAMPP / MySQL.
# XAMPP's default login is user "root" with an empty password.
# (Any value can also be given as an environment variable, e.g. AGENDE_DB_PASSWORD.)
# =========================================================
import os
import secrets

# ---------------------------------------------------------
# MySQL database  <-- edit these
# ---------------------------------------------------------
DB_HOST = os.environ.get("AGENDE_DB_HOST", "localhost")
DB_PORT = int(os.environ.get("AGENDE_DB_PORT", "3306"))
DB_USER = os.environ.get("AGENDE_DB_USER", "root")
DB_PASSWORD = os.environ.get("AGENDE_DB_PASSWORD", "")
DB_NAME = os.environ.get("AGENDE_DB_NAME", "agende_db")

# ---------------------------------------------------------
# Web server (python app.py)
# ---------------------------------------------------------
HOST = os.environ.get("AGENDE_HOST", "127.0.0.1")     # "0.0.0.0" (or: python app.py --lan) = other devices too
PORT = int(os.environ.get("AGENDE_PORT", "5000"))
THREADS = int(os.environ.get("AGENDE_THREADS", "8"))

# Show the sample test accounts on the login page (set to "0" for real users)
SHOW_TEST_ACCOUNTS = os.environ.get("AGENDE_SHOW_TEST_ACCOUNTS", "1") == "1"

# Sessions
SESSION_LIFETIME_MINUTES = int(os.environ.get("AGENDE_SESSION_MINUTES", "120"))
SESSION_COOKIE_SECURE = os.environ.get("AGENDE_COOKIE_SECURE", "0") == "1"   # "1" only when served over HTTPS

# ---------------------------------------------------------
# Optional email (blueprint F065). Leave MAIL_SERVER empty for in-app notifications only.
# ---------------------------------------------------------
MAIL_SERVER = os.environ.get("AGENDE_MAIL_SERVER", "")
MAIL_PORT = int(os.environ.get("AGENDE_MAIL_PORT", "587"))
MAIL_USERNAME = os.environ.get("AGENDE_MAIL_USERNAME", "")
MAIL_PASSWORD = os.environ.get("AGENDE_MAIL_PASSWORD", "")
MAIL_USE_TLS = os.environ.get("AGENDE_MAIL_USE_TLS", "1") == "1"
MAIL_SENDER = os.environ.get("AGENDE_MAIL_SENDER", "AGENDE <no-reply@agende.local>")
BASE_URL = os.environ.get("AGENDE_BASE_URL", f"http://127.0.0.1:{PORT}")   # used in password-reset emails

# ---------------------------------------------------------
# No need to edit below this line
# ---------------------------------------------------------
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INSTANCE_DIR = os.path.join(ROOT, "instance")


def _secret_key():
    """Signs the login cookie: AGENDE_SECRET_KEY, or a random key created once in instance/secret_key."""
    key = os.environ.get("AGENDE_SECRET_KEY", "")
    if key:
        return key
    path = os.path.join(INSTANCE_DIR, "secret_key")
    try:
        with open(path, encoding="utf-8") as handle:
            key = handle.read().strip()
        if key:
            return key
    except OSError:
        pass
    key = secrets.token_hex(32)
    try:
        os.makedirs(INSTANCE_DIR, exist_ok=True)
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(key)
    except OSError:
        pass
    return key


SECRET_KEY = _secret_key()
