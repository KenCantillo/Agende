# =========================================================
# MIGRATIONS.PY
# Create the database from database/schema.sql (+ seed.sql), check that an
# existing one has the current structure, and write backups - all without
# the MySQL command line. Used by the tests, by
# app.py and `flask --app app backup-db`.
# =========================================================
import os
import re

import pymysql

from agende import config
from agende.db_diagnostics import REQUIRED

ROOT = config.ROOT
SCHEMA = os.path.join(ROOT, "database", "schema.sql")
SEED = os.path.join(ROOT, "database", "seed.sql")


def statements(path, db_name=None):
    """SQL statements of a file, without comments and without CREATE DATABASE / USE lines
    (the caller chooses the database), with agende_db renamed to db_name."""
    with open(path, encoding="utf-8") as handle:
        text = handle.read()
    text = re.sub(r"--[^\n]*", "", text)
    for part in text.split(";"):
        part = part.strip()
        if not part or re.match(r"(?is)^(CREATE\s+DATABASE|USE)\b", part):
            continue
        yield part.replace("agende_db", db_name) if db_name else part


def server_connection():
    """Connection to the MySQL server (no database selected)."""
    return pymysql.connect(host=config.DB_HOST, port=config.DB_PORT, user=config.DB_USER,
                           password=config.DB_PASSWORD, autocommit=True, charset="utf8mb4")


def database_exists(cursor, name=None):
    cursor.execute("SHOW DATABASES LIKE %s", (name or config.DB_NAME,))
    return cursor.fetchone() is not None


def table_columns(cursor):
    cursor.execute("""SELECT TABLE_NAME, COLUMN_NAME FROM information_schema.COLUMNS
                      WHERE TABLE_SCHEMA = DATABASE()""")
    columns = {}
    for table, column in cursor.fetchall():
        columns.setdefault(str(table).lower(), set()).add(str(column).lower())
    return columns


def missing_parts(cursor):
    """Tables/columns of the current structure that this database lacks ([] = up to date).
    Returns None for an empty database (no tables yet)."""
    cols = table_columns(cursor)
    if "users" not in cols:
        return None
    missing = []
    for table, needed in REQUIRED.items():
        if table not in cols:
            missing.append(f"table {table}")
        else:
            missing += [f"{table}.{c}" for c in needed if c not in cols[table]]
    return missing


def drop_database(cursor):
    cursor.execute(f"DROP DATABASE IF EXISTS `{config.DB_NAME}`")


def create_database(cursor, seed=True, log=print):
    """CREATE DATABASE + schema.sql (+ seed.sql)."""
    cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{config.DB_NAME}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")
    cursor.execute(f"USE `{config.DB_NAME}`")
    for path in [SCHEMA] + ([SEED] if seed else []):
        count = 0
        for statement in statements(path, config.DB_NAME):
            cursor.execute(statement)
            count += 1
        log(f"  {os.path.basename(path)}: {count} statements")


def backup_database(cursor, path, log=print):
    """Plain SQL backup (structure + data) written with PyMySQL - no mysqldump needed.
    Restore with: mysql -u root -p agende_db < backup.sql   (or phpMyAdmin -> Import)."""
    cursor.execute(f"USE `{config.DB_NAME}`")
    cursor.execute("SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'")
    tables = [row[0] for row in cursor.fetchall()]
    conn = cursor.connection
    rows_total = 0
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as out:
        out.write(f"-- AGENDE backup of {config.DB_NAME}\nSET FOREIGN_KEY_CHECKS = 0;\n\n")
        for table in tables:
            cursor.execute(f"SHOW CREATE TABLE `{table}`")
            out.write(f"DROP TABLE IF EXISTS `{table}`;\n{cursor.fetchone()[1]};\n")
            cursor.execute(f"SELECT * FROM `{table}`")
            rows = cursor.fetchall()
            for start in range(0, len(rows), 500):
                chunk = rows[start:start + 500]
                values = ",\n".join("(" + ", ".join(conn.escape(v) for v in row) + ")" for row in chunk)
                out.write(f"INSERT INTO `{table}` VALUES\n{values};\n")
            rows_total += len(rows)
            out.write("\n")
        out.write("SET FOREIGN_KEY_CHECKS = 1;\n")
    log(f"  backup written: {path} ({len(tables)} tables, {rows_total} rows)")
    return path
