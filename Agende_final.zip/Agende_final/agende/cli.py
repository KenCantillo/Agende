# =========================================================
# CLI.PY - command-line tasks (run from the project folder)
#
#   python -m flask --app app housekeeping      reminders, expiry, forecast retraining, email
#   python -m flask --app app train-forecast    train + deploy the weekly forecast model
#   python -m flask --app app backup-db         write a SQL backup to backups/
#
# (On Windows PCs that block pip.exe / flask.exe, "python -m flask" always works.)
# =========================================================
import os
from datetime import datetime

import click

from agende.database import db_cursor
from agende.notifications import run_housekeeping
from agende.settings_store import get_settings
from agende.web import app


@app.cli.command("housekeeping")
def housekeeping_command():
    """Send due reminders, expire unanswered requests, retrain the forecast model if due, send queued emails."""
    summary = run_housekeeping(db_cursor, get_settings, force_retrain_check=True)
    print("Housekeeping finished:", ", ".join(f"{key}={value}" for key, value in summary.items()))


@app.cli.command("train-forecast")
@click.option("--source", type=click.Choice(["auto", "live", "imported", "combined"]), default="auto",
              help="Historical data to train on (auto = live records if enough weeks exist, else imported).")
@click.option("--csv", "csv_path", type=click.Path(exists=True, dir_okay=False),
              help="Import AGENDE_appointment_history.csv into historical_appointments first.")
@click.option("--replace", is_flag=True, help="With --csv: clear the previous import first.")
@click.option("--horizon", type=int, default=None, help="Weeks to forecast (default: the system setting).")
@click.option("--no-deploy", is_flag=True, help="Only print the evaluation; do not save or activate the model.")
@click.option("--export", "export_path", type=click.Path(dir_okay=False), help="Also write the deployed model to a JSON file.")
def train_forecast_command(source, csv_path, replace, horizon, no_deploy, export_path):
    """Train both weekly linear-regression models, evaluate them and deploy them."""
    import json
    from datetime import date
    from agende import forecasting
    with db_cursor(commit=True) as cursor:
        if csv_path:
            rows, skipped = forecasting.read_history_csv(csv_path)
            summary = forecasting.import_history(cursor, rows, replace=replace)
            print(f"Imported {len(rows)} rows ({skipped} skipped); historical_appointments now holds {summary['n']} rows "
                  f"({summary['first_day']} to {summary['last_day']}).")
        settings = get_settings(cursor)
        today = date.today()
        if source == "auto":
            live = forecasting.train_from_source(cursor, "live", today, settings["forecast_min_weeks"], 1)
            source = "live" if live["available"] else "imported"
        result = forecasting.train_from_source(cursor, source, today, settings["forecast_min_weeks"],
                                               horizon or settings["forecast_horizon_weeks"])
        print(f"Data: {result['source_label']} | complete weeks: {len(result['weeks'])} (minimum {settings['forecast_min_weeks']})")
        if not result["available"]:
            print("Not trained:", result["message"])
            raise SystemExit(1)
        print(f"Training period: {result['training_start']} to {result['training_end']} | records: {result['record_count']}")
        for key, label in (("appointment_model", "Appointments"), ("no_show_model", "Did not attend")):
            m = result[key]
            r2 = "N/A" if m["r2"] is None else f"{m['r2']:.4f}"
            print(f"  {label:15s} Y = {m['intercept']:.4f} + {m['slope']:.4f}*X | split {m['train_weeks']}/{m['test_weeks']} weeks | "
                  f"test MAE {m['mae']:.3f}  RMSE {m['rmse']:.3f}  R2 {r2} | baseline MAE {m['baseline_mae']:.3f}")
        for w in result["warnings"]:
            print("  Warning:", w)
        if no_deploy:
            print("Evaluation only (--no-deploy): nothing was saved.")
            return
        version, _ids = forecasting.deploy_models(cursor, result, None, "cli", settings["forecast_min_weeks"])
        from agende.audit import write_audit
        write_audit(cursor, None, "Trained and deployed forecast model", "forecast_model", _ids[0],
                    details=f"{version} from the command line ({source})")
        print(f"Deployed {version}: it is now the active model used by the dashboard and Forecast page.")
        if export_path:
            with open(export_path, "w", encoding="utf-8") as handle:
                json.dump(forecasting.export_model(forecasting.active_models(cursor)), handle, indent=2, default=str)
            print("Model file written to", export_path)


@app.cli.command("backup-db")
def backup_db_command():
    """Write a full SQL backup of the database to backups/."""
    from agende import migrations
    conn = migrations.server_connection()
    path = os.path.join(migrations.ROOT, "backups", f"agende_{datetime.now():%Y%m%d_%H%M%S}.sql")
    migrations.backup_database(conn.cursor(), path)

