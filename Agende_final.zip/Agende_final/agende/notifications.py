# =========================================================
# NOTIFICATIONS.PY
# In-app notifications (blueprint section 12, N001-N012),
# optional email, and "housekeeping" jobs that need a clock:
#   - N007 advance reminders and N008 same-day reminders
#   - expiring pending requests whose start time has passed
#   - sending queued emails (and retrying failures)
#   - retraining the forecast model when a new complete week of
#     live records exists (checked at most once an hour)
#
# There is no background scheduler in a student Flask app, so
# housekeeping runs (a) automatically at most once a minute when
# pages are opened, and (b) on demand with:
#       flask --app app housekeeping
# which can be put in Windows Task Scheduler / cron.
# =========================================================

import smtplib
import threading
from datetime import datetime, timedelta
from email.message import EmailMessage

from agende import config
from agende.scheduling import combine, status_label, to_date


def notify(cursor, user_id, title, message, notif_type="info", event_code=None, appointment_id=None):
    """Insert one in-app notification (email copy is queued automatically)."""
    cursor.execute(
        """INSERT INTO notifications (user_id, appointment_id, event_code, title, message, type, channel)
           VALUES (%s, %s, %s, %s, %s, %s, %s)""",
        (user_id, appointment_id, event_code, (title or "")[:120], message[:255], notif_type,
         "in_app+email" if email_enabled() else "in_app"),
    )


def notify_role(cursor, role_name, title, message, notif_type="info", event_code=None, appointment_id=None):
    """Send the same notification to every active account with a role
    ('user', 'provider', 'admin') or to everyone ('all')."""
    if role_name == "all":
        cursor.execute("SELECT id FROM users WHERE is_active = 1")
    else:
        cursor.execute(
            """SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id
               WHERE r.name = %s AND u.is_active = 1""", (role_name,))
    recipients = [row["id"] for row in cursor.fetchall()]
    for user_id in recipients:
        notify(cursor, user_id, title, message, notif_type, event_code, appointment_id)
    return len(recipients)


def notify_admins(cursor, title, message, notif_type="info", event_code=None, appointment_id=None, exclude_user_id=None):
    """Notify every active administrator (optionally not the one who made the change)."""
    cursor.execute(
        """SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id
           WHERE r.name = 'admin' AND u.is_active = 1 AND u.id <> %s""", (exclude_user_id or 0,))
    admins = [row["id"] for row in cursor.fetchall()]
    for admin_id in admins:
        notify(cursor, admin_id, title, message, notif_type, event_code, appointment_id)
    return len(admins)


def describe(appointment):
    """'General Consultation on 10/24/2026 at 9:00 AM' for messages."""
    day = to_date(appointment["appointment_date"])
    start = combine(day, appointment["start_time"])
    return f"{appointment['service_name']} on {day.strftime('%m/%d/%Y')} at {start.strftime('%I:%M %p').lstrip('0')}"


# ---------------------------------------------------------
# Email (optional)
# ---------------------------------------------------------
def email_enabled():
    return bool(config.MAIL_SERVER)


def send_email(to_address, subject, body):
    """Send one plain-text email. Returns True on success."""
    if not email_enabled() or not to_address:
        return False
    message = EmailMessage()
    message["From"] = config.MAIL_SENDER
    message["To"] = to_address
    message["Subject"] = subject
    message.set_content(body)
    try:
        with smtplib.SMTP(config.MAIL_SERVER, config.MAIL_PORT, timeout=10) as smtp:
            if config.MAIL_USE_TLS:
                smtp.starttls()
            if config.MAIL_USERNAME:
                smtp.login(config.MAIL_USERNAME, config.MAIL_PASSWORD)
            smtp.send_message(message)
        return True
    except Exception:
        return False


# ---------------------------------------------------------
# Housekeeping
# ---------------------------------------------------------
_last_run = {"at": None}
_retrain_checked = {"hour": None}
_lock = threading.Lock()


def maybe_run_housekeeping(get_cursor, settings_loader, now=None, min_interval_seconds=60):
    """Run housekeeping at most once per interval per server process."""
    now = now or datetime.now()
    with _lock:
        if _last_run["at"] and (now - _last_run["at"]).total_seconds() < min_interval_seconds:
            return None
        _last_run["at"] = now
    try:
        return run_housekeeping(get_cursor, settings_loader, now)
    except Exception:
        # Housekeeping must never break a page view.
        return None


def run_housekeeping(get_cursor, settings_loader, now=None, force_retrain_check=False):
    """Expire stale requests, create due reminders, send queued emails.
    Returns a small summary dict (printed by the CLI command)."""
    now = now or datetime.now()
    summary = {"expired": 0, "reminders": 0, "same_day": 0, "emails_sent": 0, "model_retrained": ""}

    with get_cursor(commit=True) as cursor:
        settings = settings_loader(cursor)

        # 1) Pending requests nobody answered before the start time (status "Expired").
        if settings["auto_expire_pending"]:
            cursor.execute(
                """SELECT a.id, a.user_id, a.appointment_date, a.start_time, s.name AS service_name
                   FROM appointments a JOIN services s ON s.id = a.service_id
                   WHERE a.status = 'pending' AND a.appointment_date <= %s
                   FOR UPDATE""",
                (now.date(),),
            )
            for row in cursor.fetchall():
                if combine(to_date(row["appointment_date"]), row["start_time"]) > now:
                    continue
                cursor.execute("UPDATE appointments SET status = 'expired' WHERE id = %s AND status = 'pending'", (row["id"],))
                cursor.execute(
                    """INSERT INTO appointment_history (appointment_id, action, old_status, new_status, performed_by, reason)
                       VALUES (%s, 'expired', 'pending', 'expired', NULL, %s)""",
                    (row["id"], "Not confirmed before the start time"),
                )
                notify(cursor, row["user_id"], "Request expired",
                       f"Your request for {describe(row)} was not confirmed in time and has expired. Please book another slot.",
                       "warning", None, row["id"])
                summary["expired"] += 1

        # 2) Reminders for confirmed appointments (N007 advance, N008 same day).
        horizon = now + timedelta(hours=settings["reminder_hours_before"])
        cursor.execute(
            """SELECT a.id, a.user_id, a.appointment_date, a.start_time, a.reminder_sent_at,
                      a.sameday_reminder_sent_at, s.name AS service_name,
                      pu.id AS staff_user_id, pu.name AS provider_name, cu.name AS client_name
               FROM appointments a
               JOIN services s ON s.id = a.service_id
               JOIN providers p ON p.id = a.provider_id
               JOIN users pu ON pu.id = p.user_id
               JOIN users cu ON cu.id = a.user_id
               WHERE a.status = 'confirmed' AND a.appointment_date BETWEEN %s AND %s
                 AND (a.reminder_sent_at IS NULL OR a.sameday_reminder_sent_at IS NULL)
               FOR UPDATE""",
            (now.date(), horizon.date()),
        )
        for row in cursor.fetchall():
            start = combine(to_date(row["appointment_date"]), row["start_time"])
            if start <= now:
                continue
            if row["reminder_sent_at"] is None and start <= horizon:
                notify(cursor, row["user_id"], "Upcoming appointment",
                       f"Reminder: {describe(row)} with {row['provider_name']}.", "info", "N007", row["id"])
                notify(cursor, row["staff_user_id"], "Upcoming appointment",
                       f"Reminder: {describe(row)} with {row['client_name']}.", "info", "N007", row["id"])
                cursor.execute("UPDATE appointments SET reminder_sent_at = %s WHERE id = %s", (now, row["id"]))
                summary["reminders"] += 1
            if row["sameday_reminder_sent_at"] is None and start.date() == now.date():
                notify(cursor, row["user_id"], "Appointment today",
                       f"Today: {describe(row)} with {row['provider_name']}.", "info", "N008", row["id"])
                notify(cursor, row["staff_user_id"], "Appointment today",
                       f"Today: {describe(row)} with {row['client_name']}.", "info", "N008", row["id"])
                cursor.execute("UPDATE appointments SET sameday_reminder_sent_at = %s WHERE id = %s", (now, row["id"]))
                summary["same_day"] += 1

    # 3) Forecast model: retrain + deploy when a new complete week of live data exists.
    hour = (now.date(), now.hour)
    if force_retrain_check or _retrain_checked["hour"] != hour:
        _retrain_checked["hour"] = hour
        try:
            from agende import forecasting
            with get_cursor(commit=True) as cursor:
                settings = settings_loader(cursor)
                trained = forecasting.auto_retrain(cursor, settings, now.date())
                if trained:
                    r = trained["result"]
                    am, nm = r["appointment_model"], r["no_show_model"]
                    notify_admins(
                        cursor, "Forecast model updated",
                        f"{trained['version']} was trained automatically on {len(r['weeks'])} weeks of live records "
                        f"(to {r['training_end'].strftime('%m/%d/%Y')}) and is now active. Test MAE: "
                        f"{am['mae']:.1f} appointments, {nm['mae']:.1f} did-not-attend per week.",
                        "info")
                    summary["model_retrained"] = trained["version"]
                    from agende.audit import write_audit
                    write_audit(cursor, None, "Retrained forecast model", "forecast_model", None,
                                details=f"{trained['version']} (automatic, live records to {r['training_end']})")
        except Exception:
            # A failed retrain keeps the current model; it is retried next hour.
            import logging
            logging.getLogger("agende").exception("Automatic forecast retraining failed")

    # 4) Email outbox (only when MAIL_SERVER is configured). A failed send stays
    #    queued and is retried next time; the in-app notification is unaffected.
    if email_enabled():
        with get_cursor(commit=True) as cursor:
            cursor.execute(
                """SELECT n.id, n.title, n.message, u.email FROM notifications n
                   JOIN users u ON u.id = n.user_id
                   WHERE n.channel = 'in_app+email' AND n.email_sent_at IS NULL
                   ORDER BY n.id LIMIT 25""")
            for row in cursor.fetchall():
                if send_email(row["email"], f"AGENDE: {row['title'] or 'Notification'}", row["message"]):
                    cursor.execute("UPDATE notifications SET email_sent_at = %s WHERE id = %s", (now, row["id"]))
                    summary["emails_sent"] += 1
    return summary


__all__ = ["notify", "notify_role", "notify_admins", "describe", "send_email", "email_enabled",
           "maybe_run_housekeeping", "run_housekeeping", "status_label"]
