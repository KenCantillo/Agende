"""
Pure-Python scorer for the exported no-show logistic-regression model (agende/models/noshow_agende.json; research copies in research/ml/models/).
No scikit-learn needed at run time, so a model trained with any scikit-learn version can be
used by AGENDE on any machine.

    from agende.noshow_scorer import load_model, risk
    model = load_model("agende/models/noshow_agende.json")
    p, tier = risk(model, {"scheduling_interval": 12, "prior_appointments": 3, "prior_no_shows": 1, ...})

The probability is ADVISORY: it supports staff decisions (an extra reminder call, a
confirmation request). It must never cancel, reject or deprioritize a booking by itself.
"""
import json
import math


def load_model(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def derive(record):
    """Add the derived features the model was trained with."""
    r = dict(record)
    prior = float(r.get("prior_appointments", 0) or 0)
    r.setdefault("has_history", 1 if prior > 0 else 0)
    r.setdefault("prior_no_show_rate", (float(r.get("prior_no_shows", 0) or 0) / prior) if prior else 0.0)
    r.setdefault("prior_cancel_rate", (float(r.get("prior_cancellations", 0) or 0) / prior) if prior else 0.0)
    for c in ("prior_appointments", "prior_no_shows", "prior_cancellations"):
        r.setdefault("log_" + c, math.log1p(float(r.get(c, 0) or 0)))
    if "hour" not in r and r.get("appointment_time"):
        hh, mm = str(r["appointment_time"]).split(":")[:2]
        r["hour"] = int(hh) + int(mm) / 60
    return r


def clipped(feature, record):
    """Value of one numeric input, kept inside the range seen in training (no wild extrapolation).
    A missing value counts as the training average (contributes 0)."""
    x = float(record.get(feature["name"], feature["mean"]))
    if "lo" in feature:
        x = min(max(x, feature["lo"]), feature["hi"])
    return x


def probability(model, record):
    r = derive(record)
    z = model["intercept"]
    for f in model["numeric"]:
        z += f["coef"] * (clipped(f, r) - f["mean"]) / f["scale"]
    for f in model["categorical"]:
        z += f["values"].get(str(r.get(f["name"])), f.get("unknown", 0.0))
    return 1 / (1 + math.exp(-z))


def risk(model, record):
    """(probability, tier) with tier 'high' / 'medium' / 'low' from the exported cut-offs."""
    p = probability(model, record)
    tiers = model["tiers"]
    tier = "high" if p >= tiers["high"] else ("medium" if p >= tiers["medium"] else "low")
    return p, tier
