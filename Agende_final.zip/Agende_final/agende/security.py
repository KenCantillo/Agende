# =========================================================
# SECURITY.PY
# Login/role guards, CSRF protection, and input validation.
# Blueprint section 32: authenticated? -> correct role? -> authorized resource?
# (the third check, ownership, is done inside each route.)
# =========================================================

import hmac
import re
import secrets
from functools import wraps

from flask import abort, flash, redirect, request, session, url_for
from markupsafe import Markup

ROLE_LABELS = {"user": "Client", "provider": "Staff", "admin": "Administrator"}

EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$")
PHONE_PATTERN = re.compile(r"^[0-9+()\-\s]{7,20}$")


# ---------------------------------------------------------
# Route guards
# ---------------------------------------------------------
def login_required(view_function):
    """Make sure someone is logged in before running the route."""
    @wraps(view_function)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "danger")
            return redirect(url_for("login", next=request.path))
        return view_function(*args, **kwargs)
    return wrapper


def role_required(*role_names):
    """Allow only the listed roles.  Usage: @role_required("admin")
    or @role_required("provider", "admin")."""
    def decorator(view_function):
        @wraps(view_function)
        def wrapper(*args, **kwargs):
            if "user_id" not in session:
                flash("Please log in to continue.", "danger")
                return redirect(url_for("login", next=request.path))
            if session.get("role") not in role_names:
                # Never trust hidden buttons: the server blocks the request.
                abort(403)
            return view_function(*args, **kwargs)
        return wrapper
    return decorator


# ---------------------------------------------------------
# CSRF protection (blueprint 32 "CSRF")
# Every POST form includes {{ csrf_field() }}. The token lives in the
# signed session cookie, so another website cannot read or forge it.
# ---------------------------------------------------------
def get_csrf_token():
    token = session.get("_csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["_csrf_token"] = token
    return token


def csrf_field():
    """Hidden <input> placed inside every POST form."""
    return Markup('<input type="hidden" name="csrf_token" value="%s">' % get_csrf_token())


def csrf_is_valid():
    sent = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token", "")
    expected = session.get("_csrf_token", "")
    return bool(sent) and bool(expected) and hmac.compare_digest(sent, expected)


# ---------------------------------------------------------
# Validation helpers (blueprint section 27)
# Each returns an error message, or None when the value is fine.
# ---------------------------------------------------------
def validate_email(email):
    if not email:
        return "Email address is required."
    if len(email) > 120 or not EMAIL_PATTERN.match(email):
        return "Enter a valid email address."
    return None


def validate_password(password, confirm=None):
    if not password or len(password) < 8:
        return "Password must be at least 8 characters."
    if not re.search(r"[A-Za-z]", password) or not re.search(r"[0-9]", password):
        return "Password must contain at least one letter and one number."
    if confirm is not None and password != confirm:
        return "Passwords do not match."
    return None


def validate_phone(phone):
    if phone and not PHONE_PATTERN.match(phone):
        return "Enter a valid phone number (digits, spaces, +, - and parentheses only)."
    return None


def validate_name(name):
    if not name or not name.strip():
        return "Name is required."
    if len(name) > 100:
        return "Name must be 100 characters or fewer."
    return None


def client_ip():
    """Best-effort client address for the audit log."""
    return (request.headers.get("X-Forwarded-For", request.remote_addr or "") or "").split(",")[0].strip()[:45]


def safe_next_url(target):
    """Only allow redirects back into this site (prevents open redirects)."""
    if target and target.startswith("/") and not target.startswith("//"):
        return target
    return None
