# =========================================================
# ANALYTICS.PY
# Descriptive analytics (blueprint section 14, F067-F077).
#
# Formulas - used the same way everywhere (BR-029):
#   A001 Total appointments   = all appointment records in the period
#   A006 No-show rate         = no_show / (completed + no_show) x 100
#   A007 Cancellation rate    = cancelled / total appointment requests x 100
#   A008 Completion rate      = completed / (completed + no_show) x 100
#   A009 Service utilization  = appointments that held a slot / potential slots x 100
#   A010 Staff workload       = appointments assigned to the staff member
#   Staff utilization         = booked minutes / available scheduled minutes x 100
#
# "Held a slot" = pending, confirmed, completed or did not attend
# (cancelled, rejected and expired requests freed their slot).
# All filters (dates, service, staff) apply to every number and chart
# on the page (BR-030).
# =========================================================

from collections import Counter, defaultdict
from datetime import date, datetime, timedelta

from agende.scheduling import ALL_STATUSES, OCCUPYING_STATUSES, combine, overlaps, status_label, to_date, to_time

WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
MAX_RANGE_DAYS = 731


def rate(numerator, denominator):
    """Percentage rounded to 1 decimal, or None when there is nothing to divide by."""
    if not denominator:
        return None
    return round(100.0 * numerator / denominator, 1)


def parse_filters(args, today, cursor=None, provider_scope=None):
    """Read ?start=&end=&service_id=&provider_id= from the URL (validation rules section 27)."""
    errors = []
    default_start = today - timedelta(days=89)
    start = to_date(args.get("start")) or default_start
    end = to_date(args.get("end")) or today
    if args.get("start") and to_date(args.get("start")) is None:
        errors.append("Start date is not a valid date.")
    if args.get("end") and to_date(args.get("end")) is None:
        errors.append("End date is not a valid date.")
    if start > end:
        errors.append("Start date must be on or before the end date.")
        start, end = end, start
    if (end - start).days > MAX_RANGE_DAYS:
        errors.append("Date range is limited to two years; showing the last two years of the selection.")
        start = end - timedelta(days=MAX_RANGE_DAYS)

    def as_int(name):
        raw = (args.get(name) or "").strip()
        if not raw:
            return None
        try:
            return int(raw)
        except ValueError:
            errors.append(f"Unknown {name.replace('_id', '')} filter ignored.")
            return None

    service_id = as_int("service_id")
    provider_id = as_int("provider_id")
    if provider_scope is not None:
        # Staff only ever see their own numbers - an unauthorized filter is rejected.
        if provider_id not in (None, provider_scope):
            errors.append("You can only view analytics for your own appointments.")
        provider_id = provider_scope
    if cursor is not None:
        if service_id is not None:
            cursor.execute("SELECT id FROM services WHERE id = %s", (service_id,))
            if cursor.fetchone() is None:
                errors.append("Selected service does not exist.")
                service_id = None
        if provider_id is not None and provider_scope is None:
            cursor.execute("SELECT id FROM providers WHERE id = %s", (provider_id,))
            if cursor.fetchone() is None:
                errors.append("Selected staff member does not exist.")
                provider_id = None
    return {"start": start, "end": end, "service_id": service_id, "provider_id": provider_id}, errors


def _where(filters, alias="a"):
    clauses = [f"{alias}.appointment_date BETWEEN %s AND %s"]
    params = [filters["start"], filters["end"]]
    if filters.get("service_id"):
        clauses.append(f"{alias}.service_id = %s")
        params.append(filters["service_id"])
    if filters.get("provider_id"):
        clauses.append(f"{alias}.provider_id = %s")
        params.append(filters["provider_id"])
    return " AND ".join(clauses), params


def bucket_for(day, granularity):
    if granularity == "day":
        return day
    if granularity == "week":
        return day - timedelta(days=day.weekday())
    return day.replace(day=1)


def bucket_label(bucket, granularity):
    if granularity == "month":
        return bucket.strftime("%b %Y")
    if granularity == "week":
        return "Wk of " + bucket.strftime("%b %d")
    return bucket.strftime("%b %d")


def iter_buckets(start, end, granularity):
    current = bucket_for(start, granularity)
    while current <= end:
        yield current
        if granularity == "day":
            current += timedelta(days=1)
        elif granularity == "week":
            current += timedelta(days=7)
        else:
            current = (current.replace(day=28) + timedelta(days=4)).replace(day=1)


def summarize_status_counts(counts):
    """KPI block from a {status: count} mapping."""
    total = sum(counts.values())
    completed, no_show, cancelled = counts.get("completed", 0), counts.get("no_show", 0), counts.get("cancelled", 0)
    return {
        "total": total,
        "pending": counts.get("pending", 0),
        "confirmed": counts.get("confirmed", 0),
        "completed": completed,
        "cancelled": cancelled,
        "rejected": counts.get("rejected", 0),
        "no_show": no_show,
        "expired": counts.get("expired", 0),
        "no_show_rate": rate(no_show, completed + no_show),
        "cancellation_rate": rate(cancelled, total),
        "completion_rate": rate(completed, completed + no_show),
    }


def available_minutes(windows_by_weekday, blocks, start, end):
    """Scheduled minutes between two dates minus blocked time inside those windows."""
    total = 0
    day = start
    while day <= end:
        for w_start, w_end in windows_by_weekday.get(day.weekday(), []):
            window_start, window_end = combine(day, w_start), combine(day, w_end)
            minutes = (window_end - window_start).total_seconds() / 60
            for b_start, b_end in blocks:
                if overlaps(window_start, window_end, b_start, b_end):
                    minutes -= (min(window_end, b_end) - max(window_start, b_start)).total_seconds() / 60
            total += max(0, minutes)
        day += timedelta(days=1)
    return total


def compute(cursor, filters):
    """Everything the analytics page needs, from actual appointment records (BR-027)."""
    where, params = _where(filters)
    cursor.execute(
        f"""SELECT a.appointment_date, a.start_time, a.end_time, a.status, a.service_id, a.provider_id,
                   s.name AS service_name, s.duration, pu.name AS provider_name
            FROM appointments a
            JOIN services s ON s.id = a.service_id
            JOIN providers p ON p.id = a.provider_id
            JOIN users pu ON pu.id = p.user_id
            WHERE {where}""",
        params,
    )
    rows = cursor.fetchall()
    start, end = filters["start"], filters["end"]
    span = (end - start).days + 1
    granularity = "day" if span <= 31 else ("week" if span <= 182 else "month")

    status_counts = Counter(r["status"] for r in rows)
    kpis = summarize_status_counts(status_counts)

    # Trends: volume plus cancellation / no-show counts per bucket.
    buckets = list(iter_buckets(start, end, granularity))
    per_bucket = {b: Counter() for b in buckets}
    for r in rows:
        b = bucket_for(to_date(r["appointment_date"]), granularity)
        if b in per_bucket:
            per_bucket[b][r["status"]] += 1
            per_bucket[b]["_total"] += 1
    trend = {
        "labels": [bucket_label(b, granularity) for b in buckets],
        "total": [per_bucket[b]["_total"] for b in buckets],
        "completed": [per_bucket[b]["completed"] for b in buckets],
        "cancelled": [per_bucket[b]["cancelled"] for b in buckets],
        "no_show": [per_bucket[b]["no_show"] for b in buckets],
        "granularity": granularity,
    }

    # Busiest days and hours (heatmap of slots actually held).
    weekday_counts = [0] * 7
    heat = defaultdict(int)
    hours = set()
    for r in rows:
        if r["status"] not in OCCUPYING_STATUSES:
            continue
        day = to_date(r["appointment_date"])
        weekday_counts[day.weekday()] += 1
        hour = to_time(r["start_time"]).hour
        heat[(day.weekday(), hour)] += 1
        hours.add(hour)
    hour_range = list(range(min(hours), max(hours) + 1)) if hours else list(range(8, 18))
    heat_max = max(heat.values()) if heat else 0
    heatmap = [{"day": WEEKDAYS[d], "cells": [{"hour": h, "count": heat.get((d, h), 0),
                                                 "level": 0 if not heat_max else round(4 * heat.get((d, h), 0) / heat_max)}
                                                for h in hour_range]} for d in range(7)]

    # Workload per staff and utilization.
    cursor.execute(
        """SELECT p.id, pu.name AS provider_name, p.is_active FROM providers p
           JOIN users pu ON pu.id = p.user_id ORDER BY pu.name""")
    providers = cursor.fetchall()
    if filters.get("provider_id"):
        providers = [p for p in providers if p["id"] == filters["provider_id"]]
    if filters.get("service_id"):
        cursor.execute("SELECT provider_id FROM provider_services WHERE service_id = %s", (filters["service_id"],))
        offering = {r["provider_id"] for r in cursor.fetchall()}
        providers = [p for p in providers if p["id"] in offering or any(r["provider_id"] == p["id"] for r in rows)]

    cursor.execute("SELECT provider_id, day_of_week, start_time, end_time FROM provider_schedules WHERE is_available = 1")
    windows = defaultdict(lambda: defaultdict(list))
    for w in cursor.fetchall():
        windows[w["provider_id"]][int(w["day_of_week"])].append((to_time(w["start_time"]), to_time(w["end_time"])))
    cursor.execute(
        "SELECT provider_id, start_datetime, end_datetime FROM blocked_periods WHERE start_datetime < %s AND end_datetime > %s",
        (datetime.combine(end + timedelta(days=1), datetime.min.time()), datetime.combine(start, datetime.min.time())))
    blocks = defaultdict(list)
    for b in cursor.fetchall():
        blocks[b["provider_id"]].append((b["start_datetime"], b["end_datetime"]))

    capacity_minutes = {p["id"]: available_minutes(windows[p["id"]], blocks[p["id"]], start, end) for p in providers}
    staff = []
    for p in providers:
        mine = [r for r in rows if r["provider_id"] == p["id"]]
        counts = Counter(r["status"] for r in mine)
        booked = sum((combine(to_date(r["appointment_date"]), r["end_time"]) -
                      combine(to_date(r["appointment_date"]), r["start_time"])).total_seconds() / 60
                     for r in mine if r["status"] in OCCUPYING_STATUSES)
        staff.append({
            "id": p["id"], "name": p["provider_name"], "total": len(mine),
            "counts": {s: counts.get(s, 0) for s in ALL_STATUSES},
            "booked_minutes": round(booked), "available_minutes": round(capacity_minutes[p["id"]]),
            "utilization": rate(booked, capacity_minutes[p["id"]]),
            "no_show_rate": rate(counts.get("no_show", 0), counts.get("completed", 0) + counts.get("no_show", 0)),
        })
    staff.sort(key=lambda s: s["total"], reverse=True)

    # Service utilization. Potential slots for a service = each offering staff
    # member's available minutes / service duration (an upper bound when a staff
    # member offers several services - stated on the page).
    cursor.execute("SELECT id, name, duration, is_active FROM services ORDER BY name")
    services = cursor.fetchall()
    if filters.get("service_id"):
        services = [s for s in services if s["id"] == filters["service_id"]]
    cursor.execute("SELECT provider_id, service_id FROM provider_services")
    offered_by = defaultdict(set)
    for link in cursor.fetchall():
        offered_by[link["service_id"]].add(link["provider_id"])
    service_stats = []
    for s in services:
        mine = [r for r in rows if r["service_id"] == s["id"]]
        held = sum(1 for r in mine if r["status"] in OCCUPYING_STATUSES)
        potential = sum(capacity_minutes.get(pid, 0) for pid in offered_by[s["id"]]
                        if not filters.get("provider_id") or pid == filters["provider_id"]) / max(1, s["duration"])
        if not mine and not potential:
            continue
        service_stats.append({"id": s["id"], "name": s["name"], "total": len(mine), "held": held,
                              "potential_slots": int(potential), "utilization": rate(held, potential),
                              "cancelled": sum(1 for r in mine if r["status"] == "cancelled"),
                              "no_show": sum(1 for r in mine if r["status"] == "no_show")})
    service_stats.sort(key=lambda s: s["total"], reverse=True)

    total_capacity = sum(capacity_minutes.values())
    total_booked = sum(s["booked_minutes"] for s in staff)
    kpis["utilization"] = rate(total_booked, total_capacity)

    return {
        "filters": filters,
        "kpis": kpis,
        "status_counts": [{"status": s, "label": status_label(s), "count": status_counts.get(s, 0)} for s in ALL_STATUSES],
        "trend": trend,
        "weekday_counts": weekday_counts,
        "weekdays": WEEKDAYS,
        "heatmap": heatmap,
        "heat_hours": hour_range,
        "staff": staff,
        "services": service_stats,
        "row_count": len(rows),
    }


def unusual_activity(cursor, today, provider_id=None):
    """Dashboard alert (blueprint 13.3): last 7 days vs the 28 days before.
    Flags a rate that is at least 1.5x the baseline with 3+ events."""
    alerts = []
    recent_start, base_start = today - timedelta(days=6), today - timedelta(days=34)
    query = """SELECT appointment_date, status FROM appointments
               WHERE appointment_date BETWEEN %s AND %s"""
    params = [base_start, today]
    if provider_id:
        query += " AND provider_id = %s"
        params.append(provider_id)
    cursor.execute(query, params)
    recent, base = Counter(), Counter()
    for r in cursor.fetchall():
        (recent if to_date(r["appointment_date"]) >= recent_start else base)[r["status"]] += 1
    checks = [("no_show", "Did-not-attend rate", lambda c: rate(c["no_show"], c["completed"] + c["no_show"])),
              ("cancelled", "Cancellation rate", lambda c: rate(c["cancelled"], sum(c.values())))]
    for status, label, fn in checks:
        now_rate, base_rate = fn(recent), fn(base)
        if recent[status] >= 3 and now_rate is not None and base_rate and now_rate >= 1.5 * base_rate:
            alerts.append(f"{label} in the last 7 days is {now_rate}% (previous 4 weeks: {base_rate}%).")
    return alerts


def daily_counts(cursor, start, end, provider_id=None, user_id=None):
    """{date: Counter(status)} for small dashboard charts."""
    query = "SELECT appointment_date, status, COUNT(*) AS n FROM appointments WHERE appointment_date BETWEEN %s AND %s"
    params = [start, end]
    if provider_id:
        query += " AND provider_id = %s"
        params.append(provider_id)
    if user_id:
        query += " AND user_id = %s"
        params.append(user_id)
    query += " GROUP BY appointment_date, status"
    cursor.execute(query, params)
    result = defaultdict(Counter)
    for r in cursor.fetchall():
        result[to_date(r["appointment_date"])][r["status"]] += int(r["n"])
    return result


__all__ = ["rate", "parse_filters", "compute", "unusual_activity", "daily_counts", "summarize_status_counts",
           "available_minutes", "WEEKDAYS", "date"]
