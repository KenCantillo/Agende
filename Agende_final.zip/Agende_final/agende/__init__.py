"""
AGENDÉ - web-based multi-appointment system (Flask + MySQL).

    from agende import app      # the Flask application with every page registered

Package layout:
    web.py              Flask app object, template filters, request hooks, shared helpers
    routes/             pages: auth, shared, client, staff, admin, admin_manage, admin_insights
    scheduling.py       availability + conflict detection          (Modules 4, 6)
    appointments.py     booking / reschedule / status changes      (Module 5)
    notifications.py    notifications, reminders, housekeeping     (Module 8)
    analytics.py        descriptive analytics                      (Module 9)
    forecasting.py      weekly linear-regression forecast model    (Module 10)
    noshow_risk.py      advisory no-show risk for staff            (3.2)
    noshow_scorer.py    pure-Python scorer for models/noshow_agende.json
    audit.py            audit trail                                (Module 12)
    settings_store.py   system settings                            (Module 13)
    security.py         guards, CSRF, validation
    database.py         connections and transactions
    migrations.py       check / back up the database (also used by the tests)
    db_diagnostics.py   plain-language database error advice
    cli.py              flask commands: housekeeping, train-forecast, backup-db
    config.py           settings (MySQL login, port ...)
"""
from agende.version import VERSION
from agende.web import app

# Importing the route modules registers their pages on the app.
from agende.routes import auth, shared, client, staff, admin, admin_manage, admin_insights  # noqa: F401,E402
from agende import cli  # noqa: F401,E402  (flask commands)

__all__ = ["app", "VERSION"]
