# =========================================================
# AUDIT.PY
# One function that appends a row to audit_logs (blueprint 31).
# It uses the SAME cursor as the change being audited, so the
# change and its audit record are saved (or rolled back) together.
# =========================================================

import json

from flask import has_request_context

from agende.security import client_ip


def _as_text(value):
    if value is None:
        return None
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, default=str, ensure_ascii=False)
    return str(value)


def write_audit(cursor, user_id, action, entity_name, entity_id=None,
                old_value=None, new_value=None, details=None):
    ip_address = client_ip() if has_request_context() else None
    cursor.execute(
        """INSERT INTO audit_logs (user_id, action, entity_name, entity_id, old_value, new_value, details, ip_address)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
        (user_id, action[:100], entity_name[:80], entity_id,
         _as_text(old_value), _as_text(new_value), _as_text(details), ip_address),
    )
