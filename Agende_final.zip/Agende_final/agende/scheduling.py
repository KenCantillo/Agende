# =========================================================
# SCHEDULING.PY
# Availability + conflict detection (blueprint sections 10, 11).
#
#   AVAILABLE SLOT = Working schedule - Breaks - Blocked periods
#                    - Active appointments - Booking restrictions
#
# The top half of this file is PURE Python (no database), so it
# can be unit-tested directly (see tests/test_rules.py).
# The bottom half loads what those functions need from MySQL.
#
# Breaks are modelled as gaps between weekly windows, e.g.
# Monday 08:00-12:00 and 13:00-17:00 = a 12:00-13:00 break.
# =========================================================

from datetime import date, datetime, time, timedelta

# Appointments in these statuses occupy their time slot.
ACTIVE_STATUSES = ("pending", "confirmed")

# Statuses that still count as "the client was going to be there"
# when measuring how busy a provider was (analytics).
OCCUPYING_STATUSES = ("pending", "confirmed", "completed", "no_show")

ALL_STATUSES = ("pending", "confirmed", "completed", "cancelled", "rejected", "no_show", "expired")

STATUS_LABELS = {
    "pending": "Pending",
    "confirmed": "Confirmed",
    "completed": "Completed",
    "cancelled": "Cancelled",
    "rejected": "Rejected",
    "no_show": "Did not attend",
    "expired": "Expired",
}

# Appointment lifecycle (blueprint 4.2). Anything not listed is refused.
TRANSITIONS = {
    "pending": ("confirmed", "rejected", "cancelled", "expired"),
    "confirmed": ("completed", "no_show", "cancelled"),
}

# Which target statuses each role may set (blueprint section 6).
ROLE_STATUS_PERMISSIONS = {
    "user": ("cancelled",),
    "provider": ("confirmed", "rejected", "cancelled", "completed", "no_show"),
    "admin": ("confirmed", "rejected", "cancelled", "completed", "no_show"),
    "system": ("expired",),
}

# These can only be recorded once the appointment's start time has passed.
REQUIRES_STARTED = ("completed", "no_show")

# Slot display states (blueprint 11)
SLOT_AVAILABLE = "available"
SLOT_BOOKED = "booked"
SLOT_BLOCKED = "blocked"
SLOT_PAST = "past"
SLOT_CLASH = "clash"          # the client already has something at that time
SLOT_TOO_FAR = "too_far"


# ---------------------------------------------------------
# PURE HELPERS
# ---------------------------------------------------------
def to_time(value):
    """MySQL TIME comes back from PyMySQL as timedelta; forms send 'HH:MM'."""
    if value is None or value == "":
        return None
    if isinstance(value, time):
        return value.replace(microsecond=0)
    if isinstance(value, timedelta):
        seconds = int(value.total_seconds()) % (24 * 3600)
        return time(seconds // 3600, (seconds % 3600) // 60, seconds % 60)
    if isinstance(value, datetime):
        return value.time().replace(microsecond=0)
    text = str(value).strip()
    for fmt in ("%H:%M:%S", "%H:%M"):
        try:
            return datetime.strptime(text, fmt).time()
        except ValueError:
            continue
    return None


def to_date(value):
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    try:
        return datetime.strptime(str(value).strip()[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


def combine(day, value):
    return datetime.combine(day, to_time(value))


def overlaps(start_a, end_a, start_b, end_b):
    """Core overlap rule (blueprint 10.1): existing_start < requested_end AND
    existing_end > requested_start. Touching edges (10-11 and 11-12) do NOT overlap."""
    return start_a < end_b and end_a > start_b


def can_transition(old_status, new_status):
    return new_status in TRANSITIONS.get(old_status, ())


def role_may_set(role, new_status):
    return new_status in ROLE_STATUS_PERMISSIONS.get(role, ())


def status_label(status):
    return STATUS_LABELS.get(status, (status or "").replace("_", " ").title())


def generate_slots(day, duration_minutes, windows, busy_appointments, blocked_periods,
                   interval_minutes=30, earliest_start=None, latest_day=None,
                   buffer_minutes=0, client_busy=None):
    """Return every candidate start time for one provider on one day.

    day               : date being booked
    duration_minutes  : service duration
    windows           : [(start_time, end_time), ...] available weekly windows for that weekday
    busy_appointments : [(start_dt, end_dt), ...] the provider's active appointments
    blocked_periods   : [(start_dt, end_dt), ...]
    earliest_start    : datetime; anything before it is "past" (now + minimum notice)
    latest_day        : last date clients may book (None = no limit)
    buffer_minutes    : required gap after each appointment (applied to both sides)
    client_busy       : [(start_dt, end_dt), ...] the client's own active appointments

    Each slot is a dict: {"start": time, "end": time, "state": "available" | ...}.
    Only state == "available" may be booked.
    """
    duration = timedelta(minutes=int(duration_minutes))
    step = timedelta(minutes=max(1, int(interval_minutes)))
    buffer = timedelta(minutes=int(buffer_minutes or 0))
    client_busy = client_busy or []
    slots = []
    seen = set()

    for window_start, window_end in sorted(windows, key=lambda w: to_time(w[0])):
        cursor_dt = combine(day, window_start)
        window_end_dt = combine(day, window_end)
        while cursor_dt + duration <= window_end_dt:
            start_dt, end_dt = cursor_dt, cursor_dt + duration
            cursor_dt += step
            if start_dt in seen:
                continue
            seen.add(start_dt)

            if latest_day is not None and day > latest_day:
                state = SLOT_TOO_FAR
            elif earliest_start is not None and start_dt < earliest_start:
                state = SLOT_PAST
            elif any(overlaps(start_dt, end_dt, b_start, b_end) for b_start, b_end in blocked_periods):
                state = SLOT_BLOCKED
            elif any(overlaps(start_dt, end_dt + buffer, a_start, a_end + buffer)
                     for a_start, a_end in busy_appointments):
                state = SLOT_BOOKED
            elif any(overlaps(start_dt, end_dt, c_start, c_end) for c_start, c_end in client_busy):
                state = SLOT_CLASH
            else:
                state = SLOT_AVAILABLE
            slots.append({"start": start_dt.time(), "end": end_dt.time(), "state": state})
    slots.sort(key=lambda s: s["start"])
    return slots


SLOT_MESSAGES = {
    SLOT_PAST: "Selected time has already passed or is too soon to book. Please choose a later time.",
    SLOT_BOOKED: "This slot is no longer available. Please select another available time.",
    SLOT_BLOCKED: "Staff member is unavailable for this time.",
    SLOT_CLASH: "Selected time conflicts with another of your appointments.",
    SLOT_TOO_FAR: "That date is too far ahead to book.",
    None: "Staff member is unavailable for this time.",
}


def find_slot(slots, start_time):
    wanted = to_time(start_time)
    for slot in slots:
        if slot["start"] == wanted:
            return slot
    return None


# ---------------------------------------------------------
# DATABASE HELPERS
# ---------------------------------------------------------
def load_calendar(cursor, provider_id, first_day, last_day, exclude_appointment_id=None, client_id=None):
    """Load everything generate_slots() needs for a range of days in 4 queries."""
    cursor.execute(
        """SELECT day_of_week, start_time, end_time FROM provider_schedules
           WHERE provider_id = %s AND is_available = 1""",
        (provider_id,),
    )
    windows = {}
    for row in cursor.fetchall():
        windows.setdefault(int(row["day_of_week"]), []).append((to_time(row["start_time"]), to_time(row["end_time"])))

    range_start = datetime.combine(first_day, time(0, 0))
    range_end = datetime.combine(last_day + timedelta(days=1), time(0, 0))
    cursor.execute(
        """SELECT start_datetime, end_datetime FROM blocked_periods
           WHERE provider_id = %s AND start_datetime < %s AND end_datetime > %s""",
        (provider_id, range_end, range_start),
    )
    blocks = [(row["start_datetime"], row["end_datetime"]) for row in cursor.fetchall()]

    query = """SELECT id, appointment_date, start_time, end_time FROM appointments
               WHERE provider_id = %s AND status IN ('pending','confirmed')
               AND appointment_date BETWEEN %s AND %s"""
    params = [provider_id, first_day, last_day]
    if exclude_appointment_id:
        query += " AND id <> %s"
        params.append(exclude_appointment_id)
    cursor.execute(query, params)
    appointments = {}
    for row in cursor.fetchall():
        day = to_date(row["appointment_date"])
        appointments.setdefault(day, []).append((combine(day, row["start_time"]), combine(day, row["end_time"])))

    client_appointments = {}
    if client_id:
        query = """SELECT id, appointment_date, start_time, end_time FROM appointments
                   WHERE user_id = %s AND status IN ('pending','confirmed')
                   AND appointment_date BETWEEN %s AND %s"""
        params = [client_id, first_day, last_day]
        if exclude_appointment_id:
            query += " AND id <> %s"
            params.append(exclude_appointment_id)
        cursor.execute(query, params)
        for row in cursor.fetchall():
            day = to_date(row["appointment_date"])
            client_appointments.setdefault(day, []).append((combine(day, row["start_time"]), combine(day, row["end_time"])))

    return {"windows": windows, "blocks": blocks, "appointments": appointments, "client": client_appointments}


def slots_for_day(calendar, day, duration_minutes, settings, now, apply_client_rules=True):
    """Slots for one day using a calendar from load_calendar().
    apply_client_rules=False is used when staff/admin reschedule: they are not
    bound by the minimum-notice and booking-window limits (but never the past)."""
    if apply_client_rules:
        earliest = now + timedelta(minutes=settings["booking_min_lead_minutes"])
        latest_day = now.date() + timedelta(days=settings["booking_max_days_ahead"])
    else:
        earliest, latest_day = now, None
    day_blocks = [(s, e) for s, e in calendar["blocks"]
                  if overlaps(s, e, datetime.combine(day, time(0)), datetime.combine(day + timedelta(days=1), time(0)))]
    return generate_slots(
        day, duration_minutes,
        calendar["windows"].get(day.weekday(), []),
        calendar["appointments"].get(day, []),
        day_blocks,
        interval_minutes=settings["slot_interval_minutes"],
        earliest_start=earliest,
        latest_day=latest_day,
        buffer_minutes=settings["buffer_minutes"],
        client_busy=calendar["client"].get(day, []),
    )


def provider_offers_service(cursor, provider_id, service_id):
    """True when the staff member is active, their login is active, and
    they are assigned to the (active) service. (BR-001, BR-003)"""
    cursor.execute(
        """SELECT p.id FROM providers p
           JOIN users u ON u.id = p.user_id
           JOIN provider_services ps ON ps.provider_id = p.id
           JOIN services s ON s.id = ps.service_id
           WHERE p.id = %s AND ps.service_id = %s
             AND p.is_active = 1 AND u.is_active = 1 AND s.is_active = 1""",
        (provider_id, service_id),
    )
    return cursor.fetchone() is not None


def check_requested_slot(cursor, provider_id, service, client_id, day, start_time, settings, now,
                         exclude_appointment_id=None, apply_client_rules=True):
    """Full server-side validation of one requested slot (F025-F029, BR-001..BR-011).
    Returns (end_time, None) when bookable, or (None, "user-facing error message")."""
    if day is None or start_time is None:
        return None, "Please choose a date and an available time."
    if day < now.date():
        return None, "Please select a future date."
    if not service or not service.get("is_active"):
        return None, "This service is currently unavailable."
    if not provider_offers_service(cursor, provider_id, service["id"]):
        return None, "The selected staff member does not offer this service or is unavailable."
    calendar = load_calendar(cursor, provider_id, day, day, exclude_appointment_id, client_id)
    slots = slots_for_day(calendar, day, service["duration"], settings, now, apply_client_rules)
    slot = find_slot(slots, start_time)
    if slot is None:
        return None, SLOT_MESSAGES[None]
    if slot["state"] != SLOT_AVAILABLE:
        return None, SLOT_MESSAGES[slot["state"]]
    return slot["end"], None


class BookingBusy(Exception):
    """Another booking for the same staff member/client is still being saved."""


def lock_for_booking(cursor, provider_id, client_id):
    """Serialize bookings for this staff member and this client (TC020).

    Call it FIRST in the transaction, before any other read. Two locks are used:
      1. Named locks (GET_LOCK) - one per staff member and one per client. They
         are held by this database connection until it is closed, which
         database.db_cursor() does right AFTER the commit.
      2. Row locks (SELECT ... FOR UPDATE) on the staff and client rows, held by
         InnoDB until COMMIT/ROLLBACK.
    Either one alone stops two people who submit the same slot at the same
    moment from both succeeding: the second request waits, then sees the first
    booking and fails the overlap check. Having both keeps the protection even
    on servers where one of the mechanisms is unavailable."""
    for name in (f"agende_staff_{provider_id}", f"agende_client_{client_id}"):
        cursor.execute("SELECT GET_LOCK(%s, 10) AS got", (name,))
        row = cursor.fetchone()
        if not row or row["got"] != 1:
            raise BookingBusy("The schedule is busy right now. Please try again in a moment.")
    # Nothing has been written yet, so start a fresh transaction now that we hold
    # the locks: its snapshot then includes every booking committed before ours,
    # whichever isolation level / engine the server uses.
    cursor.connection.commit()
    cursor.connection.begin()
    cursor.execute("SELECT id FROM providers WHERE id = %s FOR UPDATE", (provider_id,))
    cursor.execute("SELECT id FROM users WHERE id = %s FOR UPDATE", (client_id,))


def find_overlapping_pairs(cursor, start_day, end_day, provider_id=None):
    """Existing double bookings among active appointments (admin/staff alerts).
    Should stay empty because of the checks above; it catches data entered
    directly in the database or created before 3.0."""
    query = """SELECT a.id AS first_id, b.id AS second_id, a.appointment_date,
                      a.start_time AS first_start, a.end_time AS first_end,
                      b.start_time AS second_start, b.end_time AS second_end,
                      a.provider_id, pu.name AS provider_name
               FROM appointments a
               JOIN appointments b ON a.provider_id = b.provider_id
                    AND a.appointment_date = b.appointment_date AND a.id < b.id
                    AND a.start_time < b.end_time AND a.end_time > b.start_time
               JOIN providers p ON p.id = a.provider_id
               JOIN users pu ON pu.id = p.user_id
               WHERE a.status IN ('pending','confirmed') AND b.status IN ('pending','confirmed')
                 AND a.appointment_date BETWEEN %s AND %s"""
    params = [start_day, end_day]
    if provider_id:
        query += " AND a.provider_id = %s"
        params.append(provider_id)
    query += " ORDER BY a.appointment_date, a.start_time"
    cursor.execute(query, params)
    return cursor.fetchall()


def appointments_outside_availability(cursor, provider_id, from_day):
    """Upcoming active appointments that no longer fit the weekly schedule or
    fall inside a blocked period (BR-021, BR-022). Nothing is deleted - the
    records are only identified so staff/admin can act on them."""
    cursor.execute(
        """SELECT a.id, a.provider_id, a.appointment_date, a.start_time, a.end_time, a.status, a.user_id,
                  u.name AS client_name, s.name AS service_name
           FROM appointments a
           JOIN users u ON u.id = a.user_id
           JOIN services s ON s.id = a.service_id
           WHERE a.provider_id = %s AND a.status IN ('pending','confirmed') AND a.appointment_date >= %s
           ORDER BY a.appointment_date, a.start_time""",
        (provider_id, from_day),
    )
    rows = cursor.fetchall()
    if not rows:
        return []
    last_day = max(to_date(r["appointment_date"]) for r in rows)
    calendar = load_calendar(cursor, provider_id, from_day, last_day)
    affected = []
    for row in rows:
        day = to_date(row["appointment_date"])
        start_dt, end_dt = combine(day, row["start_time"]), combine(day, row["end_time"])
        inside_window = any(combine(day, w_start) <= start_dt and end_dt <= combine(day, w_end)
                            for w_start, w_end in calendar["windows"].get(day.weekday(), []))
        blocked = any(overlaps(start_dt, end_dt, b_start, b_end) for b_start, b_end in calendar["blocks"])
        if not inside_window or blocked:
            row["problem"] = "Inside a blocked period" if blocked else "Outside working hours"
            affected.append(row)
    return affected


def windows_overlap_existing(cursor, provider_id, day_of_week, start_time, end_time, exclude_schedule_id=None):
    """Schedule rule S24: no overlapping weekly windows on the same day."""
    query = """SELECT id, start_time, end_time FROM provider_schedules
               WHERE provider_id = %s AND day_of_week = %s"""
    params = [provider_id, day_of_week]
    if exclude_schedule_id:
        query += " AND id <> %s"
        params.append(exclude_schedule_id)
    cursor.execute(query, params)
    for row in cursor.fetchall():
        if overlaps(start_time, end_time, to_time(row["start_time"]), to_time(row["end_time"])):
            return True
    return False
