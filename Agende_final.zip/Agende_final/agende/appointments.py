# =========================================================
# APPOINTMENTS.PY
# Every change to an appointment goes through one of three
# functions here, for every role:
#
#   create_appointment()  - new request (client) or booking on behalf (admin)
#   reschedule()          - move to another valid slot (client/staff/admin)
#   change_status()       - confirm, reject, cancel, complete, did not attend
#
# Each function receives a cursor that is already inside a
# transaction (database.db_cursor(commit=True)). If anything fails,
# it raises AppointmentError and the caller's "with" block rolls the
# whole transaction back - so an appointment is never half-saved,
# and its status history, notifications and audit row are written
# together with it (NFR-003).
# =========================================================

from datetime import timedelta

from agende.audit import write_audit
from agende.notifications import describe, notify, notify_admins
from agende.scheduling import (ACTIVE_STATUSES, REQUIRES_STARTED, BookingBusy, can_transition, check_requested_slot,
                        combine, lock_for_booking, role_may_set, status_label, to_date, to_time)


class AppointmentError(Exception):
    """A rule was broken. str(error) is safe to show to the user."""


APPOINTMENT_SELECT = """
    SELECT a.*, s.name AS service_name, s.duration, s.description AS service_description,
           cu.name AS client_name, cu.email AS client_email, cu.phone AS client_phone,
           pu.name AS provider_name, p.user_id AS staff_user_id, p.position AS provider_position
    FROM appointments a
    JOIN services s ON s.id = a.service_id
    JOIN users cu ON cu.id = a.user_id
    JOIN providers p ON p.id = a.provider_id
    JOIN users pu ON pu.id = p.user_id
"""


def fetch_appointment(cursor, appointment_id):
    cursor.execute(APPOINTMENT_SELECT + " WHERE a.id = %s", (appointment_id,))
    return cursor.fetchone()


def get_service(cursor, service_id):
    cursor.execute("SELECT * FROM services WHERE id = %s", (service_id,))
    return cursor.fetchone()


def can_view(appointment, role, user_id, provider_id=None):
    """Ownership rule: clients see their own, staff see assigned, admins see all."""
    if appointment is None:
        return False
    if role == "admin":
        return True
    if role == "provider":
        return provider_id is not None and appointment["provider_id"] == provider_id
    return appointment["user_id"] == user_id


def start_datetime(appointment):
    return combine(to_date(appointment["appointment_date"]), appointment["start_time"])


def client_cutoff_passed(appointment, settings, now):
    return start_datetime(appointment) - now < timedelta(hours=settings["cancellation_cutoff_hours"])


def _lock(cursor, provider_id, client_id):
    try:
        lock_for_booking(cursor, provider_id, client_id)
    except BookingBusy as error:
        raise AppointmentError(str(error))


def _history(cursor, appointment_id, action, old_status, new_status, actor_id, reason=None):
    cursor.execute(
        """INSERT INTO appointment_history (appointment_id, action, old_status, new_status, performed_by, reason)
           VALUES (%s, %s, %s, %s, %s, %s)""",
        (appointment_id, action, old_status, new_status, actor_id, (reason or None) and reason[:255]),
    )


# ---------------------------------------------------------
# CREATE (F020-F031, booking workflow section 9)
# ---------------------------------------------------------
def create_appointment(cursor, client_id, provider_id, service_id, day, start, notes,
                       actor_id, actor_role, settings, now):
    _lock(cursor, provider_id, client_id)                     # step 7: conflict protection

    cursor.execute(
        """SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id
           WHERE u.id = %s AND r.name = 'user' AND u.is_active = 1""", (client_id,))
    if cursor.fetchone() is None:
        raise AppointmentError("The selected client account is not active.")

    service = get_service(cursor, service_id)
    end, error = check_requested_slot(                         # step 5: final validation
        cursor, provider_id, service, client_id, day, to_time(start), settings, now,
        apply_client_rules=(actor_role == "user"))
    if error:
        raise AppointmentError(error)

    # Admin bookings made on a client's behalf are confirmed straight away.
    status = "confirmed" if actor_role == "admin" else "pending"
    cursor.execute(
        """INSERT INTO appointments (user_id, provider_id, service_id, appointment_date, start_time, end_time, status, notes)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
        (client_id, provider_id, service_id, day, to_time(start), end, status, (notes or "").strip()[:255] or None),
    )
    appointment_id = cursor.lastrowid
    _history(cursor, appointment_id, "created", None, status, actor_id,
             "Booked by administrator" if actor_role == "admin" else None)

    appointment = fetch_appointment(cursor, appointment_id)
    if status == "pending":
        notify(cursor, client_id, "Request submitted",
               f"Your request for {describe(appointment)} with {appointment['provider_name']} is waiting for confirmation.",
               "info", "N001", appointment_id)
        notify(cursor, appointment["staff_user_id"], "New appointment request",
               f"{appointment['client_name']} requested {describe(appointment)}.", "info", "N002", appointment_id)
    else:
        notify(cursor, client_id, "Appointment booked",
               f"An appointment was booked for you: {describe(appointment)} with {appointment['provider_name']}.",
               "success", "N003", appointment_id)
        notify(cursor, appointment["staff_user_id"], "New appointment",
               f"Admin booked {appointment['client_name']} for {describe(appointment)}.", "info", "N002", appointment_id)
    write_audit(cursor, actor_id, "Created appointment", "appointment", appointment_id,
                new_value={"status": status, "date": day, "start": to_time(start), "provider_id": provider_id,
                           "service_id": service_id, "client_id": client_id})
    return appointment_id


# ---------------------------------------------------------
# RESCHEDULE (F036, S15, BR-014..BR-016)
# ---------------------------------------------------------
def reschedule(cursor, appointment_id, new_day, new_start, actor_id, actor_role, actor_provider_id,
               settings, now, reason=None):
    current = fetch_appointment(cursor, appointment_id)
    if not can_view(current, actor_role, actor_id, actor_provider_id):
        raise PermissionError()
    _lock(cursor, current["provider_id"], current["user_id"])
    cursor.execute("SELECT status FROM appointments WHERE id = %s FOR UPDATE", (appointment_id,))
    current = fetch_appointment(cursor, appointment_id)          # re-read after the lock

    if current["status"] not in ACTIVE_STATUSES:
        raise AppointmentError("Only pending or confirmed appointments can be rescheduled.")
    if actor_role == "user" and client_cutoff_passed(current, settings, now):
        raise AppointmentError(
            f"Appointments cannot be rescheduled online less than {settings['cancellation_cutoff_hours']} "
            "hour(s) before they start. Please contact the staff.")
    if actor_role != "user" and not (reason or "").strip():
        raise AppointmentError("Please give a reason for the change; the client will see it.")

    old_day, old_start = to_date(current["appointment_date"]), to_time(current["start_time"])
    if old_day == new_day and old_start == to_time(new_start):
        raise AppointmentError("Choose a different date or time.")

    service = get_service(cursor, current["service_id"])
    end, error = check_requested_slot(
        cursor, current["provider_id"], service, current["user_id"], new_day, to_time(new_start),
        settings, now, exclude_appointment_id=appointment_id, apply_client_rules=(actor_role == "user"))
    if error:
        raise AppointmentError(error)

    # A client-initiated move needs fresh approval; staff/admin moves keep the status.
    new_status = "pending" if actor_role == "user" else current["status"]
    cursor.execute(
        """UPDATE appointments
           SET appointment_date = %s, start_time = %s, end_time = %s, status = %s,
               reschedule_count = reschedule_count + 1, reminder_sent_at = NULL, sameday_reminder_sent_at = NULL
           WHERE id = %s""",
        (new_day, to_time(new_start), end, new_status, appointment_id),
    )
    old_text = describe(current)
    _history(cursor, appointment_id, "rescheduled", current["status"], new_status, actor_id,
             (reason or "").strip() or f"Moved from {old_text}")
    updated = fetch_appointment(cursor, appointment_id)
    note = f" Reason: {reason.strip()}" if (reason or "").strip() else ""
    if actor_role == "user":
        notify(cursor, updated["user_id"], "Reschedule requested",
               f"Your appointment was moved to {describe(updated)} and is waiting for confirmation.",
               "info", "N005", appointment_id)
        notify(cursor, updated["staff_user_id"], "Appointment rescheduled",
               f"{updated['client_name']} moved {old_text} to {describe(updated)}. Please review.",
               "warning", "N005", appointment_id)
    else:
        notify(cursor, updated["user_id"], "Appointment rescheduled",
               f"Your appointment was moved to {describe(updated)}.{note}", "warning", "N005", appointment_id)
        if actor_role == "admin":
            notify(cursor, updated["staff_user_id"], "Appointment rescheduled",
                   f"Admin moved {updated['client_name']}'s {old_text} to {describe(updated)}.{note}",
                   "warning", "N005", appointment_id)
    # Administrators always hear about schedule changes (other admins when an admin did it).
    who = {"user": f"Client {updated['client_name']} requested", "provider": f"{updated['provider_name']} made"}.get(
        actor_role, "An administrator made")
    notify_admins(cursor, "Reschedule request" if actor_role == "user" else "Appointment rescheduled",
                  f"{who} a schedule change: #{appointment_id} {old_text} → {describe(updated)} "
                  f"(staff: {updated['provider_name']}, client: {updated['client_name']}).{note}",
                  "warning" if actor_role == "user" else "info", "N005", appointment_id, exclude_user_id=actor_id)
    write_audit(cursor, actor_id, "Rescheduled appointment", "appointment", appointment_id,
                old_value={"date": old_day, "start": old_start, "status": current["status"]},
                new_value={"date": new_day, "start": to_time(new_start), "status": new_status},
                details=(reason or "").strip() or None)
    return updated


# ---------------------------------------------------------
# STATUS CHANGES (F032, F033, F037, F052, F053; BR-012, BR-013, BR-017, BR-018)
# ---------------------------------------------------------
STATUS_EVENTS = {
    # new_status: (title, notification type, event code)
    "confirmed": ("Appointment confirmed", "success", "N003"),
    "rejected": ("Request declined", "danger", "N004"),
    "cancelled": ("Appointment cancelled", "warning", "N006"),
    "completed": ("Appointment completed", "success", "N010"),
    "no_show": ("Marked as did not attend", "warning", "N009"),
}


def change_status(cursor, appointment_id, new_status, actor_id, actor_role, actor_provider_id,
                  settings, now, reason=None):
    reason = (reason or "").strip()
    cursor.execute("SELECT id FROM appointments WHERE id = %s FOR UPDATE", (appointment_id,))
    current = fetch_appointment(cursor, appointment_id)
    if not can_view(current, actor_role, actor_id, actor_provider_id):
        raise PermissionError()

    old_status = current["status"]
    if not role_may_set(actor_role, new_status):
        raise PermissionError()
    if not can_transition(old_status, new_status):
        raise AppointmentError(
            f"A {status_label(old_status).lower()} appointment cannot be changed to {status_label(new_status).lower()}.")
    if new_status in REQUIRES_STARTED and start_datetime(current) > now:
        raise AppointmentError(
            f"'{status_label(new_status)}' can only be recorded after the appointment's start time.")
    if new_status == "rejected" and not reason:
        raise AppointmentError("Please give the client a reason for declining the request.")
    if new_status == "cancelled":
        if actor_role == "user":
            if current["status"] == "confirmed" and client_cutoff_passed(current, settings, now):
                raise AppointmentError(
                    f"Confirmed appointments cannot be cancelled online less than "
                    f"{settings['cancellation_cutoff_hours']} hour(s) before they start. Please contact the staff.")
            if settings["require_cancellation_reason"] and not reason:
                raise AppointmentError("Please tell us why you are cancelling.")
        elif not reason:
            raise AppointmentError("Please give a reason for cancelling; the client will see it.")
        if start_datetime(current) <= now and actor_role == "user":
            raise AppointmentError("This appointment has already started and can no longer be cancelled online.")

    # Was this pending request created by a reschedule (rather than a new booking)?
    cursor.execute("SELECT action FROM appointment_history WHERE appointment_id = %s ORDER BY id DESC LIMIT 1",
                   (appointment_id,))
    last = cursor.fetchone()
    is_reschedule_request = old_status == "pending" and bool(last) and last["action"] == "rescheduled"
    cursor.execute("SELECT name FROM users WHERE id = %s", (actor_id,))
    actor_row = cursor.fetchone()
    actor_name = actor_row["name"] if actor_row else "Staff"

    fields = ["status = %s"]
    values = [new_status]
    if new_status == "cancelled":
        fields += ["cancellation_reason = %s", "cancelled_by = %s"]
        values += [reason[:255] or None, actor_id]
    if new_status == "rejected":
        fields.append("rejection_reason = %s")
        values.append(reason[:255])
    cursor.execute(f"UPDATE appointments SET {', '.join(fields)} WHERE id = %s", (*values, appointment_id))
    _history(cursor, appointment_id, new_status, old_status, new_status, actor_id, reason or None)

    title, notif_type, code = STATUS_EVENTS[new_status]
    text = describe(current)
    because = f" Reason: {reason}" if reason else ""
    if new_status == "cancelled":
        if actor_role == "user":
            notify(cursor, current["user_id"], title, f"You cancelled {text}.", notif_type, code, appointment_id)
            notify(cursor, current["staff_user_id"], title,
                   f"{current['client_name']} cancelled {text}.{because}", notif_type, code, appointment_id)
        else:
            notify(cursor, current["user_id"], title, f"Your {text} was cancelled.{because}", notif_type, code, appointment_id)
            if actor_role == "admin":
                notify(cursor, current["staff_user_id"], title,
                       f"Admin cancelled {current['client_name']}'s {text}.{because}", notif_type, code, appointment_id)
    elif new_status in ("confirmed", "rejected"):
        # A decision on a request: the client AND the staff member are both told,
        # and for reschedule requests the administrators too (they were told about the request).
        approved = new_status == "confirmed"
        what = "reschedule request" if is_reschedule_request else "appointment request"
        verb = "approved" if approved else "declined"
        title = (("Reschedule approved" if approved else "Reschedule declined") if is_reschedule_request
                 else ("Appointment confirmed" if approved else "Request declined"))
        if approved:
            client_text = f"Your {what} was approved: {text} with {current['provider_name']} is confirmed."
        else:
            client_text = (f"Your {what} for {text} was declined.{because} "
                           "The time slot was released; please book another time if you still need it.")
        notify(cursor, current["user_id"], title, client_text, notif_type, code, appointment_id)
        decided_by = "You" if actor_id == current["staff_user_id"] else actor_name
        notify(cursor, current["staff_user_id"], title,
               f"{decided_by} {verb} {current['client_name']}'s {what} for {text}.{because}",
               "success" if approved else "warning", code, appointment_id)
        if is_reschedule_request:
            notify_admins(cursor, title, f"{actor_name} {verb} {current['client_name']}'s {what}: #{appointment_id} "
                          f"{text} with {current['provider_name']}.{because}", "info", code, appointment_id,
                          exclude_user_id=actor_id)
    elif new_status == "completed":
        notify(cursor, current["user_id"], title,
               f"Your {text} has been marked as completed.", notif_type, code, appointment_id)
    elif new_status == "no_show":
        notify(cursor, current["user_id"], title,
               f"You were recorded as not attending {text}.", notif_type, code, appointment_id)

    write_audit(cursor, actor_id, f"Appointment {status_label(new_status).lower()}", "appointment", appointment_id,
                old_value={"status": old_status}, new_value={"status": new_status}, details=reason or None)
    return fetch_appointment(cursor, appointment_id)


def available_actions(appointment, role, settings, now):
    """Which buttons to show on a detail page. The server re-checks everything."""
    if appointment is None:
        return []
    status = appointment["status"]
    started = start_datetime(appointment) <= now
    actions = []
    if role in ("provider", "admin"):
        if status == "pending":
            actions += ["confirmed", "rejected"]
        if status == "confirmed" and started:
            actions += ["completed", "no_show"]
        if status in ACTIVE_STATUSES:
            actions += ["reschedule", "cancelled"]
    elif role == "user" and status in ACTIVE_STATUSES and not started:
        if not (status == "confirmed" and client_cutoff_passed(appointment, settings, now)):
            actions.append("cancelled")
        if not client_cutoff_passed(appointment, settings, now):
            actions.append("reschedule")
    return actions
