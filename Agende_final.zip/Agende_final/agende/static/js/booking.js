// =========================================================
// BOOKING.JS - booking wizard and reschedule picker.
// Only times returned by /api/slots as "available" can be chosen,
// and the server validates everything again when the form is sent
// (blueprint section 9, step 5 "final validation").
// =========================================================
(function () {
    const form = document.getElementById("bookingForm");
    if (!form) { return; }

    const mode = form.dataset.mode;                       // "book" or "reschedule"
    const services = JSON.parse(document.getElementById("servicesData")?.textContent || "[]");
    const state = {
        clientId: form.dataset.clientId || "",
        serviceId: form.dataset.serviceId || "",
        providerId: form.dataset.providerId || "",
        appointmentId: form.dataset.appointmentId || "",
        date: "", time: "", timeLabel: "",
        month: (form.dataset.today || new Date().toISOString().slice(0, 10)).slice(0, 7),
        today: form.dataset.today || new Date().toISOString().slice(0, 10),
    };
    const $ = (sel) => form.querySelector(sel);
    const fields = {
        client: $("input[name=client_id]"), service: $("input[name=service_id]"), provider: $("input[name=provider_id]"),
        date: $("input[name=appointment_date]"), time: $("input[name=start_time]"),
    };

    function serviceById(id) { return services.find((s) => String(s.id) === String(id)); }

    function query(extra) {
        const p = new URLSearchParams();
        if (state.appointmentId) { p.set("appointment_id", state.appointmentId); }
        else { p.set("provider_id", state.providerId); p.set("service_id", state.serviceId); }
        if (state.clientId) { p.set("client_id", state.clientId); }
        Object.entries(extra).forEach(([k, v]) => p.set(k, v));
        return p.toString();
    }

    // ---------- step 1: services ----------
    function renderServices() {
        const box = document.getElementById("serviceChoices");
        if (!box) { return; }
        box.innerHTML = "";
        services.forEach((s) => {
            const b = document.createElement("button");
            b.type = "button";
            b.className = "choice";
            b.setAttribute("aria-pressed", String(String(s.id) === String(state.serviceId)));
            b.disabled = s.staff.length === 0;
            b.innerHTML = `<span class="choice-title"></span><span class="choice-meta"></span><span class="choice-meta"></span>`;
            b.children[0].textContent = s.name;
            b.children[1].textContent = `${s.duration} minutes · ${s.staff.length ? s.staff.length + " staff" : "no staff available yet"}`;
            b.children[2].textContent = s.description || "";
            b.addEventListener("click", () => {
                state.serviceId = String(s.id);
                state.providerId = s.staff.length === 1 ? String(s.staff[0].id) : "";
                resetDateTime();
                renderServices(); renderStaff(); updateSteps();
                if (state.providerId) { loadDates(); }
                document.getElementById("stepStaff")?.scrollIntoView({ behavior: "smooth", block: "nearest" });
            });
            box.appendChild(b);
        });
    }

    // ---------- step 2: staff ----------
    function renderStaff() {
        const section = document.getElementById("stepStaff");
        const box = document.getElementById("staffChoices");
        if (!box) { return; }
        const service = serviceById(state.serviceId);
        section.hidden = !service;
        box.innerHTML = "";
        if (!service) { return; }
        service.staff.forEach((p) => {
            const b = document.createElement("button");
            b.type = "button";
            b.className = "choice";
            b.setAttribute("aria-pressed", String(String(p.id) === String(state.providerId)));
            b.innerHTML = `<span class="d-flex align-items-center gap-2"><span class="avatar sm soft"></span><span><span class="choice-title d-block"></span><span class="choice-meta"></span></span></span>`;
            b.querySelector(".avatar").textContent = p.name.replace(/^(Dr\.|Engr\.|Atty\.)\s*/, "").slice(0, 1);
            b.querySelector(".choice-title").textContent = p.name;
            b.querySelector(".choice-meta").textContent = p.position || "Staff";
            b.addEventListener("click", () => {
                state.providerId = String(p.id);
                resetDateTime();
                renderStaff(); updateSteps(); loadDates();
            });
            box.appendChild(b);
        });
    }

    // ---------- step 3: date ----------
    let availableDays = {};
    let maxDate = null;
    async function loadDates() {
        const section = document.getElementById("stepDate");
        section.hidden = !(state.appointmentId || (state.serviceId && state.providerId));
        if (section.hidden) { return; }
        const grid = document.getElementById("calGrid");
        grid.innerHTML = '<div class="skeleton" style="grid-column:1/-1;height:220px"></div>';
        try {
            const res = await fetch(`${form.dataset.datesUrl}?${query({ month: state.month })}`, { headers: { Accept: "application/json" } });
            const data = await res.json();
            availableDays = data.days || {};
            maxDate = data.max_date || null;
            document.getElementById("dateMessage").textContent = data.message || "";
        } catch (e) {
            availableDays = {};
            document.getElementById("dateMessage").textContent = "Could not load availability. Check your connection and try again.";
        }
        renderCalendar();
    }

    function renderCalendar() {
        const [y, m] = state.month.split("-").map(Number);
        const first = new Date(y, m - 1, 1);
        const days = new Date(y, m, 0).getDate();
        document.getElementById("calTitle").textContent = first.toLocaleDateString(undefined, { month: "long", year: "numeric" });
        const thisMonth = state.today.slice(0, 7);
        document.getElementById("calPrev").disabled = state.month <= thisMonth;
        document.getElementById("calNext").disabled = !!maxDate && state.month >= maxDate.slice(0, 7);
        const grid = document.getElementById("calGrid");
        grid.innerHTML = "";
        ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].forEach((d) => {
            const h = document.createElement("div"); h.className = "dow"; h.textContent = d; grid.appendChild(h);
        });
        for (let i = 0; i < first.getDay(); i++) { const pad = document.createElement("div"); pad.className = "cal-day outside"; grid.appendChild(pad); }
        let anyAvailable = false;
        for (let d = 1; d <= days; d++) {
            const iso = `${state.month}-${String(d).padStart(2, "0")}`;
            const count = availableDays[iso];
            const b = document.createElement("button");
            b.type = "button";
            b.className = "cal-day" + (count ? " available" : "") + (iso === state.date ? " selected" : "") + (iso === state.today ? " today" : "");
            b.disabled = !count;
            b.innerHTML = `<span>${d}</span>${count ? `<small>${count} open</small>` : ""}`;
            b.setAttribute("aria-label", new Date(y, m - 1, d).toDateString() + (count ? `, ${count} open times` : ", unavailable"));
            if (iso === state.date) { b.setAttribute("aria-pressed", "true"); }
            if (count) {
                anyAvailable = true;
                b.addEventListener("click", () => { state.date = iso; state.time = ""; renderCalendar(); updateSteps(); loadSlots(); });
            }
            grid.appendChild(b);
        }
        if (!anyAvailable && !document.getElementById("dateMessage").textContent) {
            document.getElementById("dateMessage").textContent = "No open dates this month. Try the next month.";
        } else if (anyAvailable) {
            document.getElementById("dateMessage").textContent = "";
        }
    }

    function shiftMonth(delta) {
        const [y, m] = state.month.split("-").map(Number);
        const d = new Date(y, m - 1 + delta, 1);
        state.month = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
        loadDates();
    }

    // ---------- step 4: time ----------
    async function loadSlots() {
        const section = document.getElementById("stepTime");
        section.hidden = !state.date;
        if (!state.date) { return; }
        const grid = document.getElementById("slotGrid");
        grid.innerHTML = '<div class="skeleton" style="grid-column:1/-1;height:90px"></div>';
        let data = { slots: [] };
        try {
            const res = await fetch(`${form.dataset.slotsUrl}?${query({ date: state.date })}`, { headers: { Accept: "application/json" } });
            data = await res.json();
        } catch (e) { data = { slots: [], message: "Could not load times. Please try again." }; }
        grid.innerHTML = "";
        const reasons = { booked: "Booked", blocked: "Unavailable (blocked)", past: "Too soon", clash: "You have another appointment then" };
        data.slots.forEach((s) => {
            const b = document.createElement("button");
            b.type = "button";
            b.className = "slot state-" + s.state;
            b.textContent = s.label;
            b.disabled = s.state !== "available";
            b.title = s.state === "available" ? `${s.label} – ${s.end_label}` : `${s.label}: ${reasons[s.state] || "Unavailable"}`;
            b.setAttribute("aria-label", b.title);
            b.setAttribute("aria-pressed", String(s.time === state.time));
            if (!b.disabled) {
                b.addEventListener("click", () => { state.time = s.time; state.timeLabel = `${s.label} – ${s.end_label}`; loadSlotsPressed(); updateSteps(); });
            }
            grid.appendChild(b);
        });
        document.getElementById("slotMessage").textContent = data.message || "";
    }
    function loadSlotsPressed() {
        form.querySelectorAll("#slotGrid .slot").forEach((b) => {
            b.setAttribute("aria-pressed", String(b.textContent === (state.timeLabel.split(" – ")[0])));
        });
    }

    function resetDateTime() { state.date = ""; state.time = ""; state.timeLabel = ""; document.getElementById("stepTime").hidden = true; }

    // ---------- summary + stepper ----------
    function updateSteps() {
        const service = serviceById(state.serviceId);
        const staff = service ? service.staff.find((p) => String(p.id) === String(state.providerId)) : null;
        if (fields.client) { state.clientId = fields.client.value; }
        if (fields.service) { fields.service.value = state.serviceId; }
        if (fields.provider) { fields.provider.value = state.providerId; }
        fields.date.value = state.date;
        fields.time.value = state.time;
        const set = (id, text) => { const el = document.getElementById(id); if (el) { el.textContent = text || "—"; } };
        if (mode === "book") {
            set("sumService", service ? service.name : "");
            set("sumDuration", service ? `${service.duration} min` : "");
            set("sumStaff", staff ? staff.name : "");
        }
        set("sumDate", state.date ? new Date(state.date + "T00:00").toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric", year: "numeric" }) : "");
        set("sumTime", state.timeLabel);
        const ready = (mode === "reschedule" || (state.serviceId && state.providerId && (!fields.client || fields.client.value))) && state.date && state.time;
        document.getElementById("submitBooking").disabled = !ready;
        const done = [mode === "reschedule" || !!state.serviceId, mode === "reschedule" || !!state.providerId, !!state.date, !!state.time];
        form.querySelectorAll(".stepper .step").forEach((el, i) => {
            const offset = mode === "reschedule" ? 2 : 0;
            const idx = i + offset;
            el.classList.toggle("done", !!done[idx]);
            el.classList.toggle("current", !done[idx] && done.slice(0, idx).every(Boolean));
        });
    }

    document.getElementById("calPrev")?.addEventListener("click", () => shiftMonth(-1));
    document.getElementById("calNext")?.addEventListener("click", () => shiftMonth(1));
    fields.client?.addEventListener("change", () => { state.clientId = fields.client.value; resetDateTime(); updateSteps(); if (state.providerId) { loadDates(); } });
    const clientSelect = document.getElementById("clientSelect");
    clientSelect?.addEventListener("change", () => { fields.client.value = clientSelect.value; fields.client.dispatchEvent(new Event("change")); });
    form.addEventListener("submit", (e) => { if (!fields.date.value || !fields.time.value) { e.preventDefault(); } });

    renderServices();
    renderStaff();
    if (mode === "reschedule" || (state.serviceId && state.providerId)) { loadDates(); }
    updateSteps();
})();
