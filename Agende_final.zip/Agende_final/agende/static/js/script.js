// =========================================================
// SCRIPT.JS - small helpers shared by every page.
// The server re-checks every rule; nothing here is security.
// =========================================================

// ---- Sidebar: slide-in on phones, icon-only collapse on desktop ----
function toggleSidebar() {
    document.getElementById("sidebar").classList.toggle("show");
    document.getElementById("sidebarOverlay").classList.toggle("show");
}

function toggleCollapse() {
    const collapsed = document.body.classList.toggle("sidebar-collapsed");
    try { localStorage.setItem("agende.sidebarCollapsed", collapsed ? "1" : "0"); } catch (e) { /* storage blocked */ }
    const btn = document.querySelector(".collapse-btn");
    if (btn) { btn.setAttribute("aria-expanded", String(!collapsed)); }
}

(function restoreCollapse() {
    try {
        if (localStorage.getItem("agende.sidebarCollapsed") === "1" && window.innerWidth >= 992) {
            document.body.classList.add("sidebar-collapsed");
        }
    } catch (e) { /* storage blocked */ }
})();

// ---- Legacy helpers kept from 2.1 ----
function confirmCancel(event) {
    if (!window.confirm("Are you sure you want to cancel this appointment?")) { event.preventDefault(); return false; }
    return true;
}
function confirmAction(message) { return window.confirm(message); }

document.addEventListener("DOMContentLoaded", function () {
    // Flash messages fade out after a few seconds (errors stay longer).
    document.querySelectorAll(".alert-auto-hide").forEach(function (alertEl) {
        const delay = alertEl.classList.contains("alert-danger") ? 9000 : 5000;
        setTimeout(function () {
            alertEl.classList.remove("show");
            setTimeout(function () { alertEl.remove(); }, 300);
        }, delay);
    });

    // Header gets a soft shadow once the page scrolls.
    const header = document.querySelector(".app-header");
    if (header) {
        const update = function () { header.classList.toggle("is-scrolled", window.scrollY > 6); };
        update();
        window.addEventListener("scroll", update, { passive: true });
    }

    // Close the mobile sidebar with Escape.
    document.addEventListener("keydown", function (e) {
        const sidebar = document.getElementById("sidebar");
        if (e.key === "Escape" && sidebar && sidebar.classList.contains("show")) { toggleSidebar(); }
    });

    // ---- Action dialog: one modal for confirm / reject / cancel / complete / did not attend ----
    const modalEl = document.getElementById("actionModal");
    if (modalEl && window.bootstrap) {
        const modal = new bootstrap.Modal(modalEl);
        const form = modalEl.querySelector("form");
        const reasonWrap = modalEl.querySelector("[data-reason-wrap]");
        const reason = modalEl.querySelector("textarea[name=reason]");
        document.addEventListener("click", function (event) {
            const trigger = event.target.closest("[data-action]");
            if (!trigger) { return; }
            event.preventDefault();
            form.action = trigger.dataset.url;
            form.querySelector("input[name=status]").value = trigger.dataset.action;
            form.querySelector("input[name=next]").value = trigger.dataset.next || window.location.pathname + window.location.search;
            modalEl.querySelector("[data-modal-title]").textContent = trigger.dataset.title || "Update appointment";
            modalEl.querySelector("[data-modal-text]").textContent = trigger.dataset.text || "";
            const submit = modalEl.querySelector("button[type=submit]");
            submit.textContent = trigger.dataset.confirm || "Confirm";
            submit.className = "btn " + (trigger.dataset.danger ? "btn-danger-soft" : "btn-agende");
            const needsReason = trigger.dataset.reason === "required" || trigger.dataset.reason === "optional";
            reasonWrap.hidden = !needsReason;
            reason.required = trigger.dataset.reason === "required";
            reason.value = "";
            modalEl.querySelector("[data-reason-label]").textContent =
                trigger.dataset.reasonLabel || (reason.required ? "Reason (shared with the other party)" : "Reason (optional)");
            modal.show();
            if (needsReason) { setTimeout(function () { reason.focus(); }, 250); }
        });
    }
});

// Spinner on submit buttons so people know something is happening.
document.addEventListener("submit", function (event) {
    if (event.defaultPrevented) { return; }
    const btn = event.submitter || event.target.querySelector('button[type="submit"]');
    if (btn && btn.classList.contains("btn")) {
        setTimeout(function () { btn.classList.add("is-loading"); }, 0);
    }
});
window.addEventListener("pageshow", function () {
    document.querySelectorAll(".btn.is-loading").forEach(function (b) { b.classList.remove("is-loading"); });
});

// ---- Chart.js theme (Chart.js loads before this file) ----
const AGENDE_COLORS = {
    navy: "#10264A", ocean: "#164E9B", royal: "#2676E8", electric: "#48A9FF", teal: "#20D3C2",
    tealInk: "#0FA89A", amber: "#E0A800", green: "#22A06B", red: "#D64545", rose: "#C0287A", gray: "#98A4B5",
    text: "#152A46", text2: "#64748B", grid: "rgba(16, 38, 74, .07)"
};
const STATUS_COLORS = {
    pending: "#E0A800", confirmed: "#2676E8", completed: "#22A06B", cancelled: "#D64545",
    rejected: "#F08A8A", no_show: "#C0287A", expired: "#98A4B5"
};
if (window.Chart) {
    Chart.defaults.font.family = '"Inter", system-ui, "Segoe UI", Roboto, Arial, sans-serif';
    Chart.defaults.font.size = 12;
    Chart.defaults.color = AGENDE_COLORS.text2;
    Chart.defaults.borderColor = AGENDE_COLORS.grid;
    Chart.defaults.maintainAspectRatio = false;
    Chart.defaults.elements.bar.borderRadius = 6;
    Chart.defaults.elements.line.borderWidth = 2.5;
    Chart.defaults.elements.line.tension = 0.35;
    Chart.defaults.elements.point.radius = 0;
    Chart.defaults.elements.point.hoverRadius = 5;
    Chart.defaults.interaction.mode = "index";
    Chart.defaults.interaction.intersect = false;
    Chart.defaults.plugins.legend.labels.usePointStyle = true;
    Chart.defaults.plugins.legend.labels.boxWidth = 8;
    Chart.defaults.plugins.legend.labels.color = AGENDE_COLORS.text;
    Chart.defaults.plugins.tooltip.backgroundColor = "#fff";
    Chart.defaults.plugins.tooltip.titleColor = AGENDE_COLORS.text;
    Chart.defaults.plugins.tooltip.bodyColor = AGENDE_COLORS.text;
    Chart.defaults.plugins.tooltip.borderColor = "#DCE6F2";
    Chart.defaults.plugins.tooltip.borderWidth = 1;
    Chart.defaults.plugins.tooltip.cornerRadius = 10;
    Chart.defaults.plugins.tooltip.padding = 10;
    Chart.defaults.plugins.tooltip.boxPadding = 4;
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        Chart.defaults.animation = false;
    }
}

// Vertical gradient fill: backgroundColor: agendeGradient("#2676E8", "#48A9FF")
function agendeGradient(colorTop, colorBottom) {
    return function (context) {
        const area = context.chart.chartArea;
        if (!area) { return colorTop; }
        const g = context.chart.ctx.createLinearGradient(0, area.top, 0, area.bottom);
        g.addColorStop(0, colorTop);
        g.addColorStop(1, colorBottom);
        return g;
    };
}

// Integer y axis that starts at zero.
function countAxis(extra) {
    return Object.assign({ beginAtZero: true, ticks: { precision: 0 }, grid: { color: AGENDE_COLORS.grid } }, extra || {});
}
