# =========================================================
# DB_DIAGNOSTICS.PY
# Turns MySQL connection/setup errors into plain instructions.
# Used by the error page (web.py) and by app.py's start-up check.
# =========================================================

from agende import config

UPGRADE_HINT = (
    "Your database was made by an older AGENDE version. In phpMyAdmin, export it as a backup, drop agende_db, "
    "then import database/schema.sql and database/seed.sql again."
)


def upgrade_hint(missing):
    """Every older structure is fixed the same way: recreate the database (after a backup)."""
    return UPGRADE_HINT


def explain(error):
    """Return (title, what_to_do) for a PyMySQL error."""
    code = error.args[0] if getattr(error, "args", None) else None
    text = str(error.args[1]) if getattr(error, "args", None) and len(error.args) > 1 else str(error)
    where = f"{config.DB_HOST}:{config.DB_PORT}"
    if code in (2002, 2003, 2006, 2013):
        return ("MySQL server is not running or not reachable",
                f"Start MySQL (XAMPP Control Panel → Start MySQL, or the MySQL80 Windows service), "
                f"then check DB_HOST / DB_PORT in agende/config.py (currently {where}).")
    if code == 1045:
        return ("MySQL rejected the username or password",
                f"Open agende/config.py and set DB_USER / DB_PASSWORD to your MySQL login (currently user "
                f"'{config.DB_USER}' with {'a password' if config.DB_PASSWORD else 'NO password'}). "
                "XAMPP's default is user root with an empty password.")
    if code == 1049 or "database not found" in text.lower():
        return (f"Database '{config.DB_NAME}' does not exist",
                "Create it: import database/schema.sql, then database/seed.sql, in phpMyAdmin (Import tab). "
                "If your database has a different name, set DB_NAME in agende/config.py.")
    if code in (1054, 1146) or "could not be found" in text.lower() or "doesn't exist" in text.lower() \
            or "unknown column" in text.lower() or "does not have column" in text.lower():
        return ("The database is from an older AGENDE version", UPGRADE_HINT)
    return ("Database error", "Check that MySQL is running in XAMPP and that agende/config.py matches your MySQL settings.")


REQUIRED = {
    "users": ["last_login", "updated_at"],
    "providers": ["position"],
    "appointments": ["cancellation_reason", "reschedule_count", "reminder_sent_at"],
    "appointment_history": ["reason"],
    "notifications": ["title", "event_code", "appointment_id"],
    "audit_logs": ["old_value", "new_value"],
    "provider_services": [],
    "services": ["risk_category"],
    "system_settings": [],
    "password_resets": [],
    "forecast_models": ["version_label", "is_active", "train_trigger", "baseline_mae", "training_record_count"],
    "forecast_results": [],
    "historical_appointments": [],
}


def missing_schema_parts(cursor):
    """List tables/columns 3.2 needs that the current database lacks."""
    cursor.execute("""SELECT TABLE_NAME AS t, COLUMN_NAME AS c FROM information_schema.COLUMNS
                      WHERE TABLE_SCHEMA = DATABASE()""")
    columns = {}
    for row in cursor.fetchall():
        columns.setdefault(str(row["t"]).lower(), set()).add(str(row["c"]).lower())
    missing = []
    for table, needed in REQUIRED.items():
        if table not in columns:
            missing.append(f"table {table}")
            continue
        missing += [f"{table}.{col}" for col in needed if col not in columns[table]]
    return missing
