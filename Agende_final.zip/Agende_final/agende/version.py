"""AGENDÉ version (shown when app.py starts)."""
VERSION = "3.2.0"
SCHEMA_VERSION = "3.2"
