# =========================================================
# WEB.PY
# Creates the Flask app object and everything shared by all pages:
# template filters, the header data (unread bell count), request hooks
# (CSRF check, deactivated-account check, housekeeping), error pages,
# and small helpers used by the route files.
#
# The page modules in agende/routes/ each do "from agende.web import app".
# =========================================================

import calendar as pycalendar
import csv
import io
from datetime import date, datetime, time, timedelta
from decimal import Decimal

from flask import Flask, Response, abort, flash, redirect, render_template, request, session, url_for
from flask.json.provider import DefaultJSONProvider
from werkzeug.exceptions import HTTPException
import pymysql

from agende import config
from agende.database import db_cursor
from agende.db_diagnostics import explain
from agende.notifications import maybe_run_housekeeping
from agende.scheduling import STATUS_LABELS, combine, status_label, to_date, to_time
from agende.security import ROLE_LABELS, csrf_field, csrf_is_valid, get_csrf_token
from agende.settings_store import get_settings

class AgendeJSONProvider(DefaultJSONProvider):
    """JSON for templates/API: ISO dates, HH:MM times, plain numbers."""
    @staticmethod
    def default(o):
        if isinstance(o, datetime):
            return o.isoformat(sep=" ")
        if isinstance(o, date):
            return o.isoformat()
        if isinstance(o, (time, timedelta)):
            return to_time(o).strftime("%H:%M")
        if isinstance(o, Decimal):
            return float(o)
        return DefaultJSONProvider.default(o)


app = Flask(__name__)
app.json = AgendeJSONProvider(app)
app.secret_key = config.SECRET_KEY
app.config.update(
    PERMANENT_SESSION_LIFETIME=timedelta(minutes=config.SESSION_LIFETIME_MINUTES),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=config.SESSION_COOKIE_SECURE,
    HOUSEKEEPING_ON_REQUEST=True,
    NOW_OVERRIDE=None,            # tests can freeze the clock
)

DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
STATUS_ICONS = {
    "pending": "bi-hourglass-split", "confirmed": "bi-check2", "completed": "bi-check2-all",
    "cancelled": "bi-x-lg", "rejected": "bi-slash-circle", "no_show": "bi-person-x", "expired": "bi-clock-history",
}


def current_time():
    """The app's clock. Uses the server's local time (set the PC/server time zone correctly)."""
    override = app.config.get("NOW_OVERRIDE")
    return override if override else datetime.now().replace(microsecond=0)


def today():
    return current_time().date()


# ---------------------------------------------------------
# Template filters
# ---------------------------------------------------------
@app.template_filter("mdy")
def format_mdy(value):
    day = to_date(value)
    return day.strftime("%m/%d/%Y") if day else ""


@app.template_filter("nice_date")
def format_nice_date(value):
    day = to_date(value)
    return day.strftime("%a, %b %d, %Y").replace(" 0", " ") if day else ""


@app.template_filter("short_date")
def format_short_date(value):
    day = to_date(value)
    return day.strftime("%b %d").replace(" 0", " ") if day else ""


@app.template_filter("t12")
def format_time12(value):
    t = to_time(value)
    return datetime.combine(date.today(), t).strftime("%I:%M %p").lstrip("0") if t else ""


@app.template_filter("dt")
def format_datetime(value):
    if not value:
        return ""
    if isinstance(value, str):
        return value
    return value.strftime("%m/%d/%Y %I:%M %p")


@app.template_filter("weekday_short")
def weekday_short(value):
    day = to_date(value)
    return day.strftime("%a") if day else ""


@app.template_filter("status_label")
def filter_status_label(value):
    return status_label(value)


@app.template_filter("pct")
def format_pct(value):
    return "—" if value is None else f"{value:g}%"


@app.template_filter("num")
def format_num(value, digits=2):
    return "N/A" if value is None else f"{value:,.{digits}f}"


def timeline_dates(items=None, month_value=None):
    """All days of the selected month (used by the Gantt timeline)."""
    selected = to_date(f"{month_value}-01") if isinstance(month_value, str) else month_value
    if not isinstance(selected, date):
        selected = today().replace(day=1)
    selected = selected.replace(day=1)
    days = pycalendar.monthrange(selected.year, selected.month)[1]
    return [(selected + timedelta(days=i)).isoformat() for i in range(days)]


app.jinja_env.globals.update(
    csrf_field=csrf_field,
    csrf_token=get_csrf_token,
    timeline_dates=timeline_dates,
    today_iso=lambda: today().isoformat(),
    days_ago=lambda n: (today() - timedelta(days=int(n))).isoformat(),
    STATUS_LABELS=STATUS_LABELS,
    STATUS_ICONS=STATUS_ICONS,
    ROLE_LABELS=ROLE_LABELS,
    DAY_NAMES=DAY_NAMES,
)


@app.context_processor
def inject_header_data():
    """Data the header needs on every signed-in page: unread count + latest notifications."""
    data = {"unread_count": 0, "header_notifications": [], "pending_badge": 0, "role_label": "",
            "now": current_time()}
    if "user_id" in session and request.endpoint not in (None, "static"):
        data["role_label"] = ROLE_LABELS.get(session.get("role"), "")
        try:
            with db_cursor() as cursor:
                cursor.execute("SELECT COUNT(*) AS n FROM notifications WHERE user_id = %s AND is_read = 0",
                               (session["user_id"],))
                data["unread_count"] = cursor.fetchone()["n"]
                cursor.execute(
                    """SELECT id, title, message, type, is_read, created_at FROM notifications
                       WHERE user_id = %s ORDER BY is_read ASC, created_at DESC, id DESC LIMIT 5""",
                    (session["user_id"],))
                data["header_notifications"] = cursor.fetchall()
                if session.get("role") == "provider" and session.get("provider_id"):
                    cursor.execute("SELECT COUNT(*) AS n FROM appointments WHERE provider_id = %s AND status = 'pending'",
                                   (session["provider_id"],))
                    data["pending_badge"] = cursor.fetchone()["n"]
                elif session.get("role") == "admin":
                    cursor.execute("SELECT COUNT(*) AS n FROM appointments WHERE status = 'pending'")
                    data["pending_badge"] = cursor.fetchone()["n"]
        except Exception:
            pass
    return data


# ---------------------------------------------------------
# Request hooks
# ---------------------------------------------------------
@app.before_request
def before_every_request():
    session.permanent = True
    if request.endpoint == "static":
        return None

    # 1) CSRF: every state-changing request must carry the session's token.
    if request.method == "POST" and not csrf_is_valid():
        abort(400, description="Your form expired or was submitted from another site. Please go back, refresh the page and try again.")

    # 2) A deactivated account is signed out on its next request (BR-026).
    if "user_id" in session:
        with db_cursor() as cursor:
            cursor.execute(
                """SELECT u.is_active, u.name, r.name AS role_name FROM users u
                   JOIN roles r ON r.id = u.role_id WHERE u.id = %s""", (session["user_id"],))
            row = cursor.fetchone()
        if row is None or not row["is_active"] or row["role_name"] != session.get("role"):
            session.clear()
            flash("Your account is no longer active or its role changed. Please sign in again.", "danger")
            return redirect(url_for("login"))
        session["name"] = row["name"]

        # 3) Reminders / expiry (at most once per minute per server process).
        if request.method == "GET" and app.config.get("HOUSEKEEPING_ON_REQUEST"):
            maybe_run_housekeeping(db_cursor, get_settings, current_time())
    return None


@app.after_request
def security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    if "user_id" in session:
        response.headers.setdefault("Cache-Control", "no-store")
    return response


# ---------------------------------------------------------
# Error pages and failure messages
# Rule: when a FORM ACTION (POST) fails, the user is sent back to the page
# they were on with a red message saying what happened (nothing is saved,
# because db_cursor() rolls the transaction back). Only when a PAGE itself
# cannot be shown (GET) is a full error page displayed - and that page keeps
# the sidebar, so the user is never stuck and can always log out.
# ---------------------------------------------------------
SETUP_ERROR_CODES = {1045, 1049, 1054, 1146, 2002, 2003, 2006, 2013}


def _back_url():
    referrer = request.referrer or ""
    if referrer.startswith(request.host_url) and referrer.split("?")[0] != request.base_url:
        return referrer
    return dashboard_url() if "user_id" in session else url_for("login")


def _action_failed(message, category="danger"):
    flash(message, category)
    return redirect(_back_url())


@app.errorhandler(400)
def bad_request(error):
    message = getattr(error, "description", None) or "The request could not be processed."
    if request.method == "POST":
        return _action_failed(message)
    return render_template("error.html", code=400, title="Request could not be processed",
                           message=message, icon="bi-exclamation-octagon"), 400


@app.errorhandler(403)
def forbidden(error):
    if request.method == "POST":
        return _action_failed("Action not allowed: your account does not have permission for that. Nothing was changed.")
    return render_template("error.html", code=403, title="Access denied",
                           message="You do not have permission to view this page.", icon="bi-shield-lock"), 403


@app.errorhandler(404)
def not_found(error):
    if request.method == "POST":
        return _action_failed("That record no longer exists (it may have been removed). Nothing was changed.")
    return render_template("error.html", code=404, title="Page not found",
                           message="The page you are looking for does not exist.", icon="bi-search"), 404


@app.errorhandler(405)
def method_not_allowed(error):
    return render_template("error.html", code=405, title="Not available this way",
                           message="This address only accepts form submissions. Use the buttons in the app.",
                           icon="bi-sign-stop"), 405


@app.errorhandler(pymysql.err.MySQLError)
def database_error(error):
    """Setup problems (MySQL stopped, wrong password, missing database, 2.1 database
    from an older version) get a page that says exactly what to fix. Temporary problems during
    an action (e.g. a busy lock) send the user back with a message."""
    code = error.args[0] if error.args else None
    app.logger.error("Database error: %r", error)
    if request.method == "POST" and code not in SETUP_ERROR_CODES:
        return _action_failed("The database was busy and the action was not saved. Please try again. "
                              f"(MySQL error {code})")
    title, advice = explain(error)
    return render_template("error.html", code=503, title=title, message=advice, icon="bi-database-exclamation",
                           detail=f"MySQL error {code if code is not None else ''}: "
                                  f"{error.args[1] if len(error.args) > 1 else error}"), 503


@app.errorhandler(Exception)
def unexpected_error(error):
    """Safety net for bugs: log the full traceback in the console, tell the user
    clearly, and never leave them stuck on a crash page."""
    if isinstance(error, HTTPException):
        return error
    reference = current_time().strftime("%Y%m%d-%H%M%S")
    app.logger.exception("Unexpected error (reference %s) on %s %s", reference, request.method, request.path)
    if request.method == "POST":
        return _action_failed(f"Something went wrong and nothing was saved. Please try again. "
                              f"If it keeps happening, report error reference {reference} ({type(error).__name__}).")
    return render_template("error.html", code=500, title="Something went wrong",
                           message="This page could not be shown. Try again, or go back to your dashboard. "
                                   "The details were written to the server console.",
                           detail=f"Error reference {reference}: {type(error).__name__}: {error}",
                           icon="bi-bug"), 500


# ---------------------------------------------------------
# Shared helpers for route files
# ---------------------------------------------------------
def provider_id_or_403():
    provider_id = session.get("provider_id")
    if not provider_id:
        abort(403)
    return provider_id


def load_settings():
    with db_cursor() as cursor:
        return get_settings(cursor)


# Status dots on the mini calendar: (key, statuses counted, label)
CALENDAR_DOTS = [
    ("pending", ("pending",), "Pending"),
    ("confirmed", ("confirmed",), "Confirmed"),
    ("completed", ("completed",), "Completed"),
    ("cancelled", ("cancelled", "rejected"), "Cancelled / declined"),
    ("no_show", ("no_show",), "Did not attend"),
]
app.jinja_env.globals["CALENDAR_DOTS"] = CALENDAR_DOTS


def month_grid(month_start, status_counts_by_day):
    """Weeks (Sun-Sat) for the mini calendar panel.
    status_counts_by_day: {date: {status: count}}. Each day gets one coloured dot
    per status group present (see CALENDAR_DOTS) plus a text breakdown."""
    first = month_start.replace(day=1)
    lead = (first.weekday() + 1) % 7                     # Sunday-first grid
    start = first - timedelta(days=lead)
    weeks, current = [], start
    for _ in range(6):
        week = []
        for _ in range(7):
            counts = status_counts_by_day.get(current, {}) or {}
            dots = []
            for key, statuses, label in CALENDAR_DOTS:
                n = sum(int(counts.get(status, 0)) for status in statuses)
                if n:
                    dots.append({"key": key, "label": label, "count": n})
            week.append({"date": current, "in_month": current.month == first.month, "is_today": current == today(),
                         "count": sum(d["count"] for d in dots), "dots": dots,
                         "breakdown": ", ".join(f"{d['count']} {d['label'].lower()}" for d in dots)})
            current += timedelta(days=1)
        weeks.append(week)
        if current.month != first.month and current > first:
            break
    return weeks


def selected_month():
    raw = request.args.get("month", "")
    chosen = to_date(f"{raw}-01") if raw else None
    chosen = chosen or today().replace(day=1)
    return max(date(2020, 1, 1), min(chosen, date(2077, 12, 1)))


def month_bounds(month_start):
    days = pycalendar.monthrange(month_start.year, month_start.month)[1]
    return month_start, month_start + timedelta(days=days - 1)


def shift_month(month_start, delta):
    year, month = month_start.year, month_start.month + delta
    while month > 12:
        year, month = year + 1, month - 12
    while month < 1:
        year, month = year - 1, month + 1
    return date(year, month, 1)


def paginate(total, per_page=25):
    try:
        page = max(1, int(request.args.get("page", 1)))
    except ValueError:
        page = 1
    pages = max(1, -(-total // per_page))
    page = min(page, pages)
    return {"page": page, "pages": pages, "total": total, "per_page": per_page, "offset": (page - 1) * per_page}


def page_url(page):
    args = request.args.to_dict()
    args["page"] = page
    return url_for(request.endpoint, **(request.view_args or {}), **args)


app.jinja_env.globals["page_url"] = page_url


def smart_order(alias="a"):
    """Default order for appointment lists. Returns (ORDER BY sql, params).
      1. Upcoming appointments (today onward): soonest to farthest - by date,
         then time, then appointment ID.
      2. Past appointments after them: most recent first.
    Rescheduled appointments simply sit at their (new) date - they are marked
    with a "Rescheduled" badge instead of being moved around the list."""
    t = today()
    sql = f"""({alias}.appointment_date >= %s) DESC,
        CASE WHEN {alias}.appointment_date >= %s THEN {alias}.appointment_date END ASC,
        CASE WHEN {alias}.appointment_date >= %s THEN {alias}.start_time END ASC,
        CASE WHEN {alias}.appointment_date < %s THEN {alias}.appointment_date END DESC,
        CASE WHEN {alias}.appointment_date < %s THEN {alias}.start_time END DESC,
        {alias}.id ASC"""
    return sql, [t] * 5


def is_past_appointment(appointment):
    """Used by the lists to draw the 'Past appointments' divider."""
    return to_date(appointment.get("appointment_date")) < today()


app.jinja_env.globals["is_past_appointment"] = is_past_appointment


def csv_response(filename, header, rows):
    """Excel-friendly UTF-8 CSV download."""
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(header)
    for row in rows:
        writer.writerow(["" if value is None else value for value in row])
    return Response("﻿" + output.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={filename}"})


def appointment_start(appointment):
    return combine(to_date(appointment["appointment_date"]), appointment["start_time"])


def back_to_list():
    role = session.get("role")
    if role == "admin":
        return url_for("admin_appointments")
    if role == "provider":
        return url_for("provider_appointments")
    return url_for("user_appointments")


def dashboard_url():
    role = session.get("role")
    if role == "admin":
        return url_for("admin_dashboard")
    if role == "provider":
        return url_for("provider_dashboard")
    return url_for("user_dashboard")


app.jinja_env.globals["dashboard_url"] = dashboard_url
