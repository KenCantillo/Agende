# =========================================================
# FORECASTING.PY
# Aggregate weekly forecasting with simple linear regression
# (blueprint section 15, CRISP-DM section 16, F078-F088, BR-031..BR-036).
#
#   X = sequential week number (1, 2, 3, ...)
#   Y = appointment count (Model 1)  or  did-not-attend count (Model 2)
#   Y = b0 + b1 * X      fitted by ordinary least squares
#
# TRAINING (CRISP-DM data preparation -> modeling -> evaluation)
#   1. Data preparation - count records per day, then per Monday-Sunday
#      week. Only COMPLETE weeks inside the data coverage are used, and
#      weeks with no records inside that coverage count as 0 (so week
#      numbers stay evenly spaced).
#   2. Chronological split - first 80% of weeks train, last 20% test.
#      Never random, so future weeks cannot leak into training (BR-032).
#   3. Evaluation - MAE, RMSE and R^2 on the TEST weeks, computed from the
#      raw (unclamped) predictions, and compared with a naive baseline
#      (the average of the training weeks) so the model has to earn its place.
#   4. Final model - refit on all weeks.
#
# DEPLOYMENT (CRISP-DM deployment)
#   deploy_models() stores the trained pair (appointments + did-not-attend)
#   in forecast_models under one version label (FM-0001, FM-0002 ...) and
#   marks it ACTIVE. Week 1 of the model is its training_start Monday, so the
#   saved b0/b1 can predict ANY later week without retraining:
#       X(week) = weeks between training_start and that week + 1
#   The dashboard and Forecast page read the active model; they do not
#   retrain on every page view. Housekeeping retrains automatically once a
#   new complete week of live records exists (setting forecast_auto_retrain).
#   Displayed values are max(0, round(prediction)) (BR-035); the raw value is
#   kept in forecast_results.predicted_value.
#
# It forecasts totals per week. It does NOT predict whether any particular
# client will attend (blueprint A-011, A-012).
# No external ML library is needed; every formula is visible below.
# research/forecast_experiment.py documents how the method and the minimum
# number of weeks were chosen (docs/FORECAST_MODEL_REPORT.md).
# =========================================================

from collections import defaultdict
from datetime import timedelta

from agende.scheduling import to_date

TRAIN_SHARE = 0.8
ALGORITHM = "Ordinary least squares (simple linear regression)"
FEATURE = "X = sequential week number"
# A straight line is only shown this many weeks past the end of its training
# data; further out the model is reported as out of date (retrain it).
STALE_AFTER_WEEKS = 8
TARGETS = (("appointments", "appointment_model", "appointments", "Appointments"),
           ("no_shows", "no_show_model", "no_shows", "Did not attend"))
SOURCES = {
    "live": "AGENDE appointment records",
    "imported": "Imported historical dataset",
    "combined": "Both (imported history + AGENDE records)",
}


# ---------------------------------------------------------
# PURE FUNCTIONS (unit-tested in tests/test_rules.py)
# ---------------------------------------------------------
def monday_of(day):
    return day - timedelta(days=day.weekday())


def weekly_series(daily, coverage_start, coverage_end):
    """daily: {date: {"total": n, "no_show": n, "completed": n, "cancelled": n}}
    Returns complete weeks fully inside [coverage_start, coverage_end], gaps as zeros."""
    if coverage_start is None or coverage_end is None or coverage_start > coverage_end:
        return []
    first_monday = monday_of(coverage_start)
    if first_monday < coverage_start:                 # partial first week -> skip it
        first_monday += timedelta(days=7)
    weeks = []
    monday = first_monday
    while monday + timedelta(days=6) <= coverage_end:
        totals = defaultdict(int)
        for offset in range(7):
            for key, value in daily.get(monday + timedelta(days=offset), {}).items():
                totals[key] += value
        weeks.append({"week_start": monday, "appointments": totals["total"], "no_shows": totals["no_show"],
                      "completed": totals["completed"], "cancelled": totals["cancelled"]})
        monday += timedelta(days=7)
    return weeks


def fit_ols(xs, ys):
    """Least squares line. Returns (intercept b0, slope b1)."""
    n = len(xs)
    mean_x, mean_y = sum(xs) / n, sum(ys) / n
    denominator = sum((x - mean_x) ** 2 for x in xs)
    slope = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, ys)) / denominator if denominator else 0.0
    return mean_y - slope * mean_x, slope


def metrics(actual, predicted):
    """MAE, RMSE and R^2 (R^2 is None when the actual values are all equal)."""
    errors = [a - p for a, p in zip(actual, predicted)]
    if not errors:
        return None, None, None
    mae = sum(abs(e) for e in errors) / len(errors)
    rmse = (sum(e * e for e in errors) / len(errors)) ** 0.5
    mean_actual = sum(actual) / len(actual)
    ss_tot = sum((a - mean_actual) ** 2 for a in actual)
    r2 = 1 - sum(e * e for e in errors) / ss_tot if ss_tot else None
    return mae, rmse, r2


def chronological_split(n, share=TRAIN_SHARE):
    """Index where the test weeks begin. Always leaves >= 2 train and >= 1 test week."""
    split = int(n * share)
    return max(2, min(split, n - 1))


def build_model(values, horizon):
    """Evaluate on a chronological split, then refit on everything and forecast."""
    n = len(values)
    xs = list(range(1, n + 1))
    split = chronological_split(n)
    b0_train, b1_train = fit_ols(xs[:split], values[:split])
    test_raw = [b0_train + b1_train * x for x in xs[split:]]
    mae, rmse, r2 = metrics(values[split:], test_raw)
    # Naive baseline: always predict the average training week.
    train_mean = sum(values[:split]) / split
    baseline_mae, baseline_rmse, _ = metrics(values[split:], [train_mean] * (n - split))
    skill = (1 - mae / baseline_mae) * 100 if baseline_mae else None
    mean_test = sum(values[split:]) / (n - split)
    mape_like = (mae / mean_test * 100) if mean_test else None
    train_fit = [b0_train + b1_train * x for x in xs[:split]]
    _, _, r2_train = metrics(values[:split], train_fit)

    b0, b1 = fit_ols(xs, values)
    future_raw = [b0 + b1 * (n + i) for i in range(1, horizon + 1)]
    return {
        "intercept": b0, "slope": b1,
        "train_intercept": b0_train, "train_slope": b1_train,
        "train_weeks": split, "test_weeks": n - split,
        "mae": mae, "rmse": rmse, "r2": r2, "r2_train": r2_train,
        "baseline_mae": baseline_mae, "baseline_rmse": baseline_rmse, "skill_pct": skill,
        "relative_error_pct": mape_like, "test_mean": mean_test,
        "test_actual": values[split:], "test_predicted": test_raw,
        "fitted": [b0 + b1 * x for x in xs],
        "future_raw": future_raw,
        "future_display": [max(0, round(v)) for v in future_raw],
        "negative_clamped": sum(1 for v in future_raw if v < 0),
    }


def run_forecast(daily, coverage_start, coverage_end, min_weeks, horizon, source):
    """Whole pipeline. Always returns a dict with "available" True/False."""
    weeks = weekly_series(daily, coverage_start, coverage_end)
    result = {"available": False, "weeks": weeks, "source": source, "source_label": SOURCES.get(source, source),
              "coverage_start": coverage_start, "coverage_end": coverage_end,
              "min_weeks": min_weeks, "horizon": horizon, "warnings": []}
    if len(weeks) < min_weeks:
        result["message"] = (
            f"Insufficient historical data for forecasting. {len(weeks)} complete week(s) are available; "
            f"at least {min_weeks} are required. AGENDE needs more appointment records before a meaningful "
            "forecast can be generated.")
        return result

    zero_run, longest = 0, 0
    for w in weeks:
        zero_run = zero_run + 1 if w["appointments"] == 0 else 0
        longest = max(longest, zero_run)
    if longest >= 4:
        result["warnings"].append(
            f"The training period contains {longest} consecutive weeks with no records. "
            "Narrow the training period so it does not span a gap (for example, between imported history and live data).")

    appointments = build_model([w["appointments"] for w in weeks], horizon)
    no_shows = build_model([w["no_shows"] for w in weeks], horizon)
    last_monday = weeks[-1]["week_start"]
    future = [{"week_start": last_monday + timedelta(days=7 * i),
               "appointments": appointments["future_display"][i - 1],
               "appointments_raw": appointments["future_raw"][i - 1],
               "no_shows": no_shows["future_display"][i - 1],
               "no_shows_raw": no_shows["future_raw"][i - 1]} for i in range(1, horizon + 1)]
    result.update({
        "available": True,
        "training_start": weeks[0]["week_start"],
        "training_end": weeks[-1]["week_start"] + timedelta(days=6),
        "test_start": weeks[appointments["train_weeks"]]["week_start"],
        "record_count": sum(w["appointments"] for w in weeks),
        "appointment_model": appointments,
        "no_show_model": no_shows,
        "future": future,
    })
    if appointments["negative_clamped"] or no_shows["negative_clamped"]:
        result["warnings"].append("Some raw predictions were below zero and are displayed as 0.")
    return result


# ---------------------------------------------------------
# DATABASE FUNCTIONS
# ---------------------------------------------------------
def _add_counts(daily, rows, date_key="appointment_date"):
    for row in rows:
        day = to_date(row[date_key])
        status, n = row["status"], int(row["n"])
        bucket = daily.setdefault(day, {"total": 0, "no_show": 0, "completed": 0, "cancelled": 0})
        bucket["total"] += n
        if status in ("no_show", "completed", "cancelled"):
            bucket[status] += n


def load_daily_counts(cursor, source, today, provider_id=None, service_id=None):
    """Return (daily_counts, coverage_start, coverage_end) for a data source.
    Live data is covered up to yesterday; imported data up to its last record.
    provider_id / service_id narrow LIVE records to one staff member or one service."""
    daily, starts, ends = {}, [], []
    if source in ("live", "combined"):
        where, params = "appointment_date < %s", [today]
        if provider_id:
            where += " AND provider_id = %s"
            params.append(provider_id)
        if service_id:
            where += " AND service_id = %s"
            params.append(service_id)
        cursor.execute(
            f"""SELECT appointment_date, status, COUNT(*) AS n FROM appointments
               WHERE {where} GROUP BY appointment_date, status""", params)
        rows = cursor.fetchall()
        _add_counts(daily, rows)
        if rows:
            starts.append(min(to_date(r["appointment_date"]) for r in rows))
            ends.append(today - timedelta(days=1))
    if source in ("imported", "combined"):
        cursor.execute(
            """SELECT appointment_date, status, COUNT(*) AS n FROM historical_appointments
               GROUP BY appointment_date, status""")
        rows = cursor.fetchall()
        _add_counts(daily, rows)
        if rows:
            starts.append(min(to_date(r["appointment_date"]) for r in rows))
            ends.append(max(to_date(r["appointment_date"]) for r in rows))
    if not starts:
        return daily, None, None
    return daily, min(starts), max(ends)


HISTORY_STATUS_MAP = {"completed": "completed", "attended": "completed", "cancelled": "cancelled",
                      "no_show": "no_show", "did not attend": "no_show", "did_not_attend": "no_show"}


def read_history_csv(path):
    """Rows for historical_appointments from AGENDE_appointment_history.csv.
    Only what forecasting needs is kept (no patient details). Returns (rows, skipped)."""
    import csv
    rows, skipped = [], 0
    with open(path, newline="", encoding="utf-8-sig") as handle:
        for record in csv.DictReader(handle):
            status = HISTORY_STATUS_MAP.get((record.get("appointment_status") or "").strip().lower())
            if not status or not record.get("appointment_date"):
                skipped += 1
                continue
            try:
                duration = int(round(float(record["appointment_duration"]))) if record.get("appointment_duration") else None
            except ValueError:
                duration = None
            rows.append((record.get("appointment_id"), record["appointment_date"][:10], record.get("appointment_time") or None,
                         duration, record.get("appointment_category"), record.get("provider_id"), status))
    return rows, skipped


def import_history(cursor, rows, replace=False):
    """Insert prepared rows into historical_appointments (in batches)."""
    if replace:
        cursor.execute("DELETE FROM historical_appointments")
    for start in range(0, len(rows), 2000):
        cursor.executemany(
            """INSERT INTO historical_appointments
               (source_ref, appointment_date, start_time, duration_minutes, service_category, provider_code, status)
               VALUES (%s, %s, %s, %s, %s, %s, %s)""", rows[start:start + 2000])
    return imported_history_summary(cursor)


def imported_history_summary(cursor):
    cursor.execute("SELECT COUNT(*) AS n, MIN(appointment_date) AS first_day, MAX(appointment_date) AS last_day FROM historical_appointments")
    return cursor.fetchone()


def week_number(model, week_start):
    """X for any week, counted from the model's first training week (week 1)."""
    return (to_date(week_start) - to_date(model["training_start"])).days // 7 + 1


def predict(model, week_start):
    """(raw, display) prediction of a saved model row for the week starting week_start."""
    raw = float(model["intercept"]) + float(model["slope"]) * week_number(model, week_start)
    return raw, max(0, round(raw))


def deploy_models(cursor, result, user_id, trigger="manual", min_weeks=None):
    """Save the trained pair under a new version label and make it the active model
    (F081, F082, F088). Older versions stay in the table so they can be re-activated.
    Returns (version_label, [appointment_model_id, no_show_model_id])."""
    ids = []
    for model_type, key, target, _label in TARGETS:
        model = result[key]
        cursor.execute(
            """INSERT INTO forecast_models (model_type, algorithm, data_source, training_start, training_end,
                                            training_weeks, test_weeks, training_record_count, intercept, slope,
                                            mae, rmse, r2, baseline_mae, min_weeks, train_trigger, is_active, created_by)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, 0, %s)""",
            (model_type, ALGORITHM, result["source"], result["training_start"], result["training_end"],
             model["train_weeks"], model["test_weeks"], result["record_count"], model["intercept"], model["slope"],
             model["mae"], model["rmse"], model["r2"], model["baseline_mae"], min_weeks or result.get("min_weeks"),
             trigger, user_id),
        )
        model_id = cursor.lastrowid
        ids.append(model_id)
        for row in result["future"]:
            cursor.execute(
                """INSERT INTO forecast_results (model_id, forecast_period, target_type, predicted_value, display_value)
                   VALUES (%s, %s, %s, %s, %s)""",
                (model_id, row["week_start"], target, row[f"{target}_raw"], row[target]),
            )
    cursor.execute("SELECT DISTINCT version_label FROM forecast_models WHERE version_label LIKE 'FM-%%'")
    numbers = [int(r["version_label"][3:]) for r in cursor.fetchall() if r["version_label"][3:].isdigit()]
    version = f"FM-{max(numbers, default=0) + 1:04d}"          # FM-0001, FM-0002, ... (no gaps)
    cursor.execute("UPDATE forecast_models SET version_label = %s WHERE id IN (%s, %s)", (version, ids[0], ids[1]))
    activate_version(cursor, version)
    return version, ids


def activate_version(cursor, version):
    """Make one saved version the active model (deactivates every other one)."""
    cursor.execute("SELECT COUNT(*) AS n FROM forecast_models WHERE version_label = %s", (version,))
    if not cursor.fetchone()["n"]:
        return False
    cursor.execute("UPDATE forecast_models SET is_active = COALESCE(version_label = %s, 0)", (version,))
    return True


def active_models(cursor):
    """{"version": ..., "appointments": row, "no_shows": row} or None."""
    cursor.execute("""SELECT m.*, u.name AS created_by_name FROM forecast_models m
                      LEFT JOIN users u ON u.id = m.created_by
                      WHERE m.is_active = 1 ORDER BY m.id""")
    rows = {row["model_type"]: row for row in cursor.fetchall()}
    if "appointments" not in rows or "no_shows" not in rows:
        return None
    return {"version": rows["appointments"]["version_label"], "appointments": rows["appointments"],
            "no_shows": rows["no_shows"], "source": rows["appointments"]["data_source"],
            "training_start": to_date(rows["appointments"]["training_start"]),
            "training_end": to_date(rows["appointments"]["training_end"]),
            "created_at": rows["appointments"]["created_at"], "trigger": rows["appointments"]["train_trigger"],
            "created_by_name": rows["appointments"]["created_by_name"]}


def model_versions(cursor, limit=12):
    """Saved versions, newest first, one row per version with both models' metrics."""
    cursor.execute(
        """SELECT m.*, u.name AS created_by_name FROM forecast_models m LEFT JOIN users u ON u.id = m.created_by
           ORDER BY m.id DESC LIMIT %s""", (limit * 2,))
    versions = {}
    for row in cursor.fetchall():
        label = row["version_label"] or f"FM-{row['id']:04d}"
        entry = versions.setdefault(label, {"version": label, "created_at": row["created_at"],
                                            "created_by_name": row["created_by_name"], "source": row["data_source"],
                                            "training_start": row["training_start"], "training_end": row["training_end"],
                                            "weeks": row["training_weeks"] + row["test_weeks"],
                                            "records": row["training_record_count"], "trigger": row["train_trigger"],
                                            "is_active": False, "can_activate": bool(row["version_label"])})
        entry[row["model_type"]] = row
        entry["is_active"] = entry["is_active"] or bool(row["is_active"])
    return [v for v in versions.values() if "appointments" in v and "no_shows" in v][:limit]


def deployed_forecast(cursor, today, horizon):
    """Forecast of the ACTIVE model for this week and the next horizon-1 weeks,
    plus live monitoring (predicted vs actual for complete weeks since training)."""
    models = active_models(cursor)
    if not models:
        return {"available": False, "reason": "none"}
    this_monday = monday_of(today)
    last_training_monday = monday_of(models["training_end"])
    weeks_ahead = (this_monday - last_training_monday).days // 7
    out = {"available": True, "models": models, "version": models["version"], "weeks_ahead": weeks_ahead,
           "stale": weeks_ahead > STALE_AFTER_WEEKS, "stale_after": STALE_AFTER_WEEKS,
           "source_label": SOURCES.get(models["source"], models["source"]),
           "appointment_mae": float(models["appointments"]["mae"] or 0),
           "no_show_mae": float(models["no_shows"]["mae"] or 0)}
    future = []
    for i in range(horizon):
        week = this_monday + timedelta(days=7 * i)
        a_raw, a_show = predict(models["appointments"], week)
        n_raw, n_show = predict(models["no_shows"], week)
        future.append({"week_start": week, "appointments": a_show, "appointments_raw": a_raw,
                       "no_shows": n_show, "no_shows_raw": n_raw, "current": i == 0})
    out["future"] = future

    # Live monitoring: complete weeks after the training data, up to 12 weeks.
    monitor = []
    if models["source"] in ("live", "combined"):
        first = last_training_monday + timedelta(days=7)
        last = this_monday - timedelta(days=7)
        if first <= last:
            first = max(first, last - timedelta(days=7 * 11))
            cursor.execute(
                """SELECT appointment_date, status, COUNT(*) AS n FROM appointments
                   WHERE appointment_date BETWEEN %s AND %s GROUP BY appointment_date, status""",
                (first, last + timedelta(days=6)))
            daily = {}
            _add_counts(daily, cursor.fetchall())
            for w in weekly_series(daily, first, last + timedelta(days=6)):
                a_raw, a_show = predict(models["appointments"], w["week_start"])
                n_raw, n_show = predict(models["no_shows"], w["week_start"])
                monitor.append({"week_start": w["week_start"], "appointments": w["appointments"], "appointments_pred": a_show,
                                "no_shows": w["no_shows"], "no_shows_pred": n_show,
                                "appointments_raw": a_raw, "no_shows_raw": n_raw})
    out["monitor"] = monitor
    if monitor:
        out["live_appointment_mae"] = metrics([m["appointments"] for m in monitor], [m["appointments_raw"] for m in monitor])[0]
        out["live_no_show_mae"] = metrics([m["no_shows"] for m in monitor], [m["no_shows_raw"] for m in monitor])[0]
    return out


def train_from_source(cursor, source, today, min_weeks, horizon, train_start=None, train_end=None):
    """Load records, prepare weeks and train both models (no saving)."""
    daily, data_start, data_end = load_daily_counts(cursor, source, today)
    coverage_start = max(filter(None, [data_start, train_start])) if data_start else None
    coverage_end = min(filter(None, [data_end, train_end])) if data_end else None
    result = run_forecast(daily, coverage_start, coverage_end, min_weeks, horizon, source)
    result.update({"data_start": data_start, "data_end": data_end})
    return result


def auto_retrain(cursor, settings, today, user_id=None):
    """Retrain on live records when a new complete week exists (housekeeping).
    Returns the new version label, or None when nothing needed to change."""
    if not settings.get("forecast_auto_retrain"):
        return None
    result = train_from_source(cursor, "live", today, settings["forecast_min_weeks"], settings["forecast_horizon_weeks"])
    if not result["available"]:
        return None
    active = active_models(cursor)
    if active and active["source"] == "live" and active["training_end"] >= result["training_end"]:
        return None                                   # already trained on the latest complete week
    if active and active["source"] != "live" and active["trigger"] == "manual" and active["training_end"] >= result["training_end"]:
        return None                                   # a newer manual model (e.g. combined) is kept
    version, _ids = deploy_models(cursor, result, user_id, trigger="auto", min_weeks=settings["forecast_min_weeks"])
    return {"version": version, "result": result}


def scoped_forecast(cursor, settings, today, provider_id=None, service_id=None):
    """Forecast for ONE staff member or ONE service, trained on demand from their own live
    records with the same method (blueprint permission matrix: staff forecasts are limited to
    their own schedule). Small numbers give larger relative errors, so MAE is always shown."""
    daily, start, end = load_daily_counts(cursor, "live", today, provider_id, service_id)
    if (provider_id or service_id) and start is not None:
        # Coverage begins at the first record of THIS scope; it still ends yesterday.
        end = today - timedelta(days=1)
    return run_forecast(daily, start, end, settings["forecast_min_weeks"], settings["forecast_horizon_weeks"], "live")


def breakdown(cursor, settings, today):
    """Next-week forecast per active staff member and per active service (admin Forecast page)."""
    rows = {"staff": [], "services": []}
    cursor.execute("""SELECT p.id, u.name FROM providers p JOIN users u ON u.id = p.user_id
                      WHERE p.is_active = 1 ORDER BY u.name""")
    for p in cursor.fetchall():
        rows["staff"].append({"name": p["name"], "id": p["id"],
                              "forecast": scoped_forecast(cursor, settings, today, provider_id=p["id"])})
    cursor.execute("SELECT id, name FROM services WHERE is_active = 1 ORDER BY name")
    for sv in cursor.fetchall():
        rows["services"].append({"name": sv["name"], "id": sv["id"],
                                 "forecast": scoped_forecast(cursor, settings, today, service_id=sv["id"])})
    return rows


def export_model(models):
    """The active model as a plain dict (downloadable JSON 'model file')."""
    def part(row):
        return {"model_type": row["model_type"], "equation": f"Y = {float(row['intercept']):.6f} + {float(row['slope']):.6f} * X",
                "intercept_b0": float(row["intercept"]), "slope_b1": float(row["slope"]),
                "test_mae": None if row["mae"] is None else float(row["mae"]),
                "test_rmse": None if row["rmse"] is None else float(row["rmse"]),
                "test_r2": None if row["r2"] is None else float(row["r2"]),
                "baseline_mae": None if row.get("baseline_mae") is None else float(row["baseline_mae"]),
                "training_weeks": row["training_weeks"], "test_weeks": row["test_weeks"]}
    return {"system": "AGENDE", "version": models["version"], "algorithm": ALGORITHM, "feature": FEATURE,
            "week_1_starts": str(models["training_start"]), "training_end": str(models["training_end"]),
            "data_source": models["source"], "trigger": models["trigger"],
            "training_record_count": models["appointments"]["training_record_count"],
            "how_to_predict": "X = ((week_start - week_1_starts).days // 7) + 1;  display = max(0, round(b0 + b1 * X))",
            "models": {"appointments": part(models["appointments"]), "no_shows": part(models["no_shows"])}}


__all__ = ["run_forecast", "load_daily_counts", "weekly_series", "fit_ols", "metrics",
           "build_model", "chronological_split", "imported_history_summary", "SOURCES",
           "deploy_models", "activate_version", "active_models", "model_versions", "deployed_forecast",
           "train_from_source", "auto_retrain", "predict", "week_number", "export_model", "STALE_AFTER_WEEKS",
           "read_history_csv", "import_history", "scoped_forecast", "breakdown"]
