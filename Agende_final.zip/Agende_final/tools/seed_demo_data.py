"""
Generate DEMO appointment history so dashboards, analytics and the live-data
forecast have something to show during development and the UMUX walkthrough.

    python tools/seed_demo_data.py              # 30 past weeks + 2 future weeks (forecast needs 26)
    python tools/seed_demo_data.py --weeks 40

Every generated appointment respects staff working hours and never overlaps
another active booking. Notes are marked "[demo]" so they can be removed:

    DELETE h FROM appointment_history h JOIN appointments a ON a.id = h.appointment_id WHERE a.notes = '[demo]';
    DELETE n FROM notifications n JOIN appointments a ON a.id = n.appointment_id WHERE a.notes = '[demo]';
    DELETE FROM appointments WHERE notes = '[demo]';
    DELETE FROM notifications WHERE user_id IN (SELECT id FROM users WHERE email LIKE '%@demo.agende.test');
    DELETE FROM users WHERE email LIKE '%@demo.agende.test';

It also creates 150 demo client accounts (clientNNN@demo.agende.test, password123), each
with their own attendance habit, so the no-show risk badge shows a realistic mix.

These are illustrative records, NOT real organization data. Do not use them as
evidence in the capstone results chapter.
"""
import os
import random
import sys
from datetime import date, datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agende.database import db_cursor  # noqa: E402
from agende.scheduling import combine, overlaps, to_time  # noqa: E402


FIRST = ["Andrea", "Benjo", "Carla", "Dennis", "Ella", "Francis", "Gabriel", "Hannah", "Isaac", "Joy", "Kevin", "Lara", "Miguel",
         "Nina", "Oscar", "Patricia", "Quinn", "Rafael", "Sofia", "Tomas", "Ursula", "Vince", "Wena", "Xavier", "Yna", "Zoe"]
LAST = ["Aquino", "Bautista", "Castillo", "Dizon", "Estrada", "Flores", "Garcia", "Hernandez", "Ilagan", "Javier", "Lim",
        "Mendoza", "Navarro", "Ocampo", "Pascual", "Quiambao", "Reyes", "Santos", "Tan", "Villanueva"]
DEMO_DOMAIN = "demo.agende.test"
DEMO_CLIENTS = 150


def ensure_demo_clients(cursor, rng):
    """150 demo client accounts (password: password123), so each client has a realistic
    number of visits instead of ten clients sharing every booking."""
    cursor.execute("SELECT password FROM users WHERE email = 'maria.santos@example.com'")
    row = cursor.fetchone()
    cursor.execute("SELECT id FROM roles WHERE name = 'user'")
    role_id = cursor.fetchone()["id"]
    for i in range(1, DEMO_CLIENTS + 1):
        email = f"client{i:03d}@{DEMO_DOMAIN}"
        cursor.execute("SELECT id FROM users WHERE email = %s", (email,))
        if cursor.fetchone() is None and row:
            name = f"{rng.choice(FIRST)} {rng.choice(LAST)}"
            cursor.execute("""INSERT INTO users (role_id, name, email, password, phone, is_active)
                              VALUES (%s, %s, %s, %s, %s, 1)""", (role_id, name, email, row["password"], f"0917-555-{i:04d}"))
    cursor.execute("""SELECT u.id FROM users u JOIN roles r ON r.id = u.role_id WHERE r.name = 'user' AND u.is_active = 1""")
    return [r["id"] for r in cursor.fetchall()]


def main():
    weeks = 30
    if "--weeks" in sys.argv:
        weeks = int(sys.argv[sys.argv.index("--weeks") + 1])
    rng = random.Random(42)
    today = date.today()
    start_day = today - timedelta(weeks=weeks)
    end_day = today + timedelta(days=14)
    now = datetime.now()

    with db_cursor(commit=True) as cursor:
        clients = ensure_demo_clients(cursor, rng)
        # Each client has their own attendance habit, so the advisory no-show risk varies like real data:
        # most clients rarely miss, a few miss often.
        habit = {c: rng.choice([0.02, 0.03, 0.04, 0.05, 0.06, 0.08, 0.10, 0.15, 0.25, 0.35]) for c in clients}
        cursor.execute("""SELECT ps.provider_id, s.id AS service_id, s.duration, p.user_id AS staff_user
                          FROM provider_services ps JOIN services s ON s.id = ps.service_id
                          JOIN providers p ON p.id = ps.provider_id WHERE p.is_active = 1 AND s.is_active = 1""")
        offers = {}
        for r in cursor.fetchall():
            offers.setdefault(r["provider_id"], []).append(r)
        cursor.execute("SELECT provider_id, day_of_week, start_time, end_time FROM provider_schedules WHERE is_available = 1")
        windows = {}
        for r in cursor.fetchall():
            windows.setdefault((r["provider_id"], int(r["day_of_week"])), []).append((to_time(r["start_time"]), to_time(r["end_time"])))
        cursor.execute("""SELECT provider_id, user_id, appointment_date, start_time, end_time FROM appointments
                          WHERE status IN ('pending','confirmed','completed','no_show')""")
        busy, client_busy = {}, {}
        for r in cursor.fetchall():
            span = (combine(r["appointment_date"], r["start_time"]), combine(r["appointment_date"], r["end_time"]))
            busy.setdefault(r["provider_id"], []).append(span)
            client_busy.setdefault(r["user_id"], []).append(span)

        created = 0
        day = start_day
        while day <= end_day:
            weeks_ago = (today - day).days / 7
            growth = 1.0 + 0.04 * (weeks - weeks_ago)          # gentle upward trend
            for provider_id, services in offers.items():
                for w_start, w_end in windows.get((provider_id, day.weekday()), []):
                    slot = combine(day, w_start)
                    while slot < combine(day, w_end):
                        if rng.random() < 0.20 * growth:
                            offer = rng.choice(services)
                            end = slot + timedelta(minutes=offer["duration"])
                            client = rng.choice(clients)
                            if end <= combine(day, w_end) and \
                               not any(overlaps(slot, end, a, b) for a, b in busy.get(provider_id, [])) and \
                               not any(overlaps(slot, end, a, b) for a, b in client_busy.get(client, [])):
                                roll = rng.random()
                                if slot >= now:
                                    status = "confirmed" if roll < 0.7 else "pending"
                                elif roll < 0.12:
                                    status = "cancelled"
                                elif roll < 0.16:
                                    status = "rejected"
                                elif rng.random() < habit[client]:
                                    status = "no_show"
                                else:
                                    status = "completed"
                                lead = rng.choice([1, 2, 3, 4, 5, 7, 7, 10, 14, 21, 30])
                                created_at = datetime.combine(day - timedelta(days=lead), datetime.min.time()) + timedelta(hours=rng.randint(8, 20))
                                cursor.execute(
                                    """INSERT INTO appointments (user_id, provider_id, service_id, appointment_date, start_time, end_time,
                                       status, notes, cancellation_reason, rejection_reason, created_at,
                                       reminder_sent_at, sameday_reminder_sent_at)
                                       VALUES (%s,%s,%s,%s,%s,%s,%s,'[demo]',%s,%s,%s,%s,%s)""",
                                    (client, provider_id, offer["service_id"], day, slot.time(), end.time(), status,
                                     "Schedule conflict" if status == "cancelled" else None,
                                     "Fully booked that day" if status == "rejected" else None,
                                     min(created_at, now), now if slot < now else None, now if slot < now else None))
                                new_id = cursor.lastrowid
                                cursor.execute("""INSERT INTO appointment_history (appointment_id, action, old_status, new_status, performed_by, created_at)
                                                  VALUES (%s, 'created', NULL, 'pending', %s, %s)""", (new_id, client, min(created_at, now)))
                                if status != "pending":
                                    cursor.execute("""INSERT INTO appointment_history (appointment_id, action, old_status, new_status, performed_by)
                                                      VALUES (%s, %s, 'pending', %s, %s)""",
                                                   (new_id, status, status, client if status == "cancelled" else offer["staff_user"]))
                                if status in ("pending", "confirmed", "completed", "no_show"):
                                    busy.setdefault(provider_id, []).append((slot, end))
                                    client_busy.setdefault(client, []).append((slot, end))
                                created += 1
                        slot += timedelta(minutes=30)
            day += timedelta(days=1)
    print(f"Created {created} demo appointments between {start_day} and {end_day}.")


if __name__ == "__main__":
    main()
